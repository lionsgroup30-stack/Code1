import { useState } from 'react';
import { Plus, X, Droplets, FlaskConical, Bug, ShoppingBasket, DollarSign, ShoppingCart, Wallet, HardHat, Sprout, Check, ChevronRight } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { supabase } from '../lib/supabase';
import { todayISO } from '../lib/format';
import { GASTO_SUBCATEGORIAS } from '../lib/calculations';
import { inputClass } from './ui';
import type { ReactNode } from 'react';

type ActionType = 'riego' | 'fertilizacion' | 'plaga' | 'cosecha' | 'venta' | 'compra' | 'gasto' | 'trabajador' | 'siembra';

interface ActionDef { type: ActionType; label: string; icon: ReactNode; color: string }

const ACTIONS: ActionDef[] = [
  { type: 'riego', label: 'Riego', icon: <Droplets size={22} />, color: 'bg-blue-500' },
  { type: 'fertilizacion', label: 'Fertilización', icon: <FlaskConical size={22} />, color: 'bg-purple-500' },
  { type: 'plaga', label: 'Plaga', icon: <Bug size={22} />, color: 'bg-red-500' },
  { type: 'cosecha', label: 'Cosecha', icon: <ShoppingBasket size={22} />, color: 'bg-green-500' },
  { type: 'venta', label: 'Venta', icon: <DollarSign size={22} />, color: 'bg-emerald-500' },
  { type: 'compra', label: 'Compra', icon: <ShoppingCart size={22} />, color: 'bg-indigo-500' },
  { type: 'gasto', label: 'Gasto', icon: <Wallet size={22} />, color: 'bg-amber-500' },
  { type: 'trabajador', label: 'Trabajador', icon: <HardHat size={22} />, color: 'bg-slate-600' },
  { type: 'siembra', label: 'Siembra', icon: <Sprout size={22} />, color: 'bg-lime-600' },
];

export function QuickActionFAB() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeAction, setActiveAction] = useState<ActionType | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState<Record<string, unknown>>({});

  const data = useData();

  const openAction = (type: ActionType) => {
    setActiveAction(type);
    setForm({});
    setSaved(false);
    setMenuOpen(false);
  };

  const closeModal = () => { setActiveAction(null); setForm({}); setSaved(false); };

  const save = async () => {
    if (!activeAction) return;
    setSaving(true);
    try {
      const tableMap: Record<ActionType, string> = {
        riego: 'riego', fertilizacion: 'fertilizacion', plaga: 'plagas',
        cosecha: 'cosechas', venta: 'ventas', compra: 'compras',
        gasto: 'gastos', trabajador: 'trabajadores', siembra: 'cosechas',
      };
      const table = tableMap[activeAction];
      const payload: Record<string, unknown> = { ...form };
      if (activeAction !== 'trabajador') payload.fecha = todayISO();
      if ('parcela_id' in payload && !payload.parcela_id) payload.parcela_id = null;
      if ('cliente_id' in payload && !payload.cliente_id) payload.cliente_id = null;
      const { error } = await supabase.from(table).insert(payload);
      if (error) throw error;
      setSaved(true);
      setTimeout(() => closeModal(), 1200);
      data.refresh();
    } catch (err) {
      console.error('Quick save error:', err);
    } finally {
      setSaving(false);
    }
  };

  const isFormValid = (): boolean => {
    if (!activeAction) return false;
    if (activeAction === 'riego') return !!form.parcela_id && form.cantidad_litros != null;
    if (activeAction === 'fertilizacion') return !!form.parcela_id && !!form.producto;
    if (activeAction === 'plaga') return !!form.parcela_id && !!form.tipo_plaga;
    if (activeAction === 'cosecha') return !!form.parcela_id && form.cantidad_libras != null;
    if (activeAction === 'venta') return !!form.cliente_id && form.total != null;
    if (activeAction === 'compra') return form.monto_total != null;
    if (activeAction === 'gasto') return form.monto != null;
    if (activeAction === 'trabajador') return !!form.nombre;
    if (activeAction === 'siembra') return !!form.parcela_id;
    return false;
  };

  const moneda = data.config?.moneda || 'RD$';

  return (
    <>
      {/* FAB */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
        {menuOpen && (
          <>
            <div className="fixed inset-0 bg-slate-900/30 backdrop-blur-sm z-40" onClick={() => setMenuOpen(false)} />
            <div className="relative z-50 flex flex-col items-end gap-2.5 mb-2">
              {ACTIONS.map((a, i) => (
                <button
                  key={a.type}
                  onClick={() => openAction(a.type)}
                  className="flex items-center gap-3 group"
                  style={{ animation: `fab-slide 0.3s ease-out ${i * 0.04}s both` }}
                >
                  <span className="text-slate-700 font-semibold text-sm bg-white px-3 py-1.5 rounded-xl shadow-lg opacity-0 group-hover:opacity-100 transition-opacity">
                    {a.label}
                  </span>
                  <span className={`w-12 h-12 rounded-2xl ${a.color} text-white flex items-center justify-center shadow-lg hover:scale-110 transition-transform active:scale-90`}>
                    {a.icon}
                  </span>
                </button>
              ))}
            </div>
          </>
        )}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className={`w-16 h-16 rounded-2xl bg-brand-600 text-white flex items-center justify-center shadow-lg transition-transform duration-300 active:scale-90 z-50 ${menuOpen ? 'rotate-45' : ''}`}
        >
          {menuOpen ? <X size={28} /> : <Plus size={32} />}
        </button>
      </div>

      <style>{`
        @keyframes fab-slide { from { opacity: 0; transform: translateY(20px) scale(0.8); } to { opacity: 1; transform: translateY(0) scale(1); } }
        @keyframes modal-pop { from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: scale(1); } }
      `}</style>

      {/* Quick Modal */}
      {activeAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={closeModal} />
          <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-md p-6" style={{ animation: 'modal-pop 0.25s ease-out' }}>
            {saved ? (
              <div className="text-center py-12">
                <div className="inline-flex w-16 h-16 rounded-full bg-green-100 items-center justify-center mb-4">
                  <Check className="text-green-600" size={32} />
                </div>
                <p className="text-xl font-bold text-slate-800">¡Registrado!</p>
                <p className="text-slate-400 text-sm mt-1">Tu registro se guardó correctamente</p>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-slate-800">
                    {ACTIONS.find(a => a.type === activeAction)?.label}
                  </h3>
                  <button onClick={closeModal} className="text-slate-400 hover:text-slate-600 p-1">
                    <X size={22} />
                  </button>
                </div>
                <div className="space-y-4">
                  {/* RIEGO */}
                  {activeAction === 'riego' && (
                    <>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Parcela</label>
                        <select className={inputClass} value={(form.parcela_id as string) || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value })}>
                          <option value="">Seleccionar...</option>
                          {data.parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Cantidad de litros</label>
                        <input type="number" className={inputClass} placeholder="0" value={(form.cantidad_litros as number) || ''} onChange={e => setForm({ ...form, cantidad_litros: +e.target.value })} />
                      </div>
                    </>
                  )}
                  {/* FERTILIZACION */}
                  {activeAction === 'fertilizacion' && (
                    <>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Parcela</label>
                        <select className={inputClass} value={(form.parcela_id as string) || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value })}>
                          <option value="">Seleccionar...</option>
                          {data.parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Producto</label>
                        <input className={inputClass} placeholder="Ej: NPK 15-15-15" value={(form.producto as string) || ''} onChange={e => setForm({ ...form, producto: e.target.value })} />
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Cantidad (lb)</label>
                        <input type="number" className={inputClass} placeholder="0" value={(form.cantidad as number) || ''} onChange={e => setForm({ ...form, cantidad: +e.target.value, unidad: 'lb' })} />
                      </div>
                    </>
                  )}
                  {/* PLAGA */}
                  {activeAction === 'plaga' && (
                    <>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Parcela</label>
                        <select className={inputClass} value={(form.parcela_id as string) || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value })}>
                          <option value="">Seleccionar...</option>
                          {data.parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Tipo de plaga</label>
                        <input className={inputClass} placeholder="Ej: Áfidos" value={(form.tipo_plaga as string) || ''} onChange={e => setForm({ ...form, tipo_plaga: e.target.value })} />
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Severidad</label>
                        <select className={inputClass} value={(form.severidad as string) || 'baja'} onChange={e => setForm({ ...form, severidad: e.target.value })}>
                          <option value="baja">Baja</option><option value="media">Media</option><option value="alta">Alta</option>
                        </select>
                      </div>
                    </>
                  )}
                  {/* COSECHA */}
                  {activeAction === 'cosecha' && (
                    <>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Parcela</label>
                        <select className={inputClass} value={(form.parcela_id as string) || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value })}>
                          <option value="">Seleccionar...</option>
                          {data.parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Cantidad (libras)</label>
                        <input type="number" className={inputClass} placeholder="0" value={(form.cantidad_libras as number) || ''} onChange={e => setForm({ ...form, cantidad_libras: +e.target.value })} />
                      </div>
                    </>
                  )}
                  {/* VENTA */}
                  {activeAction === 'venta' && (
                    <>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Cliente</label>
                        <select className={inputClass} value={(form.cliente_id as string) || ''} onChange={e => setForm({ ...form, cliente_id: e.target.value })}>
                          <option value="">Seleccionar...</option>
                          {data.clientes.map(c => <option key={c.id} value={c.id}>{c.nombre}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Total ({moneda})</label>
                        <input type="number" step="0.01" className={inputClass} placeholder="0.00" value={(form.total as number) || ''} onChange={e => setForm({ ...form, total: +e.target.value, estado_pago: 'pagado' })} />
                      </div>
                    </>
                  )}
                  {/* COMPRA */}
                  {activeAction === 'compra' && (
                    <>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Descripción</label>
                        <input className={inputClass} placeholder="¿Qué compraste?" value={(form.descripcion as string) || ''} onChange={e => setForm({ ...form, descripcion: e.target.value, metodo_pago: 'efectivo' })} />
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Monto total ({moneda})</label>
                        <input type="number" step="0.01" className={inputClass} placeholder="0.00" value={(form.monto_total as number) || ''} onChange={e => setForm({ ...form, monto_total: +e.target.value, cantidad: 1 })} />
                      </div>
                    </>
                  )}
                  {/* GASTO */}
                  {activeAction === 'gasto' && (
                    <>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Categoría</label>
                        <select className={inputClass} value={(form.categoria as string) || ''} onChange={e => setForm({ ...form, categoria: e.target.value })}>
                          {Object.keys(GASTO_SUBCATEGORIAS).map(g => <option key={g} value={g}>{g}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Subcategoría</label>
                        <select className={inputClass} value={(form.subcategoria as string) || ''} onChange={e => setForm({ ...form, subcategoria: e.target.value })}>
                          <option value="">Seleccionar...</option>
                          {GASTO_SUBCATEGORIAS[(form.categoria as string) || 'Inversión inicial']?.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Monto ({moneda})</label>
                        <input type="number" step="0.01" className={inputClass} placeholder="0.00" value={(form.monto as number) || ''} onChange={e => setForm({ ...form, monto: +e.target.value })} />
                      </div>
                    </>
                  )}
                  {/* TRABAJADOR */}
                  {activeAction === 'trabajador' && (
                    <>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Nombre</label>
                        <input className={inputClass} placeholder="Nombre del trabajador" value={(form.nombre as string) || ''} onChange={e => setForm({ ...form, nombre: e.target.value, rol: 'jornalero', activo: true, fecha_ingreso: todayISO() })} />
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Jornal diario ({moneda})</label>
                        <input type="number" step="0.01" className={inputClass} placeholder="0.00" value={(form.jornal_diario as number) || ''} onChange={e => setForm({ ...form, jornal_diario: +e.target.value })} />
                      </div>
                    </>
                  )}
                  {/* SIEMBRA */}
                  {activeAction === 'siembra' && (
                    <>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Parcela</label>
                        <select className={inputClass} value={(form.parcela_id as string) || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value })}>
                          <option value="">Seleccionar...</option>
                          {data.parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-slate-600 mb-1.5 block">Notas</label>
                        <input className={inputClass} placeholder="Ej: 500 plantas de ají" value={(form.observaciones as string) || ''} onChange={e => setForm({ ...form, observaciones: e.target.value })} />
                      </div>
                    </>
                  )}
                </div>
                <button
                  onClick={save}
                  disabled={!isFormValid() || saving}
                  className="mt-6 w-full bg-brand-600 text-white font-bold text-lg py-4 rounded-2xl disabled:opacity-40 transition-transform active:scale-95 flex items-center justify-center gap-2"
                >
                  {saving ? 'Guardando...' : <>Guardar <ChevronRight size={20} /></>}
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}
