import { useState, useRef, useEffect } from 'react';
import { Leaf, Phone, User, Mail, Lock, ArrowRight, Check, ChevronLeft, Delete } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Profile } from '../lib/types';

export function Onboarding({ onComplete }: { onComplete: (profile: Profile) => void }) {
  const [step, setStep] = useState(0);
  const [telefono, setTelefono] = useState('');
  const [nombre, setNombre] = useState('');
  const [pin, setPin] = useState('');
  const [email, setEmail] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const phoneRef = useRef<HTMLInputElement>(null);
  const nameRef = useRef<HTMLInputElement>(null);
  const emailRef = useRef<HTMLInputElement>(null);
  const completedRef = useRef(false);

  useEffect(() => {
    if (step === 1) setTimeout(() => phoneRef.current?.focus(), 100);
    if (step === 2) setTimeout(() => nameRef.current?.focus(), 100);
    if (step === 4) setTimeout(() => emailRef.current?.focus(), 100);
  }, [step]);

  const formatPhone = (raw: string) => {
    const digits = raw.replace(/\D/g, '').slice(0, 10);
    if (digits.length <= 3) return digits;
    if (digits.length <= 6) return `(${digits.slice(0, 3)}) ${digits.slice(3)}`;
    return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
  };

  const handlePhoneChange = (v: string) => {
    setTelefono(formatPhone(v));
    setError('');
  };

  const canProceed = () => {
    if (step === 1) return telefono.replace(/\D/g, '').length === 10;
    if (step === 2) return nombre.trim().length >= 2;
    if (step === 3) return pin.length === 4;
    return true;
  };

  const next = () => {
    if (step < 4 && canProceed()) { setStep(step + 1); setError(''); }
    else if (step === 4) finish();
  };

  const finish = async () => {
    setSaving(true);
    setError('');
    try {
      const digits = telefono.replace(/\D/g, '');
      const e164 = `+1${digits}`;
      const { data, error: dbError } = await supabase
        .from('profiles')
        .insert({ telefono: e164, nombre: nombre.trim(), email: email.trim() || null, pin })
        .select()
        .single();
      if (dbError) throw dbError;
      if (data) {
        localStorage.setItem('mi-tierra-profile-id', data.id);
        setStep(5);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al registrar');
      setSaving(false);
    }
  };

  useEffect(() => {
    if (step === 5 && !completedRef.current) {
      completedRef.current = true;
      const timer = setTimeout(() => {
        const id = localStorage.getItem('mi-tierra-profile-id');
        if (id) onComplete({ id, telefono: `+1${telefono.replace(/\D/g, '')}`, nombre: nombre.trim(), email: email.trim() || null, pin, created_at: new Date().toISOString() });
      }, 1900);
      return () => clearTimeout(timer);
    }
  }, [step]);

  const pressKey = (k: string) => {
    if (pin.length < 4) { setPin(pin + k); setError(''); }
    if (pin.length === 3) setTimeout(() => { setStep(4); }, 400);
  };
  const deleteKey = () => setPin(pin.slice(0, -1));

  return (
    <div className="fixed inset-0 bg-brand-700 flex items-center justify-center overflow-hidden">
      <style>{`
        @keyframes onb-fade-in { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes onb-pop { 0% { transform: scale(0); } 60% { transform: scale(1.15); } 100% { transform: scale(1); } }
        @keyframes onb-ring { from { width: 60px; height: 60px; opacity: 0.5; } to { width: 200px; height: 200px; opacity: 0; } }
        .onb-fade-in { animation: onb-fade-in 0.4s ease-out; }
        .onb-pop { animation: onb-pop 0.5s cubic-bezier(0.34, 1.56, 0.64, 1); }
        .onb-ring { animation: onb-ring 1.5s ease-out infinite; }
      `}</style>

      <div className="relative z-10 w-full max-w-md px-6">
        {step > 0 && step < 5 && (
          <button onClick={() => setStep(step - 1)} className="absolute -top-2 left-6 text-white/80 hover:text-white transition-colors">
            <ChevronLeft size={28} />
          </button>
        )}

        {/* Step 0: Welcome */}
        {step === 0 && (
          <div className="text-center onb-fade-in">
            <div className="inline-flex w-20 h-20 rounded-3xl bg-white/15 backdrop-blur items-center justify-center mb-6 shadow-2xl onb-pop">
              <Leaf className="text-white" size={40} />
            </div>
            <h1 className="text-4xl font-extrabold text-white tracking-tight">Mi Tierra</h1>
            <p className="text-white/80 text-lg mt-3">La administración de tu finca, simple.</p>
            <button onClick={() => setStep(1)} className="mt-10 w-full bg-white text-green-700 font-bold text-lg py-4 rounded-2xl shadow-xl hover:shadow-2xl transition-all active:scale-95 flex items-center justify-center gap-2">
              Comenzar <ArrowRight size={20} />
            </button>
            <p className="text-white/50 text-xs mt-6">Solo toma 30 segundos</p>
          </div>
        )}

        {/* Step 1: Phone */}
        {step === 1 && (
          <div className="onb-fade-in">
            <div className="flex items-center gap-3 mb-2 text-white/60">
              <Phone size={20} />
              <span className="text-sm font-medium">Paso 1 de 4</span>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Tu número de teléfono</h2>
            <p className="text-white/60 text-sm mb-8">Lo usamos para identificar tu cuenta. No spam.</p>
            <div className="flex items-center gap-3 bg-white rounded-2xl px-4 py-4 shadow-xl">
              <span className="text-slate-400 font-semibold text-lg whitespace-nowrap">+1</span>
              <input
                ref={phoneRef}
                type="tel"
                inputMode="numeric"
                value={telefono}
                onChange={e => handlePhoneChange(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && next()}
                placeholder="(809) 000-0000"
                className="flex-1 text-lg font-semibold text-slate-800 outline-none bg-transparent"
              />
            </div>
            {error && <p className="text-red-200 text-sm mt-3">{error}</p>}
            <button onClick={next} disabled={!canProceed()} className="mt-6 w-full bg-white text-green-700 font-bold text-lg py-4 rounded-2xl shadow-xl disabled:opacity-40 transition-all active:scale-95 flex items-center justify-center gap-2">
              Continuar <ArrowRight size={20} />
            </button>
          </div>
        )}

        {/* Step 2: Name */}
        {step === 2 && (
          <div className="onb-fade-in">
            <div className="flex items-center gap-3 mb-2 text-white/60">
              <User size={20} />
              <span className="text-sm font-medium">Paso 2 de 4</span>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">¿Cómo te llamas?</h2>
            <p className="text-white/60 text-sm mb-8">Tu nombre aparecerá en la app.</p>
            <div className="flex items-center gap-3 bg-white rounded-2xl px-4 py-4 shadow-xl">
              <User className="text-slate-400" size={20} />
              <input
                ref={nameRef}
                type="text"
                value={nombre}
                onChange={e => setNombre(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && next()}
                placeholder="Tu nombre"
                className="flex-1 text-lg font-semibold text-slate-800 outline-none bg-transparent"
              />
            </div>
            <button onClick={next} disabled={!canProceed()} className="mt-6 w-full bg-white text-green-700 font-bold text-lg py-4 rounded-2xl shadow-xl disabled:opacity-40 transition-all active:scale-95 flex items-center justify-center gap-2">
              Continuar <ArrowRight size={20} />
            </button>
          </div>
        )}

        {/* Step 3: PIN */}
        {step === 3 && (
          <div className="onb-fade-in">
            <div className="flex items-center gap-3 mb-2 text-white/60">
              <Lock size={20} />
              <span className="text-sm font-medium">Paso 3 de 4</span>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Crea un PIN de 4 dígitos</h2>
            <p className="text-white/60 text-sm mb-8">Para entrar rápido a tu cuenta.</p>
            <div className="flex items-center justify-center gap-4 mb-8">
              {[0, 1, 2, 3].map(i => (
                <div key={i} className={`w-4 h-4 rounded-full transition-all duration-200 ${i < pin.length ? 'bg-white scale-125' : 'bg-white/25'}`} />
              ))}
            </div>
            <div className="grid grid-cols-3 gap-3">
              {['1','2','3','4','5','6','7','8','9'].map(k => (
                <button key={k} onClick={() => pressKey(k)} className="bg-white/10 backdrop-blur text-white text-2xl font-bold py-5 rounded-2xl hover:bg-white/20 transition-all active:scale-90">
                  {k}
                </button>
              ))}
              <div />
              <button onClick={() => pressKey('0')} className="bg-white/10 backdrop-blur text-white text-2xl font-bold py-5 rounded-2xl hover:bg-white/20 transition-all active:scale-90">0</button>
              <button onClick={deleteKey} disabled={pin.length === 0} className="bg-white/10 backdrop-blur text-white py-5 rounded-2xl hover:bg-white/20 transition-all active:scale-90 disabled:opacity-30">
                <Delete size={24} className="mx-auto" />
              </button>
            </div>
          </div>
        )}

        {/* Step 4: Email (optional) */}
        {step === 4 && (
          <div className="onb-fade-in">
            <div className="flex items-center gap-3 mb-2 text-white/60">
              <Mail size={20} />
              <span className="text-sm font-medium">Paso 4 de 4 (opcional)</span>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">¿Tu correo? (opcional)</h2>
            <p className="text-white/60 text-sm mb-8">Para respaldos y reportes PDF. Puedes saltarte este paso.</p>
            <div className="flex items-center gap-3 bg-white rounded-2xl px-4 py-4 shadow-xl">
              <Mail className="text-slate-400" size={20} />
              <input
                ref={emailRef}
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && finish()}
                placeholder="correo@ejemplo.com"
                className="flex-1 text-lg font-semibold text-slate-800 outline-none bg-transparent"
              />
            </div>
            {error && <p className="text-red-200 text-sm mt-3">{error}</p>}
            <button onClick={finish} disabled={saving} className="mt-6 w-full bg-white text-green-700 font-bold text-lg py-4 rounded-2xl shadow-xl disabled:opacity-50 transition-all active:scale-95 flex items-center justify-center gap-2">
              {saving ? 'Guardando...' : 'Saltar y terminar'} <ArrowRight size={20} />
            </button>
            {email.trim() && (
              <button onClick={finish} disabled={saving} className="mt-3 w-full bg-white/10 border-2 border-white/30 text-white font-semibold text-base py-3 rounded-2xl transition-all active:scale-95">
                Guardar correo
              </button>
            )}
          </div>
        )}

        {/* Step 5: Success */}
        {step === 5 && (
          <div className="text-center onb-fade-in">
            <div className="relative inline-flex items-center justify-center mb-6">
              <div className="absolute onb-ring rounded-full bg-white/20" />
              <div className="relative w-20 h-20 rounded-full bg-white flex items-center justify-center onb-pop shadow-2xl">
                <Check className="text-green-600" size={40} />
              </div>
            </div>
            <h2 className="text-3xl font-extrabold text-white">¡Listo!</h2>
            <p className="text-white/80 text-lg mt-2">Bienvenido a Mi Tierra{nombre ? `, ${nombre.split(' ')[0]}` : ''}</p>
          </div>
        )}

        {/* Progress dots */}
        {step > 0 && step < 5 && (
          <div className="flex items-center justify-center gap-2 mt-10">
            {[1, 2, 3, 4].map(s => (
              <div key={s} className={`h-2 rounded-full transition-all duration-300 ${s === step ? 'w-8 bg-white' : s < step ? 'w-2 bg-white/60' : 'w-2 bg-white/25'}`} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
