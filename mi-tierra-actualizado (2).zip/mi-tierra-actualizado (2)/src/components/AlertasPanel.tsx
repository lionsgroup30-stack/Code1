import { useState } from 'react';
import { AlertTriangle, Info, Bell, CheckCircle2 } from 'lucide-react';
import type { Alerta, AlertaSeveridad } from '../lib/alerts';
import { Modal } from './ui';

export function AlertasPanel({ open, onClose, alertas }: { open: boolean; onClose: () => void; alertas: Alerta[] }) {
  const [filtro, setFiltro] = useState<'todas' | AlertaSeveridad>('todas');
  const filtradas = filtro === 'todas' ? alertas : alertas.filter(a => a.severidad === filtro);
  const counts = {
    critica: alertas.filter(a => a.severidad === 'critica').length,
    advertencia: alertas.filter(a => a.severidad === 'advertencia').length,
    info: alertas.filter(a => a.severidad === 'info').length,
  };

  return (
    <Modal open={open} onClose={onClose} title="Centro de Alertas Inteligentes" size="lg">
      <div className="flex gap-2 mb-4">
        <FilterChip active={filtro === 'todas'} onClick={() => setFiltro('todas')} label={`Todas (${alertas.length})`} />
        <FilterChip active={filtro === 'critica'} onClick={() => setFiltro('critica')} label={`Críticas (${counts.critica})`} color="red" />
        <FilterChip active={filtro === 'advertencia'} onClick={() => setFiltro('advertencia')} label={`Advertencias (${counts.advertencia})`} color="amber" />
        <FilterChip active={filtro === 'info'} onClick={() => setFiltro('info')} label={`Info (${counts.info})`} color="blue" />
      </div>

      {filtradas.length === 0 ? (
        <div className="flex flex-col items-center py-12 text-center">
          <CheckCircle2 className="text-brand-500" size={48} />
          <p className="text-lg font-semibold text-slate-700 mt-3">Sin alertas</p>
          <p className="text-sm text-slate-400">Todo funciona correctamente</p>
        </div>
      ) : (
        <div className="space-y-3 max-h-[60vh] overflow-y-auto">
          {filtradas.map(a => <AlertaRow key={a.id} alerta={a} />)}
        </div>
      )}
    </Modal>
  );
}

function FilterChip({ active, onClick, label, color = 'slate' }: { active: boolean; onClick: () => void; label: string; color?: string }) {
  const colors: Record<string, string> = {
    slate: active ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600',
    red: active ? 'bg-red-600 text-white' : 'bg-red-50 text-red-600',
    amber: active ? 'bg-amber-600 text-white' : 'bg-amber-50 text-amber-600',
    blue: active ? 'bg-blue-600 text-white' : 'bg-blue-50 text-blue-600',
  };
  return <button onClick={onClick} className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors ${colors[color]}`}>{label}</button>;
}

function AlertaRow({ alerta }: { alerta: Alerta }) {
  const config: Record<AlertaSeveridad, { icon: typeof AlertTriangle; bg: string; border: string; iconColor: string }> = {
    critica: { icon: AlertTriangle, bg: 'bg-red-50', border: 'border-red-200', iconColor: 'text-red-600' },
    advertencia: { icon: Bell, bg: 'bg-amber-50', border: 'border-amber-200', iconColor: 'text-amber-600' },
    info: { icon: Info, bg: 'bg-blue-50', border: 'border-blue-200', iconColor: 'text-blue-600' },
  };
  const c = config[alerta.severidad];
  const Icon = c.icon;
  return (
    <div className={`flex gap-3 p-4 rounded-xl border ${c.bg} ${c.border}`}>
      <Icon className={`shrink-0 ${c.iconColor}`} size={20} />
      <div className="min-w-0 flex-1">
        <p className="font-semibold text-slate-800 text-sm">{alerta.titulo}</p>
        <p className="text-sm text-slate-600 mt-0.5">{alerta.mensaje}</p>
        {alerta.dias_restantes !== undefined && (
          <p className="text-xs text-slate-400 mt-1">
            {alerta.dias_restantes < 0 ? `Vencido hace ${Math.abs(alerta.dias_restantes)} días` : `En ${alerta.dias_restantes} días`}
          </p>
        )}
      </div>
    </div>
  );
}
