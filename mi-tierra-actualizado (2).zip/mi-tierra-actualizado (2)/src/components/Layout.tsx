import { type ReactNode, useState, useMemo } from 'react';
import {
  LayoutDashboard, Sprout, Trees, Rows, Wheat, ShoppingBasket,
  CalendarDays, Moon, Droplets, FlaskConical, Bug, Package, Wrench, Truck,
  Wallet, ShoppingCart, Users, Store, Coffee,
  FileBarChart, Settings, Brain, Menu, Bell, Leaf, ChevronDown,
  HardHat, MoveRight, Grid2x2, ShoppingBag, CloudSun, Target, Cpu,
  TrendingUp, Layers, Wrench as Equipos,
} from 'lucide-react';
import { useData } from '../lib/DataContext';
import { generarAlertas } from '../lib/alerts';
import { calcDashboard, calcSemaforoFinanciero } from '../lib/calculations';
import { Semaforo } from './ui';

export type PageKey =
  | 'dashboard' | 'semilleros' | 'trasplantes' | 'cultivos' | 'parcelas' | 'lotes'
  | 'filas' | 'produccion' | 'cosechas' | 'calendario' | 'lunar' | 'clima' | 'metas'
  | 'riego' | 'fertilizacion' | 'plagas' | 'inventario' | 'herramientas'
  | 'vehiculos' | 'trabajadores' | 'gastos' | 'ventas' | 'compras' | 'clientes'
  | 'mercados' | 'cacao' | 'reportes' | 'centrointeligencia'
  | 'asistente' | 'configuracion';

interface NavItem { key: PageKey; label: string; icon: ReactNode; group: string }

const NAV: NavItem[] = [
  { key: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} />, group: 'Principal' },
  { key: 'centrointeligencia', label: 'Centro de Inteligencia', icon: <Cpu size={18} />, group: 'Principal' },
  { key: 'asistente', label: 'Asistente IA', icon: <Brain size={18} />, group: 'Principal' },
  { key: 'semilleros', label: 'Semilleros', icon: <Sprout size={18} />, group: 'Producción' },
  { key: 'trasplantes', label: 'Trasplantes', icon: <MoveRight size={18} />, group: 'Producción' },
  { key: 'cultivos', label: 'Cultivos', icon: <Leaf size={18} />, group: 'Producción' },
  { key: 'parcelas', label: 'Parcelas', icon: <Trees size={18} />, group: 'Producción' },
  { key: 'lotes', label: 'Lotes', icon: <Grid2x2 size={18} />, group: 'Producción' },
  { key: 'filas', label: 'Filas', icon: <Rows size={18} />, group: 'Producción' },
  { key: 'produccion', label: 'Producción', icon: <Wheat size={18} />, group: 'Producción' },
  { key: 'cosechas', label: 'Cosechas', icon: <ShoppingBasket size={18} />, group: 'Producción' },
  { key: 'calendario', label: 'Calendario Agrícola', icon: <CalendarDays size={18} />, group: 'Planificación' },
  { key: 'lunar', label: 'Calendario Lunar', icon: <Moon size={18} />, group: 'Planificación' },
  { key: 'clima', label: 'Clima', icon: <CloudSun size={18} />, group: 'Planificación' },
  { key: 'metas', label: 'Planificador de Metas', icon: <Target size={18} />, group: 'Planificación' },
  { key: 'riego', label: 'Riego', icon: <Droplets size={18} />, group: 'Operaciones' },
  { key: 'fertilizacion', label: 'Fertilización', icon: <FlaskConical size={18} />, group: 'Operaciones' },
  { key: 'plagas', label: 'Plagas', icon: <Bug size={18} />, group: 'Operaciones' },
  { key: 'inventario', label: 'Inventario', icon: <Package size={18} />, group: 'Operaciones' },
  { key: 'herramientas', label: 'Equipos', icon: <Equipos size={18} />, group: 'Operaciones' },
  { key: 'vehiculos', label: 'Vehículos', icon: <Truck size={18} />, group: 'Operaciones' },
  { key: 'trabajadores', label: 'Trabajadores', icon: <HardHat size={18} />, group: 'Operaciones' },
  { key: 'gastos', label: 'Gastos', icon: <Wallet size={18} />, group: 'Finanzas' },
  { key: 'ventas', label: 'Ventas', icon: <ShoppingCart size={18} />, group: 'Finanzas' },
  { key: 'compras', label: 'Compras', icon: <ShoppingBag size={18} />, group: 'Finanzas' },
  { key: 'clientes', label: 'Clientes', icon: <Users size={18} />, group: 'Finanzas' },
  { key: 'mercados', label: 'Mercados', icon: <Store size={18} />, group: 'Finanzas' },
  { key: 'cacao', label: 'Cacao', icon: <Coffee size={18} />, group: 'Especial' },
  { key: 'reportes', label: 'Reportes', icon: <FileBarChart size={18} />, group: 'Sistema' },
  { key: 'configuracion', label: 'Configuración', icon: <Settings size={18} />, group: 'Sistema' },
];

const GROUPS = ['Principal', 'Producción', 'Planificación', 'Operaciones', 'Finanzas', 'Especial', 'Sistema'];
const COLLAPSIBLE_GROUPS = ['Producción', 'Planificación', 'Operaciones', 'Finanzas'];

export function Layout({ current, onNavigate, children, onToggleAlerts }: {
  current: PageKey;
  onNavigate: (key: PageKey) => void;
  children: ReactNode;
  onToggleAlerts: () => void;
}) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const data = useData();

  const alertas = useMemo(() => {
    if (!data.config) return [];
    return generarAlertas({
      parcelas: data.parcelas, cosechas: data.cosechas, gastos: data.gastos,
      inventario: data.inventario, ventas: data.ventas, prestamos: data.prestamos,
      semilleros: data.semilleros, plagas: data.plagas, riego: data.riego,
      metas: data.metas, trasplantes: data.trasplantes, trabajadores: data.trabajadores,
      config: data.config,
    });
  }, [data]);

  const alertasCriticas = alertas.filter(a => a.severidad === 'critical').length;
  const currentItem = NAV.find(n => n.key === current);
  const activeGroup = currentItem?.group ?? '';

  const toggleGroup = (group: string) => {
    setCollapsed(prev => {
      const next = new Set(prev);
      if (next.has(group)) next.delete(group);
      else next.add(group);
      return next;
    });
  };

  const isGroupOpen = (group: string) => {
    if (!COLLAPSIBLE_GROUPS.includes(group)) return true;
    if (activeGroup === group) return true;
    return !collapsed.has(group);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <aside className={`fixed lg:sticky top-0 left-0 z-40 h-screen w-72 bg-white border-r border-slate-200 flex flex-col transition-transform duration-300 ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="px-5 py-5 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-brand-600 flex items-center justify-center">
              <Leaf className="text-white" size={22} />
            </div>
            <div>
              <h1 className="font-bold text-slate-900 text-lg leading-tight">Mi Tierra</h1>
              <p className="text-xs text-slate-400">{data.profile?.nombre || data.config?.nombre_finca || 'Mi Finca'}</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-3 px-3 space-y-2">
          {GROUPS.map(group => {
            const items = NAV.filter(n => n.group === group);
            const open = isGroupOpen(group);
            const collapsible = COLLAPSIBLE_GROUPS.includes(group);
            return (
              <div key={group}>
                <button
                  onClick={() => collapsible && toggleGroup(group)}
                  className={`w-full flex items-center justify-between px-3 py-1.5 text-xs font-bold text-slate-400 uppercase tracking-wider ${collapsible ? 'hover:text-slate-600 cursor-pointer' : 'cursor-default'}`}
                >
                  <span>{group}</span>
                  {collapsible && (
                    <ChevronDown size={14} className={`transition-transform duration-200 ${open ? '' : '-rotate-90'}`} />
                  )}
                </button>
                {open && (
                  <div className="space-y-0.5 mt-0.5">
                    {items.map(item => {
                      const active = current === item.key;
                      const badge = item.key === 'asistente' && alertasCriticas > 0 ? alertasCriticas : 0;
                      return (
                        <button
                          key={item.key}
                          onClick={() => { onNavigate(item.key); setMobileOpen(false); }}
                          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                            active ? 'bg-brand-50 text-brand-700 shadow-sm' : 'text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          <span className={active ? 'text-brand-600' : 'text-slate-400'}>{item.icon}</span>
                          <span className="flex-1 text-left">{item.label}</span>
                          {badge > 0 && (
                            <span className="px-1.5 py-0.5 text-xs font-bold bg-red-500 text-white rounded-full">{badge}</span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        <div className="px-5 py-3 border-t border-slate-100">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="w-2 h-2 rounded-full bg-brand-500 animate-pulse" />
            <span>Datos en tiempo real</span>
          </div>
        </div>
      </aside>

      {mobileOpen && <div className="fixed inset-0 bg-slate-900/30 z-30 lg:hidden" onClick={() => setMobileOpen(false)} />}

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-20 bg-white/80 backdrop-blur-md border-b border-slate-200">
          <div className="flex items-center justify-between px-4 sm:px-6 py-3.5">
            <div className="flex items-center gap-3">
              <button onClick={() => setMobileOpen(true)} className="lg:hidden p-2 rounded-lg hover:bg-slate-100 text-slate-600">
                <Menu size={20} />
              </button>
              <div className="flex items-center gap-2">
                <span className="text-slate-400">{currentItem?.icon}</span>
                <h2 className="text-lg font-bold text-slate-900">{currentItem?.label}</h2>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="hidden sm:block">
                {data.config && <SemaforoEstadoFinanciero />}
              </div>
              <button
                onClick={onToggleAlerts}
                className="relative p-2.5 rounded-xl hover:bg-slate-100 text-slate-600 transition-colors"
              >
                <Bell size={20} />
                {alertasCriticas > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 flex items-center justify-center text-[10px] font-bold bg-red-500 text-white rounded-full">
                    {alertasCriticas}
                  </span>
                )}
              </button>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 max-w-[1600px] w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

function SemaforoEstadoFinanciero() {
  const data = useData();
  if (!data.config) return null;

  const kpis = calcDashboard(
    data.ventas, data.gastos, data.cosechas, data.inventario, data.clientes,
    data.prestamos, data.config, data.parcelas, data.filas, data.viajes,
    data.vehiculos, data.mercados, data.trabajadores, 0,
  );
  const sf = calcSemaforoFinanciero(kpis, data.config);
  const label = sf.estado === 'verde' ? 'Ganando' : sf.estado === 'amarillo' ? 'Riesgo' : 'Perdiendo';
  return <Semaforo estado={sf.estado} label={label} size="sm" />;
}
