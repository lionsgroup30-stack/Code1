import { type ReactNode, useEffect } from 'react';
import { X } from 'lucide-react';

// ============================================================
// KPI CARD
// ============================================================
type AccentColor = 'default' | 'green' | 'red' | 'amber' | 'blue' | 'brand' | 'slate';

function normalizeAccent(c: AccentColor): 'default' | 'green' | 'red' | 'amber' | 'blue' {
  if (c === 'brand') return 'green';
  if (c === 'slate') return 'default';
  return c;
}

export function KpiCard({
  label, value, icon, trend, trendLabel, accent = 'default', subtitle, unit, small,
}: {
  label: string;
  value: string;
  icon?: ReactNode;
  trend?: 'up' | 'down' | 'neutral';
  trendLabel?: string;
  accent?: AccentColor;
  color?: AccentColor;
  subtitle?: string;
  unit?: string;
  small?: boolean;
}) {
  const a = normalizeAccent(accent);
  const accents: Record<string, string> = {
    default: 'bg-slate-50 text-slate-900',
    green: 'bg-brand-50 text-brand-900',
    red: 'bg-red-50 text-red-900',
    amber: 'bg-amber-50 text-amber-900',
    blue: 'bg-blue-50 text-blue-900',
  };
  const iconAccents: Record<string, string> = {
    default: 'bg-slate-100 text-slate-600',
    green: 'bg-brand-100 text-brand-600',
    red: 'bg-red-100 text-red-600',
    amber: 'bg-amber-100 text-amber-600',
    blue: 'bg-blue-100 text-blue-600',
  };
  return (
    <div className={`${accents[a]} rounded-2xl border border-slate-200/60 p-5 transition-colors duration-200`}>
      <div className="flex items-start justify-between">
        <div className="min-w-0 flex-1">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wide truncate">{label}</p>
          <p className={`${small ? 'text-lg' : 'text-2xl'} font-bold mt-1 tabular-nums truncate`}>
            {value}{unit && <span className="text-sm font-normal text-slate-400 ml-1">{unit}</span>}
          </p>
          {subtitle && <p className="text-xs text-slate-400 mt-0.5 truncate">{subtitle}</p>}
        </div>
        {icon && (
          <div className={`shrink-0 w-10 h-10 rounded-xl flex items-center justify-center ${iconAccents[a]}`}>
            {icon}
          </div>
        )}
      </div>
      {trend && trendLabel && (
        <div className="mt-3 flex items-center gap-1.5">
          <span className={`text-xs font-semibold ${trend === 'up' ? 'text-brand-600' : trend === 'down' ? 'text-red-600' : 'text-slate-500'}`}>
            {trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→'} {trendLabel}
          </span>
        </div>
      )}
    </div>
  );
}

// ============================================================
// SEMÁFORO
// ============================================================
export function Semaforo({
  estado, label, size = 'md',
}: {
  estado: 'verde' | 'amarillo' | 'rojo' | 'azul';
  label?: string;
  size?: 'sm' | 'md' | 'lg';
}) {
  const colors: Record<string, { bg: string; dot: string; text: string; ring: string }> = {
    verde: { bg: 'bg-brand-50', dot: 'bg-brand-500', text: 'text-brand-700', ring: 'ring-brand-200' },
    amarillo: { bg: 'bg-amber-50', dot: 'bg-amber-500', text: 'text-amber-700', ring: 'ring-amber-200' },
    rojo: { bg: 'bg-red-50', dot: 'bg-red-500', text: 'text-red-700', ring: 'ring-red-200' },
    azul: { bg: 'bg-blue-50', dot: 'bg-blue-500', text: 'text-blue-700', ring: 'ring-blue-200' },
  };
  const c = colors[estado];
  const sizes = { sm: 'px-2 py-1 text-xs', md: 'px-3 py-1.5 text-sm', lg: 'px-4 py-2 text-base' };
  const dotSizes = { sm: 'w-1.5 h-1.5', md: 'w-2 h-2', lg: 'w-2.5 h-2.5' };
  return (
    <span className={`inline-flex items-center gap-2 rounded-full ${c.bg} ${c.text} ${sizes[size]} font-semibold ring-1 ${c.ring}`}>
      <span className={`${c.dot} ${dotSizes[size]} rounded-full animate-pulse-slow`} />
      {label}
    </span>
  );
}

// ============================================================
// BADGE
// ============================================================
export function Badge({ children, color = 'slate' }: { children: ReactNode; color?: 'slate' | 'green' | 'red' | 'amber' | 'blue' | 'earth' }) {
  const colors: Record<string, string> = {
    slate: 'bg-slate-100 text-slate-700',
    green: 'bg-brand-100 text-brand-700',
    red: 'bg-red-100 text-red-700',
    amber: 'bg-amber-100 text-amber-700',
    blue: 'bg-blue-100 text-blue-700',
    earth: 'bg-earth-100 text-earth-700',
  };
  return <span className={`inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-semibold ${colors[color]}`}>{children}</span>;
}

// ============================================================
// BUTTON
// ============================================================
export function Button({
  children, onClick, variant = 'primary', size = 'md', type = 'button', disabled, className = '',
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  type?: 'button' | 'submit';
  disabled?: boolean;
  className?: string;
}) {
  const variants: Record<string, string> = {
    primary: 'bg-brand-600 text-white hover:bg-brand-700 shadow-sm',
    secondary: 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50',
    ghost: 'text-slate-600 hover:bg-slate-100',
    danger: 'bg-red-600 text-white hover:bg-red-700 shadow-sm',
  };
  const sizes: Record<string, string> = {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-4 py-2 text-sm',
    lg: 'px-5 py-2.5 text-base',
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-all duration-150 disabled:opacity-50 disabled:cursor-not-allowed ${variants[variant]} ${sizes[size]} ${className}`}
    >
      {children}
    </button>
  );
}

// ============================================================
// MODAL
// ============================================================
export function Modal({
  open, onClose, title, children, size = 'md',
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}) {
  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
      return () => { document.body.style.overflow = ''; };
    }
  }, [open]);

  if (!open) return null;
  const sizes: Record<string, string> = {
    sm: 'max-w-md', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl',
  };
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto p-4 sm:p-6">
      <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className={`relative z-10 w-full ${sizes[size]} bg-white rounded-2xl shadow-2xl my-8 animate-slide-up`}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h2 className="text-lg font-bold text-slate-900">{title}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 transition-colors">
            <X size={20} />
          </button>
        </div>
        <div className="px-6 py-5">{children}</div>
      </div>
    </div>
  );
}

// ============================================================
// FORM FIELD
// ============================================================
export function Field({
  label, children, required, hint,
}: {
  label: string;
  children: ReactNode;
  required?: boolean;
  hint?: string;
}) {
  return (
    <div className="space-y-1.5">
      <label className="block text-sm font-semibold text-slate-700">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      {children}
      {hint && <p className="text-xs text-slate-400">{hint}</p>}
    </div>
  );
}

export const inputClass = 'w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent transition-all text-sm';

// ============================================================
// EMPTY STATE
// ============================================================
export function EmptyState({ icon, title, message, action }: { icon?: ReactNode; title: string; message?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      {icon && <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400 mb-4">{icon}</div>}
      <h3 className="text-lg font-semibold text-slate-700">{title}</h3>
      {message && <p className="text-sm text-slate-400 mt-1 max-w-sm">{message}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

// ============================================================
// PAGE HEADER
// ============================================================
export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{title}</h1>
        {subtitle && <p className="text-sm text-slate-500 mt-1">{subtitle}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

// ============================================================
// CARD
// ============================================================
export function Card({ children, className = '', title, action }: { children: ReactNode; className?: string; title?: string; action?: ReactNode }) {
  return (
    <div className={`bg-white rounded-2xl border border-slate-200/70 shadow-sm ${className}`}>
      {(title || action) && (
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          {title && <h3 className="font-bold text-slate-800">{title}</h3>}
          {action}
        </div>
      )}
      {children}
    </div>
  );
}

// ============================================================
// TABLE WRAPPER
// ============================================================
export function Table({ children }: { children: ReactNode }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">{children}</table>
    </div>
  );
}

export function Th({ children, className = '' }: { children?: ReactNode; className?: string }) {
  return <th className={`text-left font-semibold text-slate-500 uppercase text-xs tracking-wide px-4 py-3 ${className}`}>{children}</th>;
}

export function Td({ children, className = '' }: { children?: ReactNode; className?: string }) {
  return <td className={`px-4 py-3 text-slate-700 ${className}`}>{children}</td>;
}

// ============================================================
// STAT BAR (progress)
// ============================================================
export function StatBar({ value, max, color = 'brand', label }: { value: number; max: number; color?: 'brand' | 'amber' | 'red' | 'blue'; label?: string }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  const colors: Record<string, string> = {
    brand: 'bg-brand-500', amber: 'bg-amber-500', red: 'bg-red-500', blue: 'bg-blue-500',
  };
  return (
    <div className="space-y-1">
      {label && <div className="flex justify-between text-xs text-slate-500"><span>{label}</span><span>{pct.toFixed(0)}%</span></div>}
      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
        <div className={`h-full ${colors[color]} rounded-full transition-all duration-500`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

// ============================================================
// LOADING SPINNER
// ============================================================
export function Spinner({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const sizes = { sm: 'w-4 h-4', md: 'w-8 h-8', lg: 'w-12 h-12' };
  return (
    <div className="flex items-center justify-center py-12">
      <div className={`${sizes[size]} border-3 border-brand-200 border-t-brand-600 rounded-full animate-spin`} />
    </div>
  );
}
