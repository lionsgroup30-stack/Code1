import type {
  Parcela, Cosecha, Gasto, Venta, Cliente, Mercado, InventarioItem,
  Configuracion, Semillero, Prestamo, Trabajador, Meta, Compra, Viaje, Vehiculo,
} from './types';
import { daysBetween, startOfMonth, startOfWeek, addDays } from './format';
import {
  calcDashboard, calcSemaforoFinanciero, rentabilidadPorParcela,
  rentabilidadPorMercado, rentabilidadPorTrabajador, parcelaProduccionEsperada,
  parcelaProduccionReal, calcMeta, DashboardKPIs,
} from './calculations';

export interface Recomendacion {
  tipo: 'costos' | 'produccion' | 'comercial' | 'finanzas' | 'inventario' | 'trabajador' | 'metas' | 'alerta';
  prioridad: 'alta' | 'media' | 'baja';
  titulo: string;
  mensaje: string;
  accion: string;
}

interface AssistantInput {
  parcelas: Parcela[];
  cosechas: Cosecha[];
  gastos: Gasto[];
  ventas: Venta[];
  clientes: Cliente[];
  mercados: Mercado[];
  inventario: InventarioItem[];
  semilleros: Semillero[];
  prestamos: Prestamo[];
  trabajadores: Trabajador[];
  metas: Meta[];
  compras: Compra[];
  viajes: Viaje[];
  vehiculos: Vehiculo[];
  config: Configuracion;
  kpis: DashboardKPIs;
  semaforoFinanciero: ReturnType<typeof calcSemaforoFinanciero>;
}

export function generarRecomendaciones(input: AssistantInput): Recomendacion[] {
  const recs: Recomendacion[] = [];
  const now = new Date();
  const sMes = startOfMonth(now);
  const sSem = startOfWeek(now);

  // Semáforo financiero
  if (input.semaforoFinanciero.estado === 'rojo') {
    recs.push({
      tipo: 'finanzas', prioridad: 'alta',
      titulo: 'Pérdida operacional detectada',
      mensaje: `Margen actual ${input.kpis.rentabilidad_pct.toFixed(1)}%. Los gastos superan los ingresos.`,
      accion: 'Reducir costos variables inmediatamente y renegociar precios con clientes',
    });
  } else if (input.semaforoFinanciero.estado === 'amarillo') {
    recs.push({
      tipo: 'finanzas', prioridad: 'media',
      titulo: 'Margen por debajo del objetivo (20%)',
      mensaje: `Margen actual ${input.kpis.rentabilidad_pct.toFixed(1)}%. Objetivo: >20%.`,
      accion: 'Revisar gastos por categoría y buscar reducir costos de transporte e insumos',
    });
  }

  // Costos por parcela
  const rentParcelas = rentabilidadPorParcela(input.parcelas, input.cosechas, input.gastos, input.ventas)
    .sort((a, b) => a.margen_pct - b.margen_pct);
  if (rentParcelas.length > 0 && rentParcelas[0].ganancia < 0) {
    recs.push({
      tipo: 'costos', prioridad: 'alta',
      titulo: 'Parcela en pérdida',
      mensaje: `${rentParcelas[0].nombre} tiene margen de ${rentParcelas[0].margen_pct.toFixed(1)}%.`,
      accion: 'Evaluar si es viable continuar o reasignar recursos a parcelas más rentables',
    });
  }

  // Comparación mensual de costos
  const gastosMesActual = input.gastos.filter(g => new Date(g.fecha) >= sMes).reduce((s, g) => s + g.monto, 0);
  const sMesPrev = new Date(sMes);
  sMesPrev.setMonth(sMesPrev.getMonth() - 1);
  const gastosMesPrev = input.gastos.filter(g => {
    const f = new Date(g.fecha);
    return f >= sMesPrev && f < sMes;
  }).reduce((s, g) => s + g.monto, 0);
  if (gastosMesPrev > 0) {
    const varPct = ((gastosMesActual - gastosMesPrev) / gastosMesPrev) * 100;
    if (varPct > 20) {
      recs.push({
        tipo: 'costos', prioridad: 'alta',
        titulo: 'Costos en aumento',
        mensaje: `Gastos del mes ${varPct > 0 ? 'subieron' : 'cambiaron'} ${Math.abs(varPct).toFixed(0)}% vs mes anterior.`,
        accion: 'Revisar categorías con mayor incremento y negociar con proveedores',
      });
    }
  }

  // Inventario crítico
  const invCritico = input.inventario.filter(i => i.stock_minimo > 0 && i.stock_actual <= i.stock_minimo);
  if (invCritico.length > 0) {
    recs.push({
      tipo: 'inventario', prioridad: invCritico.length > 2 ? 'alta' : 'media',
      titulo: `${invCritico.length} insumo(s) en stock crítico`,
      mensaje: invCritico.map(i => i.nombre).join(', '),
      accion: 'Realizar compra de reposición antes de que afecte la producción',
    });
  }

  // Insumos por vencer
  const porVencer = input.inventario.filter(i => {
    if (!i.fecha_vencimiento) return false;
    const d = daysBetween(now, new Date(i.fecha_vencimiento));
    return d >= 0 && d <= 30;
  });
  if (porVencer.length > 0) {
    recs.push({
      tipo: 'inventario', prioridad: 'media',
      titulo: 'Insumos por vencer',
      mensaje: porVencer.map(i => `${i.nombre} (${daysBetween(now, new Date(i.fecha_vencimiento!))} días)`).join(', '),
      accion: 'Priorizar uso de estos insumos o planificar descarte',
    });
  }

  // Producción por debajo
  input.parcelas.forEach(p => {
    const esperada = parcelaProduccionEsperada(p, []);
    const real = parcelaProduccionReal(p, input.cosechas);
    if (esperada > 0 && real < esperada * 0.5 && input.cosechas.some(c => c.parcela_id === p.id)) {
      recs.push({
        tipo: 'produccion', prioridad: 'alta',
        titulo: `Producción baja en ${p.nombre}`,
        mensaje: `Solo ${((real / esperada) * 100).toFixed(0)}% del objetivo (${real.toFixed(0)}/${esperada.toFixed(0)} libras).`,
        accion: 'Revisar plagas, riego, fertilización y condiciones del cultivo',
      });
    }
  });

  // Mercado más rentable
  const rentMercados = rentabilidadPorMercado(input.ventas, input.mercados).sort((a, b) => b.ganancia - a.ganancia);
  if (rentMercados.length > 1 && rentMercados[0].ganancia > 0) {
    recs.push({
      tipo: 'comercial', prioridad: 'media',
      titulo: 'Mejor mercado identificado',
      mensaje: `${rentMercados[0].nombre} genera la mayor rentabilidad (${rentMercados[0].margen_pct.toFixed(0)}% margen).`,
      accion: `Considerar enviar más producción a ${rentMercados[0].nombre}`,
    });
  }

  // Trabajadores — productividad
  const rentTrab = rentabilidadPorTrabajador(input.trabajadores, input.cosechas, input.gastos)
    .sort((a, b) => a.ganancia - b.ganancia);
  if (rentTrab.length > 0) {
    const peor = rentTrab[0];
    if (peor.ganancia < 0) {
      recs.push({
        tipo: 'trabajador', prioridad: 'media',
        titulo: 'Trabajador con costo negativo',
        mensaje: `${peor.nombre} genera pérdida neta (${peor.ganancia.toFixed(2)}).`,
        accion: 'Revisar asignación de tareas y productividad del trabajador',
      });
    }
    const mejor = rentTrab[rentTrab.length - 1];
    if (mejor.ganancia > 0) {
      recs.push({
        tipo: 'trabajador', prioridad: 'baja',
        titulo: 'Trabajador destacado',
        mensaje: `${mejor.nombre} genera la mayor rentabilidad (${mejor.ganancia.toFixed(2)}).`,
        accion: 'Considerar asignar más responsabilidades o reconocer el desempeño',
      });
    }
  }

  // Metas
  input.metas.forEach(m => {
    if (m.estado === 'activa') {
      const calc = calcMeta(m);
      if (calc.estado === 'atrasada' || calc.estado === 'vencida') {
        recs.push({
          tipo: 'metas', prioridad: calc.estado === 'vencida' ? 'alta' : 'media',
          titulo: `Meta ${calc.estado === 'vencida' ? 'vencida' : 'atrasada'}: ${m.titulo}`,
          mensaje: `${calc.porcentaje_cumplimiento.toFixed(0)}% completada, ${calc.dias_restantes} días restantes.`,
          accion: 'Acelerar actividades para cumplir o replantear el objetivo',
        });
      }
    }
  });

  // Semilleros listos
  input.semilleros.forEach(s => {
    if (s.estado === 'activo') {
      const dias = daysBetween(now, addDays(new Date(s.fecha_siembra), s.dias_para_trasplante));
      if (dias >= 0 && dias <= 7) {
        recs.push({
          tipo: 'produccion', prioridad: dias <= 3 ? 'alta' : 'media',
          titulo: 'Semillero listo para trasplante',
          mensaje: `${s.cultivos?.nombre ?? 'Semillero'}: trasplantar en ${dias} días.`,
          accion: 'Preparar parcelas y filas para recibir las plántulas',
        });
      }
    }
  });

  return recs.sort((a, b) => {
    const order = { alta: 0, media: 1, baja: 2 };
    return order[a.prioridad] - order[b.prioridad];
  });
}
