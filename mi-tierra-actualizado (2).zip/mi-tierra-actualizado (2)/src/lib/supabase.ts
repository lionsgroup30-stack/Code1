import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(url, anonKey, {
  auth: { persistSession: false },
});

export const DB = {
  cultivos: 'cultivos',
  parcelas: 'parcelas',
  filas: 'filas',
  semilleros: 'semilleros',
  cosechas: 'cosechas',
  riego: 'riego',
  fertilizacion: 'fertilizacion',
  plagas: 'plagas',
  inventario: 'inventario',
  herramientas: 'herramientas',
  vehiculos: 'vehiculos',
  viajes: 'viajes',
  gastos: 'gastos',
  ventas: 'ventas',
  clientes: 'clientes',
  mercados: 'mercados',
  bancos: 'bancos',
  transacciones_bancarias: 'transacciones_bancarias',
  prestamos: 'prestamos',
  pagos_prestamos: 'pagos_prestamos',
  cacao_lotes: 'cacao_lotes',
  trabajadores: 'trabajadores',
  lotes: 'lotes',
  trasplantes: 'trasplantes',
  compras: 'compras',
  metas: 'metas',
  profiles: 'profiles',
  configuracion: 'configuracion',
} as const;
