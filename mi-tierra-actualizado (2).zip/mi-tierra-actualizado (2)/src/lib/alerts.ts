import type {
  Cosecha, Gasto, InventarioItem, Plaga, Prestamo, Semillero, Venta, Riego,
  Parcela, Configuracion, Trabajador, Trasplante, Meta,
} from './types';
import { daysBetween, addDays, isSameDay, startOfMonth } from './format';
import { parcelaProduccionEsperada, parcelaProduccionReal } from './calculations';

export type AlertaSeveridad = 'info' | 'warning' | 'critical';
export type AlertaTipo =
  | 'produccion_baja' | 'costos_altos' | 'inventario_bajo' | 'inventario_vencer'
  | 'prestamo_vencido' | 'pago_pendiente' | 'semillero_atrasado'
  | 'semillero_listo' | 'meta_vencida' | 'meta_atrasada' | 'meta_proxima'
  | 'plaga_detectada' | 'riego_atrasado' | 'trasplante_atrasado'
  | 'trasplante_programado' | 'trabajador_inactivo' | 'venta_rechazada';

export interface Alerta {
  id: string;
  tipo: AlertaTipo;
  severidad: AlertaSeveridad;
  titulo: string;
  mensaje: string;
  fecha: string;
  entidad_id?: string;
  entidad_tipo?: string;
}

interface AlertaInput {
  parcelas: Parcela[];
  cosechas: Cosecha[];
  gastos: Gasto[];
  inventario: InventarioItem[];
  ventas: Venta[];
  prestamos: Prestamo[];
  semilleros: Semillero[];
  plagas: Plaga[];
  riego: Riego[];
  metas: Meta[];
  trasplantes: Trasplante[];
  trabajadores: Trabajador[];
  config: Configuracion;
}

export function generarAlertas(input: AlertaInput): Alerta[] {
  const alertas: Alerta[] = [];
  const now = new Date();

  // Producción por debajo del objetivo
  input.parcelas.forEach(p => {
    const esperada = parcelaProduccionEsperada(p, []);
    const real = parcelaProduccionReal(p, input.cosechas);
    if (esperada > 0 && real < esperada * 0.5) {
      alertas.push({
        id: `prod-${p.id}`, tipo: 'produccion_baja', severidad: 'critical',
        titulo: 'Producción crítica', mensaje: `${p.nombre}: ${real.toFixed(0)} / ${esperada.toFixed(0)} libras`,
        fecha: now.toISOString(), entidad_id: p.id, entidad_tipo: 'parcela',
      });
    }
  });

  // Inventario bajo
  input.inventario.forEach(i => {
    if (i.stock_minimo > 0 && i.stock_actual <= i.stock_minimo) {
      alertas.push({
        id: `inv-${i.id}`, tipo: 'inventario_bajo', severidad: 'critical',
        titulo: 'Stock crítico', mensaje: `${i.nombre}: ${i.stock_actual} ${i.unidad} (mín: ${i.stock_minimo})`,
        fecha: now.toISOString(), entidad_id: i.id, entidad_tipo: 'inventario',
      });
    }
    if (i.fecha_vencimiento) {
      const dias = daysBetween(now, new Date(i.fecha_vencimiento));
      if (dias >= 0 && dias <= 30) {
        alertas.push({
          id: `venc-${i.id}`, tipo: 'inventario_vencer', severidad: dias <= 7 ? 'critical' : 'warning',
          titulo: dias <= 7 ? 'Insumo por vencer' : 'Insumo próximo a vencer',
          mensaje: `${i.nombre} vence en ${dias} días (${new Date(i.fecha_vencimiento).toLocaleDateString('es-DO')})`,
          fecha: now.toISOString(), entidad_id: i.id, entidad_tipo: 'inventario',
        });
      }
    }
  });

  // Pagos pendientes
  const pagosPend = input.ventas.filter(v => v.estado_pago === 'pendiente');
  pagosPend.forEach(v => {
    alertas.push({
      id: `pag-${v.id}`, tipo: 'pago_pendiente', severidad: 'warning',
      titulo: 'Pago pendiente', mensaje: `Venta ${v.id.slice(0, 8)} por ${v.total.toFixed(2)}`,
      fecha: now.toISOString(), entidad_id: v.id, entidad_tipo: 'venta',
    });
  });

  // Semilleros
  input.semilleros.forEach(s => {
    if (s.estado === 'activo') {
      const fechaTrasplante = addDays(new Date(s.fecha_siembra), s.dias_para_trasplante);
      const dias = daysBetween(now, fechaTrasplante);
      if (dias < 0) {
        alertas.push({
          id: `sem-${s.id}`, tipo: 'semillero_atrasado', severidad: 'critical',
          titulo: 'Trasplante atrasado', mensaje: `${s.cultivos?.nombre ?? 'Semillero'}: ${Math.abs(dias)} días de retraso`,
          fecha: now.toISOString(), entidad_id: s.id, entidad_tipo: 'semillero',
        });
      } else if (dias <= 7) {
        alertas.push({
          id: `sem-${s.id}`, tipo: 'semillero_listo', severidad: 'info',
          titulo: 'Semillero listo', mensaje: `${s.cultivos?.nombre ?? 'Semillero'}: trasplantar en ${dias} días`,
          fecha: now.toISOString(), entidad_id: s.id, entidad_tipo: 'semillero',
        });
      }
    }
  });

  // Plagas detectadas
  input.plagas.forEach(p => {
    const dias = daysBetween(p.fecha, now);
    if (dias <= 30 && p.severidad === 'alta') {
      alertas.push({
        id: `plaga-${p.id}`, tipo: 'plaga_detectada', severidad: 'critical',
        titulo: 'Plaga severa', mensaje: `${p.tipo_plaga} en ${p.parcelas?.nombre ?? 'parcela'} (${dias} días)`,
        fecha: p.fecha, entidad_id: p.id, entidad_tipo: 'plaga',
      });
    }
  });

  // Riego atrasado
  input.parcelas.forEach(p => {
    if (p.ultima_riego) {
      const dias = daysBetween(new Date(p.ultima_riego), now);
      if (dias > 7) {
        alertas.push({
          id: `riego-${p.id}`, tipo: 'riego_atrasado', severidad: dias > 14 ? 'critical' : 'warning',
          titulo: 'Riego atrasado', mensaje: `${p.nombre}: ${dias} días sin riego`,
          fecha: now.toISOString(), entidad_id: p.id, entidad_tipo: 'parcela',
        });
      }
    }
  });

  // Metas
  input.metas.forEach(m => {
    if (m.estado === 'activa') {
      const pct = m.valor_objetivo > 0 ? (m.valor_actual / m.valor_objetivo) * 100 : 0;
      if (m.fecha_limite) {
        const dias = daysBetween(now, new Date(m.fecha_limite));
        if (dias < 0 && pct < 100) {
          alertas.push({
            id: `meta-${m.id}`, tipo: 'meta_vencida', severidad: 'critical',
            titulo: 'Meta vencida', mensaje: `${m.titulo}: ${pct.toFixed(0)}% completada`,
            fecha: now.toISOString(), entidad_id: m.id, entidad_tipo: 'meta',
          });
        } else if (dias <= 7 && pct < 80) {
          alertas.push({
            id: `meta-${m.id}`, tipo: 'meta_atrasada', severidad: 'warning',
            titulo: 'Meta atrasada', mensaje: `${m.titulo}: ${dias} días restantes, ${pct.toFixed(0)}% completada`,
            fecha: now.toISOString(), entidad_id: m.id, entidad_tipo: 'meta',
          });
        } else if (dias <= 14) {
          alertas.push({
            id: `meta-${m.id}`, tipo: 'meta_proxima', severidad: 'info',
            titulo: 'Meta próxima a vencer', mensaje: `${m.titulo}: ${dias} días restantes`,
            fecha: now.toISOString(), entidad_id: m.id, entidad_tipo: 'meta',
          });
        }
      }
    }
  });

  // Trasplantes próximos o atrasados
  input.trasplantes.forEach(t => {
    const dias = daysBetween(now, new Date(t.fecha));
    if (dias >= 0 && dias <= 3) {
      alertas.push({
        id: `tras-${t.id}`, tipo: 'trasplante_programado', severidad: 'info',
        titulo: 'Trasplante próximo', mensaje: `${t.semilleros?.cultivos?.nombre ?? 'Trasplante'} en ${dias} días`,
        fecha: now.toISOString(), entidad_id: t.id, entidad_tipo: 'trasplante',
      });
    } else if (dias < 0) {
      alertas.push({
        id: `tras-${t.id}`, tipo: 'trasplante_atrasado', severidad: 'warning',
        titulo: 'Trasplante atrasado', mensaje: `${Math.abs(dias)} días de retraso`,
        fecha: now.toISOString(), entidad_id: t.id, entidad_tipo: 'trasplante',
      });
    }
  });

  // Trabajadores inactivos
  input.trabajadores.forEach(t => {
    if (!t.activo) {
      alertas.push({
        id: `trab-${t.id}`, tipo: 'trabajador_inactivo', severidad: 'info',
        titulo: 'Trabajador inactivo', mensaje: `${t.nombre} está marcado como inactivo`,
        fecha: now.toISOString(), entidad_id: t.id, entidad_tipo: 'trabajador',
      });
    }
  });

  return alertas.sort((a, b) => {
    const order = { critical: 0, warning: 1, info: 2 };
    return order[a.severidad] - order[b.severidad];
  });
}
