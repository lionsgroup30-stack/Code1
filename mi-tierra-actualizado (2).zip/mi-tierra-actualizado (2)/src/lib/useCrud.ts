import { useState, useCallback } from 'react';
import { supabase } from './supabase';

export function useCrud<T extends { id: string | number }>(table: string) {
  const [saving, setSaving] = useState(false);

  const insert = useCallback(async (data: Partial<T>): Promise<T | null> => {
    setSaving(true);
    try {
      const { data: result, error } = await supabase.from(table).insert(data).select().single();
      if (error) throw error;
      return result as T;
    } catch (err) {
      console.error(`Insert ${table}:`, err);
      return null;
    } finally {
      setSaving(false);
    }
  }, [table]);

  const update = useCallback(async (id: string | number, data: Partial<T>): Promise<T | null> => {
    setSaving(true);
    try {
      const { data: result, error } = await supabase.from(table).update(data).eq('id', id).select().single();
      if (error) throw error;
      return result as T;
    } catch (err) {
      console.error(`Update ${table}:`, err);
      return null;
    } finally {
      setSaving(false);
    }
  }, [table]);

  const remove = useCallback(async (id: string | number): Promise<boolean> => {
    setSaving(true);
    try {
      const { error } = await supabase.from(table).delete().eq('id', id);
      if (error) throw error;
      return true;
    } catch (err) {
      console.error(`Delete ${table}:`, err);
      return false;
    } finally {
      setSaving(false);
    }
  }, [table]);

  return { insert, update, remove, saving };
}
