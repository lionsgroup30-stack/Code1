export interface Cultivo {
  id: string;
  nombre: string;
  variedad: string | null;
  dias_germinacion: number;
  dias_trasplante: number;
  produccion_esperada_por_planta: number;
  costo_esperado_por_planta: number;
  costo_esperado_por_libra: number;
  margen_objetivo: number;
  color: string | null;
  activo: boolean;
  created_at: string;
}

export interface Parcela {
  id: string;
  nombre: string;
  ubicacion: string | null;
  area_tareas: number;
  area_m2: number;
  cultivo_id: string | null;
  fecha_siembra: string | null;
  estado: string;
  produccion_esperada_total: number;
  precio_esperado_libra: number;
  created_at: string;
  cultivos?: Cultivo | null;
}

export interface Lote {
  id: string;
  parcela_id: string;
  nombre: string;
  area_tareas: number;
  estado: string;
  created_at: string;
  parcelas?: Parcela | null;
}

export interface Fila {
  id: string;
  parcela_id: string;
  lote_id: string | null;
  numero: number;
  etiqueta: string | null;
  cantidad_plantas: number;
  fecha_trasplante: string | null;
  estado: string;
  produccion_esperada_por_planta: number;
  created_at: string;
  parcelas?: Parcela | null;
  lotes?: Lote | null;
}

export interface Semillero {
  id: string;
  cultivo_id: string | null;
  fecha_siembra: string;
  cantidad_semillas: number;
  variedad: string | null;
  numero_bandejas: number;
  sustrato: string | null;
  proveedor: string | null;
  costo: number;
  porcentaje_esperado_germinacion: number;
  semillas_germinadas: number;
  dias_para_trasplante: number;
  observaciones: string | null;
  estado: string;
  created_at: string;
  cultivos?: Cultivo | null;
}

export interface Cosecha {
  id: string;
  parcela_id: string;
  fila_id: string | null;
  trabajador_id: string | null;
  fecha: string;
  cantidad_libras: number;
  precio_por_libra: number;
  mercado_id: string | null;
  observaciones: string | null;
  created_at: string;
  parcelas?: Parcela | null;
  filas?: Fila | null;
  mercados?: Mercado | null;
  trabajadores?: Trabajador | null;
}

export interface Riego {
  id: string;
  parcela_id: string | null;
  fila_id: string | null;
  fecha: string;
  hora: string | null;
  cantidad_litros: number;
  duracion_min: number;
  costo: number;
  trabajador_id: string | null;
  fecha_proximo_riego: string | null;
  observaciones: string | null;
  created_at: string;
  parcelas?: Parcela | null;
  trabajadores?: Trabajador | null;
}

export interface Fertilizacion {
  id: string;
  parcela_id: string | null;
  fila_id: string | null;
  fecha: string;
  producto: string;
  cantidad: number;
  unidad: string;
  costo: number;
  trabajador_id: string | null;
  fecha_proxima_aplicacion: string | null;
  observaciones: string | null;
  created_at: string;
  parcelas?: Parcela | null;
  trabajadores?: Trabajador | null;
}

export interface Plaga {
  id: string;
  parcela_id: string | null;
  fila_id: string | null;
  fecha: string;
  tipo_plaga: string;
  producto: string | null;
  cantidad: number;
  unidad: string;
  costo: number;
  severidad: string;
  foto_url: string | null;
  tratamiento: string | null;
  resultado: string | null;
  observaciones: string | null;
  created_at: string;
  parcelas?: Parcela | null;
}

export interface InventarioItem {
  id: string;
  nombre: string;
  categoria: string;
  unidad: string;
  stock_actual: number;
  stock_minimo: number;
  costo_unitario: number;
  fecha_vencimiento: string | null;
  created_at: string;
  updated_at: string;
}

export interface Herramienta {
  id: string;
  nombre: string;
  tipo: string | null;
  estado: string;
  fecha_compra: string | null;
  costo: number;
  observaciones: string | null;
  created_at: string;
}

export interface Vehiculo {
  id: string;
  nombre: string;
  modelo: string | null;
  placa: string | null;
  kilometraje: number;
  fecha_mantenimiento: string | null;
  costo_mantenimiento: number;
  observaciones: string | null;
  created_at: string;
}

export interface Viaje {
  id: string;
  vehiculo_id: string;
  fecha: string;
  origen: string | null;
  destino: string | null;
  kilometros: number;
  combustible_litros: number;
  combustible_costo: number;
  sacos_transportados: number;
  libras_transportadas: number;
  created_at: string;
  vehiculos?: Vehiculo | null;
}

export interface Trabajador {
  id: string;
  nombre: string;
  rol: string;
  telefono: string | null;
  jornal_diario: number;
  activo: boolean;
  fecha_ingreso: string;
  observaciones: string | null;
  created_at: string;
}

export interface Trasplante {
  id: string;
  semillero_id: string | null;
  parcela_id: string;
  lote_id: string | null;
  fila_id: string | null;
  fecha: string;
  cantidad_plantas: number;
  trabajador_id: string | null;
  observaciones: string | null;
  created_at: string;
  parcelas?: Parcela | null;
  semilleros?: Semillero | null;
  lotes?: Lote | null;
  filas?: Fila | null;
  trabajadores?: Trabajador | null;
}

export interface Compra {
  id: string;
  proveedor: string | null;
  fecha: string;
  descripcion: string | null;
  monto_total: number;
  metodo_pago: string;
  inventario_item_id: string | null;
  cantidad: number;
  created_at: string;
  inventario?: InventarioItem | null;
}

export interface Meta {
  id: string;
  titulo: string;
  descripcion: string | null;
  tipo: string;
  valor_objetivo: number;
  valor_actual: number;
  unidad: string;
  fecha_limite: string | null;
  estado: string;
  created_at: string;
}

export interface Gasto {
  id: string;
  categoria: string;
  subcategoria: string | null;
  descripcion: string | null;
  monto: number;
  fecha: string;
  parcela_id: string | null;
  fila_id: string | null;
  cultivo_id: string | null;
  vehiculo_id: string | null;
  trabajador_id: string | null;
  created_at: string;
  parcelas?: Parcela | null;
  cultivos?: Cultivo | null;
  vehiculos?: Vehiculo | null;
  trabajadores?: Trabajador | null;
}

export interface Venta {
  id: string;
  cliente_id: string | null;
  mercado_id: string | null;
  parcela_id: string | null;
  fecha: string;
  producto: string | null;
  cantidad_libras: number;
  precio_por_libra: number;
  total: number;
  metodo_pago: string;
  estado_pago: string;
  fecha_pago: string | null;
  created_at: string;
  clientes?: Cliente | null;
  mercados?: Mercado | null;
  parcelas?: Parcela | null;
}

export interface Cliente {
  id: string;
  nombre: string;
  telefono: string | null;
  email: string | null;
  direccion: string | null;
  credito_limite: number;
  created_at: string;
}

export interface Mercado {
  id: string;
  nombre: string;
  ubicacion: string | null;
  costo_transporte: number;
  precio_referencia_libra: number;
  created_at: string;
}

export interface Banco {
  id: string;
  nombre: string;
  tipo: string;
  saldo_inicial: number;
  created_at: string;
}

export interface TransaccionBancaria {
  id: string;
  banco_id: string;
  tipo: string;
  monto: number;
  fecha: string;
  descripcion: string | null;
  venta_id: string | null;
  gasto_id: string | null;
  created_at: string;
  bancos?: Banco | null;
}

export interface Prestamo {
  id: string;
  monto_principal: number;
  tasa_interes: number;
  plazo_meses: number;
  fecha_inicio: string;
  cuota_mensual: number;
  saldo_actual: number;
  descripcion: string | null;
  created_at: string;
}

export interface PagoPrestamo {
  id: string;
  prestamo_id: string;
  fecha: string;
  monto: number;
  tipo: string;
  created_at: string;
  prestamos?: Prestamo | null;
}

export interface CacaoLote {
  id: string;
  parcela_id: string | null;
  fecha_cosecha: string;
  libras_humedo: number;
  libras_seco: number;
  precio_libra_humedo: number;
  precio_libra_seco: number;
  fermentacion_dias: number;
  secado_dias: number;
  estado: string;
  observaciones: string | null;
  created_at: string;
  parcelas?: Parcela | null;
}

export interface Configuracion {
  id: number;
  nombre_finca: string;
  capital_inicial: number;
  margen_objetivo: number;
  porcentaje_alerta_costo: number;
  dias_trasplante_default: number;
  moneda: string;
  latitud: number | null;
  longitud: number | null;
  telefono: string | null;
  nombre_usuario: string | null;
  created_at: string;
  updated_at: string;
}

export interface Profile {
  id: string;
  telefono: string;
  nombre: string;
  email: string | null;
  pin: string | null;
  created_at: string;
}
