import { addDays } from './format';

export interface FaseLunar {
  fecha: Date;
  fase: 'Luna Nueva' | 'Cuarto Creciente' | 'Luna Llena' | 'Cuarto Menguante';
  icono: string;
  recomendacion: string;
  actividades_recomendadas: string[];
  actividades_evitar: string[];
}

// Algoritmo simplificado basado en el ciclo sinódico (29.53 días)
// Referencia conocida: 6 enero 2000 = Luna Nueva
const LUNA_NUEVA_REFERENCIA = new Date('2000-01-06T18:14:00Z').getTime();
const CICLO_SINODICO = 29.530588853;

export function obtenerFaseLunar(fecha: Date): FaseLunar['fase'] {
  const diff = (fecha.getTime() - LUNA_NUEVA_REFERENCIA) / (1000 * 60 * 60 * 24);
  const fase = ((diff % CICLO_SINODICO) + CICLO_SINODICO) % CICLO_SINODICO;
  if (fase < 1.84566) return 'Luna Nueva';
  if (fase < 5.53699) return 'Cuarto Creciente';
  if (fase < 9.22831) return 'Luna Llena';
  if (fase < 12.91963) return 'Cuarto Menguante';
  if (fase < 16.61096) return 'Luna Nueva';
  if (fase < 20.30228) return 'Cuarto Creciente';
  if (fase < 23.99361) return 'Luna Llena';
  if (fase < 27.68493) return 'Cuarto Menguante';
  return 'Luna Nueva';
}

export function obtenerInfoFaseLunar(fecha: Date): FaseLunar {
  const fase = obtenerFaseLunar(fecha);
  const info: Record<FaseLunar['fase'], Omit<FaseLunar, 'fecha' | 'fase'>> = {
    'Luna Nueva': {
      icono: '🌑',
      recomendacion: 'Ideal para siembra de semillas y planificación de nuevos ciclos.',
      actividades_recomendadas: ['Siembra de semillas', 'Preparación de sustrato', 'Planificación de cultivos'],
      actividades_evitar: ['Poda fuerte', 'Trasplante'],
    },
    'Cuarto Creciente': {
      icono: '🌒',
      recomendacion: 'Buen momento para trasplante y fertilización. La savia ascendente favorece el crecimiento.',
      actividades_recomendadas: ['Trasplante', 'Fertilización', 'Siembra de hojas y frutos', 'Injertación'],
      actividades_evitar: ['Cosecha de raíces'],
    },
    'Luna Llena': {
      icono: '🌕',
      recomendacion: 'Favorable para cosecha de frutos y control de plagas. Evitar podas mayores.',
      actividades_recomendadas: ['Cosecha de frutos', 'Control de plagas', 'Recolección de semillas'],
      actividades_evitar: ['Poda', 'Trasplante', 'Fertilización fuerte'],
    },
    'Cuarto Menguante': {
      icono: '🌘',
      recomendacion: 'Ideal para poda, cosecha de raíces y almacenamiento. La savia desciende.',
      actividades_recomendadas: ['Poda', 'Cosecha de raíces', 'Control de malezas', 'Almacenamiento'],
      actividades_evitar: ['Siembra de semillas', 'Fertilización nitrogenada'],
    },
  };
  return { fecha, fase, ...info[fase] };
}

export function generarCalendarioLunar(dias: number = 30, inicio: Date = new Date()): FaseLunar[] {
  const calendario: FaseLunar[] = [];
  let faseAnterior = '';
  for (let i = 0; i < dias; i++) {
    const fecha = addDays(inicio, i);
    const info = obtenerInfoFaseLunar(fecha);
    // Mostrar solo días de cambio de fase o todos — mostramos todos para referencia diaria
    void faseAnterior;
    calendario.push(info);
    faseAnterior = info.fase;
  }
  return calendario;
}

// ============================================================
// CALENDARIO AGRÍCOLA — actividades según edad del cultivo
// ============================================================
export interface ActividadAgricola {
  id: string;
  parcela_id: string;
  parcela_nombre: string;
  actividad: string;
  fecha_programada: Date;
  dias_restantes: number;
  estado: 'pendiente' | 'vencida' | 'completada';
  prioridad: 'alta' | 'media' | 'baja';
  icono: string;
}

export function generarCalendarioAgricola(
  parcelas: Array<{ id: string; nombre: string; fecha_siembra: string | null; cultivo_id: string | null }>,
  cultivos: Array<{ id: string; dias_germinacion: number; dias_trasplante: number }>,
): ActividadAgricola[] {
  const actividades: ActividadAgricola[] = [];
  const now = new Date();

  const etapas = [
    { dias: 1, actividad: 'Siembra', prioridad: 'alta' as const, icono: '🌱' },
    { dias: 8, actividad: 'Revisión germinación', prioridad: 'media' as const, icono: '🌿' },
    { dias: 15, actividad: 'Primera fertilización', prioridad: 'media' as const, icono: '🧪' },
    { dias: 25, actividad: 'Control preventivo', prioridad: 'media' as const, icono: '🐛' },
    { dias: 35, actividad: 'Trasplante', prioridad: 'alta' as const, icono: '🚜' },
    { dias: 50, actividad: 'Tutorado', prioridad: 'media' as const, icono: '🪢' },
    { dias: 60, actividad: 'Floración', prioridad: 'media' as const, icono: '🌸' },
    { dias: 75, actividad: 'Primer corte', prioridad: 'alta' as const, icono: '🧺' },
  ];

  parcelas.forEach(p => {
    if (!p.fecha_siembra) return;
    const cultivo = cultivos.find(c => c.id === p.cultivo_id);
    const diasTrasplante = cultivo?.dias_trasplante ?? 35;
    etapas.forEach(e => {
      const diasReal = e.actividad === 'Trasplante' ? diasTrasplante : e.dias;
      const fechaProg = addDays(new Date(p.fecha_siembra!), diasReal);
      const diasRest = Math.floor((fechaProg.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      const estado: ActividadAgricola['estado'] = diasRest < 0 ? 'vencida' : diasRest <= 7 ? 'pendiente' : 'pendiente';
      actividades.push({
        id: `act-${p.id}-${e.dias}`,
        parcela_id: p.id,
        parcela_nombre: p.nombre,
        actividad: e.actividad,
        fecha_programada: fechaProg,
        dias_restantes: diasRest,
        estado,
        prioridad: e.prioridad,
        icono: e.icono,
      });
    });
  });

  return actividades.sort((a, b) => a.dias_restantes - b.dias_restantes);
}
