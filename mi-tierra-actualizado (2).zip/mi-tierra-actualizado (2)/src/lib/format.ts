export function fmtMoney(n: number | null | undefined, moneda = 'RD$'): string {
  const v = Number(n ?? 0);
  return `${moneda} ${v.toLocaleString('es-DO', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function fmtNum(n: number | null | undefined, decimals = 2): string {
  return Number(n ?? 0).toLocaleString('es-DO', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

export function fmtInt(n: number | null | undefined): string {
  return Number(n ?? 0).toLocaleString('es-DO');
}

export function fmtPct(n: number | null | undefined, decimals = 1): string {
  return `${Number(n ?? 0).toLocaleString('es-DO', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}%`;
}

export function fmtDate(d: string | Date | null | undefined): string {
  if (!d) return '—';
  const date = typeof d === 'string' ? new Date(d) : d;
  if (isNaN(date.getTime())) return '—';
  return date.toLocaleDateString('es-DO', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function fmtDateShort(d: string | Date | null | undefined): string {
  if (!d) return '—';
  const date = typeof d === 'string' ? new Date(d) : d;
  if (isNaN(date.getTime())) return '—';
  return date.toLocaleDateString('es-DO', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

export function daysBetween(start: string | Date, end: string | Date = new Date()): number {
  const s = typeof start === 'string' ? new Date(start) : start;
  const e = typeof end === 'string' ? new Date(end) : end;
  return Math.floor((e.getTime() - s.getTime()) / (1000 * 60 * 60 * 24));
}

export function addDays(date: Date, days: number): Date {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

export function todayISO(): string {
  return new Date().toISOString().split('T')[0];
}

export function isSameDay(d1: string | Date, d2: string | Date): boolean {
  const a = typeof d1 === 'string' ? new Date(d1) : d1;
  const b = typeof d2 === 'string' ? new Date(d2) : d2;
  return a.toDateString() === b.toDateString();
}

export function startOfMonth(d: Date = new Date()): Date {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

export function startOfYear(d: Date = new Date()): Date {
  return new Date(d.getFullYear(), 0, 1);
}

export function startOfWeek(d: Date = new Date()): Date {
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(d.setDate(diff));
}
