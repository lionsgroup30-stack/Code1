import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import { supabase } from './supabase';
import type {
  Cultivo, Parcela, Fila, Semillero, Cosecha, Riego, Fertilizacion, Plaga,
  InventarioItem, Herramienta, Vehiculo, Viaje, Gasto, Venta, Cliente, Mercado,
  Banco, TransaccionBancaria, Prestamo, PagoPrestamo, CacaoLote, Configuracion,
  Trabajador, Trasplante, Compra, Meta, Lote, Profile,
} from './types';

interface DataState {
  cultivos: Cultivo[];
  parcelas: Parcela[];
  lotes: Lote[];
  filas: Fila[];
  semilleros: Semillero[];
  cosechas: Cosecha[];
  riego: Riego[];
  fertilizacion: Fertilizacion[];
  plagas: Plaga[];
  inventario: InventarioItem[];
  herramientas: Herramienta[];
  vehiculos: Vehiculo[];
  viajes: Viaje[];
  gastos: Gasto[];
  ventas: Venta[];
  clientes: Cliente[];
  mercados: Mercado[];
  bancos: Banco[];
  transacciones_bancarias: TransaccionBancaria[];
  prestamos: Prestamo[];
  pagos_prestamos: PagoPrestamo[];
  cacao_lotes: CacaoLote[];
  trabajadores: Trabajador[];
  trasplantes: Trasplante[];
  compras: Compra[];
  metas: Meta[];
  profile: Profile | null;
  config: Configuracion | null;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

const DataContext = createContext<DataState | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<DataState>({
    cultivos: [], parcelas: [], lotes: [], filas: [], semilleros: [], cosechas: [],
    riego: [], fertilizacion: [], plagas: [], inventario: [], herramientas: [],
    vehiculos: [], viajes: [], gastos: [], ventas: [], clientes: [], mercados: [],
    bancos: [], transacciones_bancarias: [], prestamos: [], pagos_prestamos: [],
    cacao_lotes: [], trabajadores: [], trasplantes: [], compras: [], metas: [],
    profile: null, config: null, loading: true, error: null, refresh: async () => {},
  });

  const loadAll = useCallback(async () => {
    try {
      const selects: Record<string, string> = {
        cultivos: '*',
        parcelas: '*, cultivos(*)',
        lotes: '*, parcelas(*)',
        filas: '*, parcelas(*), lotes(*)',
        semilleros: '*, cultivos(*)',
        cosechas: '*, parcelas(*), filas(*), mercados(*), trabajadores(*)',
        riego: '*, parcelas(*), trabajadores(*)',
        fertilizacion: '*, parcelas(*), trabajadores(*)',
        plagas: '*, parcelas(*)',
        inventario: '*',
        herramientas: '*',
        vehiculos: '*',
        viajes: '*, vehiculos(*)',
        gastos: '*, parcelas(*), cultivos(*), vehiculos(*), trabajadores(*)',
        ventas: '*, clientes(*), mercados(*), parcelas(*)',
        clientes: '*',
        mercados: '*',
        bancos: '*',
        transacciones_bancarias: '*, bancos(*)',
        prestamos: '*',
        pagos_prestamos: '*, prestamos(*)',
        cacao_lotes: '*, parcelas(*)',
        trabajadores: '*',
        trasplantes: '*, parcelas(*), semilleros(*), lotes(*), filas(*), trabajadores(*)',
        compras: '*, inventario(*)',
        metas: '*',
        configuracion: '*',
        profiles: '*',
      };

      const entries = Object.entries(selects);
      const results = await Promise.all(
        entries.map(async ([table, sel]) => {
          const { data, error } = await supabase.from(table).select(sel).order('created_at', { ascending: false });
          if (error) throw error;
          return [table, data ?? []] as const;
        })
      );

      const next: Record<string, unknown[]> = {};
      results.forEach(([k, v]) => { next[k] = v; });

      const config = (next.configuracion as Configuracion[])[0] ?? null;
      const profile = (next.profiles as Profile[])[0] ?? null;

      setState({
        cultivos: next.cultivos as Cultivo[],
        parcelas: next.parcelas as Parcela[],
        lotes: next.lotes as Lote[],
        filas: next.filas as Fila[],
        semilleros: next.semilleros as Semillero[],
        cosechas: next.cosechas as Cosecha[],
        riego: next.riego as Riego[],
        fertilizacion: next.fertilizacion as Fertilizacion[],
        plagas: next.plagas as Plaga[],
        inventario: next.inventario as InventarioItem[],
        herramientas: next.herramientas as Herramienta[],
        vehiculos: next.vehiculos as Vehiculo[],
        viajes: next.viajes as Viaje[],
        gastos: next.gastos as Gasto[],
        ventas: next.ventas as Venta[],
        clientes: next.clientes as Cliente[],
        mercados: next.mercados as Mercado[],
        bancos: next.bancos as Banco[],
        transacciones_bancarias: next.transacciones_bancarias as TransaccionBancaria[],
        prestamos: next.prestamos as Prestamo[],
        pagos_prestamos: next.pagos_prestamos as PagoPrestamo[],
        cacao_lotes: next.cacao_lotes as CacaoLote[],
        trabajadores: next.trabajadores as Trabajador[],
        trasplantes: next.trasplantes as Trasplante[],
        compras: next.compras as Compra[],
        metas: next.metas as Meta[],
        profile: profile as Profile | null,
        config: config as Configuracion | null,
        loading: false,
        error: null,
        refresh: loadAll,
      });
    } catch (err) {
      setState(prev => ({ ...prev, loading: false, error: err instanceof Error ? err.message : 'Error de carga', refresh: loadAll }));
    }
  }, []);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  useEffect(() => {
    const channel = supabase
      .channel('mi-tierra-realtime')
      .on('postgres_changes', { event: '*', schema: 'public' }, () => { loadAll(); })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [loadAll]);

  return <DataContext.Provider value={state}>{children}</DataContext.Provider>;
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within DataProvider');
  return ctx;
}
