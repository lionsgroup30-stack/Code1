import type {
  Cultivo, Parcela, Fila, Cosecha, Gasto, Venta, Cliente, Mercado,
  Semillero, InventarioItem, Prestamo, PagoPrestamo, Configuracion, Viaje, Vehiculo,
  Trabajador, Meta, Lote, Riego, Fertilizacion, Trasplante,
} from './types';
import { daysBetween, startOfMonth, startOfYear, startOfWeek, addDays, isSameDay } from './format';

// ============================================================
// SEMILLERO INTELIGENTE
// ============================================================
export interface SemilleroCalc {
  edad_dias: number;
  dias_transcurridos: number;
  fecha_germinacion_estimada: Date;
  porcentaje_germinacion: number;
  porcentaje_esperado: number;
  fecha_trasplante_estimada: Date;
  dias_restantes_trasplante: number;
  estado: 'germinando' | 'listo' | 'atrasado' | 'trasplantado';
  proxima_actividad: string;
}

export function calcSemillero(s: Semillero): SemilleroCalc {
  const edad = daysBetween(s.fecha_siembra);
  const cultivoDiasGerminacion = s.cultivos?.dias_germinacion ?? 7;
  const fechaGerminacion = addDays(new Date(s.fecha_siembra), cultivoDiasGerminacion);
  const porcentajeGerminacion = s.cantidad_semillas > 0 ? (s.semillas_germinadas / s.cantidad_semillas) * 100 : 0;
  const fechaTrasplante = addDays(new Date(s.fecha_siembra), s.dias_para_trasplante);
  const diasRestantes = daysBetween(new Date(), fechaTrasplante);

  let estado: SemilleroCalc['estado'] = 'germinando';
  let proxima = 'Esperando germinación';
  if (s.estado === 'trasplantado') { estado = 'trasplantado'; proxima = 'Completado'; }
  else if (diasRestantes < 0) { estado = 'atrasado'; proxima = 'Trasplante atrasado'; }
  else if (diasRestantes <= 7) { estado = 'listo'; proxima = `Trasplantar en ${diasRestantes} días`; }
  else { proxima = edad < cultivoDiasGerminacion ? 'Esperando germinación' : 'Monitorear crecimiento'; }

  return {
    edad_dias: Math.max(0, edad),
    dias_transcurridos: Math.max(0, edad),
    fecha_germinacion_estimada: fechaGerminacion,
    porcentaje_germinacion: porcentajeGerminacion,
    porcentaje_esperado: s.porcentaje_esperado_germinacion ?? 85,
    fecha_trasplante_estimada: fechaTrasplante,
    dias_restantes_trasplante: diasRestantes,
    estado,
    proxima_actividad: proxima,
  };
}

// ============================================================
// PRODUCCIÓN — semáforo con thresholds del prompt V2
// ============================================================
export interface ProduccionRealidad {
  esperada: number;
  real: number;
  cumplimiento: number;
  diferencia_libras: number;
  diferencia_economica: number;
  semaforo: 'verde' | 'amarillo' | 'rojo' | 'azul';
  estado_texto: string;
}

export function calcProduccion(
  esperada: number,
  real: number,
  precioPorLibra: number,
): ProduccionRealidad {
  const cumplimiento = esperada > 0 ? (real / esperada) * 100 : 0;
  const diffLibras = real - esperada;
  const diffEcon = diffLibras * precioPorLibra;
  let semaforo: ProduccionRealidad['semaforo'] = 'rojo';
  let estado = 'Por debajo del objetivo';
  // Thresholds del prompt: 95-105% verde, 80-94% amarillo, <80% rojo, >110% azul
  if (cumplimiento > 110) { semaforo = 'azul'; estado = 'Supera el objetivo'; }
  else if (cumplimiento >= 95) { semaforo = 'verde'; estado = 'En objetivo'; }
  else if (cumplimiento >= 80) { semaforo = 'amarillo'; estado = 'Por debajo'; }
  return { esperada, real, cumplimiento, diferencia_libras: diffLibras, diferencia_economica: diffEcon, semaforo, estado_texto: estado };
}

export function parcelaProduccionEsperada(p: Parcela, filas: Fila[]): number {
  if (p.produccion_esperada_total && p.produccion_esperada_total > 0) return p.produccion_esperada_total;
  const cultivo = p.cultivos;
  if (cultivo && cultivo.produccion_esperada_por_planta > 0) {
    const totalPlantas = filas.filter(f => f.parcela_id === p.id).reduce((s, f) => s + f.cantidad_plantas, 0);
    return totalPlantas * cultivo.produccion_esperada_por_planta;
  }
  return filas.filter(f => f.parcela_id === p.id).reduce((s, f) => s + f.cantidad_plantas * f.produccion_esperada_por_planta, 0);
}

export function parcelaProduccionReal(p: Parcela, cosechas: Cosecha[]): number {
  return cosechas.filter(c => c.parcela_id === p.id).reduce((s, c) => s + c.cantidad_libras, 0);
}

export function parcelaTotalPlantas(p: Parcela, filas: Fila[]): number {
  return filas.filter(f => f.parcela_id === p.id).reduce((s, f) => s + f.cantidad_plantas, 0);
}

// ============================================================
// COSTOS — categorías reestructuradas V2
// ============================================================
export const GASTO_CATEGORIAS = [
  'Inversión inicial', 'Terreno', 'Pozo', 'Malla', 'Sistema de riego', 'Bombas',
  'Planchas', 'Herramientas', 'Construcciones', 'Equipos',
  'Semillas', 'Fertilizantes', 'Fungicidas', 'Insecticidas', 'Calcio', 'Potasio',
  'Materia orgánica', 'Herbicidas',
  'Jornales', 'Horas extras', 'Alimentación',
  'Combustible', 'Pasajes', 'Mantenimiento', 'Peajes',
  'Sacos', 'Empaques', 'Etiquetas', 'Publicidad',
  'Otros',
] as const;

export const GASTO_SUBCATEGORIAS: Record<string, string[]> = {
  'Inversión inicial': ['Terreno', 'Pozo', 'Malla', 'Sistema de riego', 'Bombas', 'Planchas', 'Herramientas', 'Construcciones'],
  'Producción': ['Semillas', 'Fertilizantes', 'Fungicidas', 'Insecticidas', 'Calcio', 'Potasio', 'Materia orgánica', 'Herbicidas'],
  'Mano de obra': ['Jornales', 'Horas extras', 'Alimentación'],
  'Transporte': ['Combustible', 'Pasajes', 'Mantenimiento', 'Peajes'],
  'Comercialización': ['Sacos', 'Empaques', 'Etiquetas', 'Publicidad'],
};

export interface CostosParcela {
  costo_total: number;
  costo_por_planta: number;
  costo_por_libra: number;
  costo_por_tarea: number;
  costo_por_fila: number;
  num_filas: number;
  num_plantas: number;
  libras_producidas: number;
  area_tareas: number;
}

export function calcCostosParcela(
  p: Parcela,
  gastos: Gasto[],
  filas: Fila[],
  cosechas: Cosecha[],
): CostosParcela {
  const gastosParcela = gastos.filter(g => g.parcela_id === p.id);
  const costoTotal = gastosParcela.reduce((s, g) => s + g.monto, 0);
  const numFilas = filas.filter(f => f.parcela_id === p.id).length;
  const numPlantas = parcelaTotalPlantas(p, filas);
  const libras = parcelaProduccionReal(p, cosechas);
  return {
    costo_total: costoTotal,
    costo_por_planta: numPlantas > 0 ? costoTotal / numPlantas : 0,
    costo_por_libra: libras > 0 ? costoTotal / libras : 0,
    costo_por_tarea: p.area_tareas > 0 ? costoTotal / p.area_tareas : 0,
    costo_por_fila: numFilas > 0 ? costoTotal / numFilas : 0,
    num_filas: numFilas,
    num_plantas: numPlantas,
    libras_producidas: libras,
    area_tareas: p.area_tareas,
  };
}

export interface SemaforoCostos {
  costo_esperado_libra: number;
  costo_real_libra: number;
  costo_esperado_planta: number;
  costo_real_planta: number;
  variacion_libra_pct: number;
  variacion_planta_pct: number;
  alerta: boolean;
  estado: 'verde' | 'amarillo' | 'rojo';
}

export function calcSemaforoCostos(
  cultivo: Cultivo | null | undefined,
  costos: CostosParcela,
  porcentajeAlerta: number,
): SemaforoCostos {
  const esperadoLibra = cultivo?.costo_esperado_por_libra ?? 0;
  const esperadoPlanta = cultivo?.costo_esperado_por_planta ?? 0;
  const realLibra = costos.costo_por_libra;
  const realPlanta = costos.costo_por_planta;
  const varLibra = esperadoLibra > 0 ? ((realLibra - esperadoLibra) / esperadoLibra) * 100 : 0;
  const varPlanta = esperadoPlanta > 0 ? ((realPlanta - esperadoPlanta) / esperadoPlanta) * 100 : 0;
  const alerta = varLibra > porcentajeAlerta || varPlanta > porcentajeAlerta;
  let estado: SemaforoCostos['estado'] = 'verde';
  if (alerta) estado = 'rojo';
  else if (varLibra > 0 || varPlanta > 0) estado = 'amarillo';
  return {
    costo_esperado_libra: esperadoLibra, costo_real_libra: realLibra,
    costo_esperado_planta: esperadoPlanta, costo_real_planta: realPlanta,
    variacion_libra_pct: varLibra, variacion_planta_pct: varPlanta, alerta, estado,
  };
}

// ============================================================
// FINANZAS / KPIs — Dashboard V2 expandido
// ============================================================
export interface DashboardKPIs {
  capital_disponible: number;
  caja: number;
  ingresos_total: number;
  ventas_dia: number;
  ventas_mes: number;
  ventas_anio: number;
  gastos_total: number;
  gastos_mes: number;
  ganancia: number;
  rentabilidad_pct: number;
  roi: number;
  margen_utilidad: number;
  flujo_caja: number;
  costo_por_planta: number;
  costo_por_libra: number;
  costo_por_lote: number;
  costo_por_tarea: number;
  costo_por_fila: number;
  costo_por_trabajador: number;
  costo_por_vehiculo: number;
  costo_por_viaje: number;
  costo_por_mercado: number;
  costo_por_cliente: number;
  produccion_dia: number;
  produccion_semana: number;
  produccion_mes: number;
  produccion_anio: number;
  produccion_estimada: number;
  produccion_real: number;
  cumplimiento_pct: number;
  inventario_valor: number;
  inventario_critico: number;
  inventos_por_vencer: number;
  consumo_promedio: number;
  rotacion: number;
  clientes_activos: number;
  clientes_nuevos: number;
  cuentas_por_cobrar: number;
  precio_promedio: number;
  mercado_mas_rentable: string;
  cliente_mas_rentable: string;
  cobros_pendientes: number;
  prestamos_total: number;
  alertas_count: number;
}

export function calcDashboard(
  ventas: Venta[],
  gastos: Gasto[],
  cosechas: Cosecha[],
  inventario: InventarioItem[],
  clientes: Cliente[],
  prestamos: Prestamo[],
  config: Configuracion,
  parcelas: Parcela[],
  filas: Fila[],
  viajes: Viaje[],
  vehiculos: Vehiculo[],
  mercados: Mercado[],
  trabajadores: Trabajador[],
  alertasCount: number,
): DashboardKPIs {
  const now = new Date();
  const sMes = startOfMonth(now), sAnio = startOfYear(now), sSem = startOfWeek(now);
  const moneda = config.moneda;

  const ventasDia = ventas.filter(v => isSameDay(v.fecha, now)).reduce((s, v) => s + v.total, 0);
  const ventasMes = ventas.filter(v => new Date(v.fecha) >= sMes).reduce((s, v) => s + v.total, 0);
  const ventasAnio = ventas.filter(v => new Date(v.fecha) >= sAnio).reduce((s, v) => s + v.total, 0);
  const ventasTotal = ventas.reduce((s, v) => s + v.total, 0);

  const gastosTotal = gastos.reduce((s, g) => s + g.monto, 0);
  const gastosMes = gastos.filter(g => new Date(g.fecha) >= sMes).reduce((s, g) => s + g.monto, 0);

  const prodDia = cosechas.filter(c => isSameDay(c.fecha, now)).reduce((s, c) => s + c.cantidad_libras, 0);
  const prodSem = cosechas.filter(c => new Date(c.fecha) >= sSem).reduce((s, c) => s + c.cantidad_libras, 0);
  const prodMes = cosechas.filter(c => new Date(c.fecha) >= sMes).reduce((s, c) => s + c.cantidad_libras, 0);
  const prodAnio = cosechas.filter(c => new Date(c.fecha) >= sAnio).reduce((s, c) => s + c.cantidad_libras, 0);
  const prodReal = cosechas.reduce((s, c) => s + c.cantidad_libras, 0);
  const prodEstimada = parcelas.reduce((s, p) => s + parcelaProduccionEsperada(p, filas), 0);
  const cumplimiento = prodEstimada > 0 ? (prodReal / prodEstimada) * 100 : 0;

  const cobrosPend = ventas.filter(v => v.estado_pago === 'pendiente').reduce((s, v) => s + v.total, 0);
  const prestamosTotal = prestamos.reduce((s, p) => s + p.saldo_actual, 0);
  const invValor = inventario.reduce((s, i) => s + i.stock_actual * i.costo_unitario, 0);
  const invCritico = inventario.filter(i => i.stock_minimo > 0 && i.stock_actual <= i.stock_minimo).length;
  const invPorVencer = inventario.filter(i => i.fecha_vencimiento && daysBetween(now, new Date(i.fecha_vencimiento)) <= 30 && daysBetween(now, new Date(i.fecha_vencimiento)) >= 0).length;
  const clientesActivos = new Set(ventas.map(v => v.cliente_id).filter(Boolean)).size;
  const clientesNuevos = clientes.filter(c => new Date(c.created_at) >= sMes).length;
  const precioPromedio = ventas.length > 0 ? ventas.reduce((s, v) => s + v.precio_por_libra, 0) / ventas.length : 0;

  const ganancia = ventasTotal - gastosTotal;
  const rentabilidad = ventasTotal > 0 ? (ganancia / ventasTotal) * 100 : 0;
  const roi = gastosTotal > 0 ? (ganancia / gastosTotal) * 100 : 0;
  const margenUtilidad = rentabilidad;
  const flujoCaja = ventasMes - gastosMes;

  const totalPlantas = parcelas.reduce((s, p) => s + parcelaTotalPlantas(p, filas), 0);
  const totalLibras = prodReal;
  const numLotes = parcelas.length;
  const numTareas = parcelas.reduce((s, p) => s + p.area_tareas, 0);
  const numFilas = filas.length;
  const numTrabajadores = trabajadores.length;
  const numVehiculos = vehiculos.length;
  const totalViajes = viajes.length;

  const capital = config.capital_inicial + ganancia;
  const caja = capital - cobrosPend;

  // Mercado más rentable
  let mercadoMasRentable = '—';
  let mejorGanancia = -Infinity;
  mercados.forEach(m => {
    const v = ventas.filter(ve => ve.mercado_id === m.id);
    const ingr = v.reduce((s, ve) => s + ve.total, 0);
    const cost = m.costo_transporte * v.length;
    const g = ingr - cost;
    if (g > mejorGanancia && v.length > 0) { mejorGanancia = g; mercadoMasRentable = m.nombre; }
  });

  // Cliente más rentable
  let clienteMasRentable = '—';
  let mejorClienteGanancia = -Infinity;
  clientes.forEach(c => {
    const total = ventas.filter(v => v.cliente_id === c.id).reduce((s, v) => s + v.total, 0);
    if (total > mejorClienteGanancia) { mejorClienteGanancia = total; clienteMasRentable = c.nombre; }
  });

  // Consumo promedio (gastos en insumos últimos 30 días)
  const consumoPromedio = gastos.filter(g => daysBetween(g.fecha, now) <= 30 && ['Semillas', 'Fertilizantes', 'Fungicidas', 'Insecticidas', 'Herbicidas'].includes(g.categoria)).reduce((s, g) => s + g.monto, 0) / 30;
  // Rotación aproximada: consumo / valor inventario
  const rotacion = invValor > 0 ? (consumoPromedio * 30) / invValor : 0;

  return {
    capital_disponible: capital, caja,
    ingresos_total: ventasTotal,
    ventas_dia: ventasDia, ventas_mes: ventasMes, ventas_anio: ventasAnio,
    gastos_total: gastosTotal, gastos_mes: gastosMes,
    ganancia, rentabilidad_pct: rentabilidad, roi, margen_utilidad: margenUtilidad, flujo_caja: flujoCaja,
    costo_por_planta: totalPlantas > 0 ? gastosTotal / totalPlantas : 0,
    costo_por_libra: totalLibras > 0 ? gastosTotal / totalLibras : 0,
    costo_por_lote: numLotes > 0 ? gastosTotal / numLotes : 0,
    costo_por_tarea: numTareas > 0 ? gastosTotal / numTareas : 0,
    costo_por_fila: numFilas > 0 ? gastosTotal / numFilas : 0,
    costo_por_trabajador: numTrabajadores > 0 ? gastosTotal / numTrabajadores : 0,
    costo_por_vehiculo: numVehiculos > 0 ? gastosTotal / numVehiculos : 0,
    costo_por_viaje: totalViajes > 0 ? viajes.reduce((s, v) => s + v.combustible_costo, 0) / totalViajes : 0,
    costo_por_mercado: mercados.length > 0 ? gastosTotal / mercados.length : 0,
    costo_por_cliente: clientesActivos > 0 ? gastosTotal / clientesActivos : 0,
    produccion_dia: prodDia, produccion_semana: prodSem, produccion_mes: prodMes, produccion_anio: prodAnio,
    produccion_estimada: prodEstimada, produccion_real: prodReal, cumplimiento_pct: cumplimiento,
    inventario_valor: invValor, inventario_critico: invCritico, inventos_por_vencer: invPorVencer,
    consumo_promedio: consumoPromedio, rotacion,
    clientes_activos: clientesActivos, clientes_nuevos: clientesNuevos,
    cuentas_por_cobrar: cobrosPend, precio_promedio: precioPromedio,
    mercado_mas_rentable: mercadoMasRentable, cliente_mas_rentable: clienteMasRentable,
    cobros_pendientes: cobrosPend, prestamos_total: prestamosTotal, alertas_count: alertasCount,
  };
  void moneda;
}

// ============================================================
// SEMÁFORO FINANCIERO — thresholds V2: >20% verde, 5-20% amarillo, <0% rojo
// ============================================================
export interface SemaforoFinanciero {
  utilidad: number;
  margen_objetivo: number;
  margen_real: number;
  estado: 'verde' | 'amarillo' | 'rojo';
  etiqueta: 'Ganando' | 'Riesgo' | 'Perdiendo';
}

export function calcSemaforoFinanciero(kpis: DashboardKPIs, _config: Configuracion): SemaforoFinanciero {
  const utilidad = kpis.ganancia;
  const margenReal = kpis.rentabilidad_pct;
  let estado: SemaforoFinanciero['estado'] = 'rojo';
  let etiqueta: SemaforoFinanciero['etiqueta'] = 'Perdiendo';
  // V2 thresholds: >20% verde, 5-20% amarillo, pérdidas rojo
  if (utilidad > 0 && margenReal >= 20) { estado = 'verde'; etiqueta = 'Ganando'; }
  else if (utilidad > 0 && margenReal >= 5) { estado = 'amarillo'; etiqueta = 'Riesgo'; }
  return { utilidad, margen_objetivo: 20, margen_real: margenReal, estado, etiqueta };
}

// ============================================================
// RENTABILIDAD POR ENTIDAD
// ============================================================
export interface RentabilidadItem {
  id: string;
  nombre: string;
  ingresos: number;
  costos: number;
  ganancia: number;
  margen_pct: number;
  roi: number;
}

export function rentabilidadPorParcela(
  parcelas: Parcela[], cosechas: Cosecha[], gastos: Gasto[], ventas: Venta[],
): RentabilidadItem[] {
  return parcelas.map(p => {
    const ingrVentas = ventas.filter(v => v.parcela_id === p.id).reduce((s, v) => s + v.total, 0);
    const ingrCosecha = cosechas.filter(c => c.parcela_id === p.id).reduce((s, c) => s + c.cantidad_libras * c.precio_por_libra, 0);
    const ingresos = ingrVentas || ingrCosecha;
    const costos = gastos.filter(g => g.parcela_id === p.id).reduce((s, g) => s + g.monto, 0);
    const ganancia = ingresos - costos;
    return {
      id: p.id, nombre: p.nombre, ingresos, costos, ganancia,
      margen_pct: ingresos > 0 ? (ganancia / ingresos) * 100 : 0,
      roi: costos > 0 ? (ganancia / costos) * 100 : 0,
    };
  });
}

export function rentabilidadPorCliente(ventas: Venta[], clientes: Cliente[]): RentabilidadItem[] {
  const map = new Map<string, number>();
  ventas.forEach(v => { if (v.cliente_id) map.set(v.cliente_id, (map.get(v.cliente_id) ?? 0) + v.total); });
  return clientes.map(c => {
    const ingresos = map.get(c.id) ?? 0;
    return {
      id: c.id, nombre: c.nombre, ingresos, costos: 0, ganancia: ingresos,
      margen_pct: 100, roi: 0,
    };
  }).sort((a, b) => b.ingresos - a.ingresos);
}

export function rentabilidadPorMercado(ventas: Venta[], mercados: Mercado[]): RentabilidadItem[] {
  return mercados.map(m => {
    const ventasM = ventas.filter(v => v.mercado_id === m.id);
    const ingresos = ventasM.reduce((s, v) => s + v.total, 0);
    const costos = m.costo_transporte * ventasM.length;
    const ganancia = ingresos - costos;
    return {
      id: m.id, nombre: m.nombre, ingresos, costos, ganancia,
      margen_pct: ingresos > 0 ? (ganancia / ingresos) * 100 : 0,
      roi: costos > 0 ? (ganancia / costos) * 100 : 0,
    };
  });
}

export function rentabilidadPorCultivo(
  cultivos: Cultivo[], parcelas: Parcela[], cosechas: Cosecha[], gastos: Gasto[],
): RentabilidadItem[] {
  return cultivos.map(c => {
    const parcelasC = parcelas.filter(p => p.cultivo_id === c.id);
    const ingr = cosechas.filter(co => parcelasC.some(p => p.id === co.parcela_id))
      .reduce((s, co) => s + co.cantidad_libras * co.precio_por_libra, 0);
    const costos = gastos.filter(g => g.cultivo_id === c.id || parcelasC.some(p => p.id === g.parcela_id))
      .reduce((s, g) => s + g.monto, 0);
    const ganancia = ingr - costos;
    return {
      id: c.id, nombre: c.nombre, ingresos: ingr, costos, ganancia,
      margen_pct: ingr > 0 ? (ganancia / ingr) * 100 : 0,
      roi: costos > 0 ? (ganancia / costos) * 100 : 0,
    };
  });
}

export function rentabilidadPorTrabajador(
  trabajadores: Trabajador[], cosechas: Cosecha[], gastos: Gasto[],
): RentabilidadItem[] {
  return trabajadores.map(t => {
    const cosechasT = cosechas.filter(c => c.trabajador_id === t.id);
    const ingresos = cosechasT.reduce((s, c) => s + c.cantidad_libras * c.precio_por_libra, 0);
    const costos = gastos.filter(g => g.trabajador_id === t.id).reduce((s, g) => s + g.monto, 0) + (t.jornal_diario * 30);
    const ganancia = ingresos - costos;
    return {
      id: t.id, nombre: t.nombre, ingresos, costos, ganancia,
      margen_pct: ingresos > 0 ? (ganancia / ingresos) * 100 : 0,
      roi: costos > 0 ? (ganancia / costos) * 100 : 0,
    };
  });
}

// ============================================================
// COMPARACIÓN DE MERCADOS
// ============================================================
export interface MercadoComparacion {
  id: string;
  nombre: string;
  precio_libra: number;
  costo_transporte: number;
  precio_neto: number;
  rentabilidad_libra: number;
  es_mejor: boolean;
}

export function compararMercados(mercados: Mercado[], costoBaseLibra: number): MercadoComparacion[] {
  if (mercados.length === 0) return [];
  const comparaciones = mercados.map(m => {
    const precio = m.precio_referencia_libra || 0;
    const precioNeto = precio - m.costo_transporte;
    return {
      id: m.id, nombre: m.nombre, precio_libra: precio,
      costo_transporte: m.costo_transporte, precio_neto: precioNeto,
      rentabilidad_libra: precioNeto - costoBaseLibra,
      es_mejor: false,
    };
  });
  const mejor = comparaciones.reduce((best, c) => c.precio_neto > best.precio_neto ? c : best, comparaciones[0]);
  mejor.es_mejor = true;
  return comparaciones;
}

// ============================================================
// PUNTO DE EQUILIBRIO
// ============================================================
export function calcPuntoEquilibrio(costosFijos: number, precioPorLibra: number, costoVariablePorLibra: number): number {
  const margenContribucion = precioPorLibra - costoVariablePorLibra;
  return margenContribucion > 0 ? costosFijos / margenContribucion : 0;
}

// ============================================================
// VEHÍCULOS
// ============================================================
export interface VehiculoStats {
  costo_total: number;
  costo_por_viaje: number;
  costo_por_libra: number;
  costo_por_saco: number;
  total_viajes: number;
  total_libras: number;
  total_sacos: number;
}

export function calcVehiculoStats(v: Vehiculo, viajes: Viaje[]): VehiculoStats {
  const viajesV = viajes.filter(vi => vi.vehiculo_id === v.id);
  const costoTotal = viajesV.reduce((s, vi) => s + vi.combustible_costo, 0) + v.costo_mantenimiento;
  const totalLibras = viajesV.reduce((s, vi) => s + vi.libras_transportadas, 0);
  const totalSacos = viajesV.reduce((s, vi) => s + vi.sacos_transportados, 0);
  return {
    costo_total: costoTotal,
    costo_por_viaje: viajesV.length > 0 ? costoTotal / viajesV.length : 0,
    costo_por_libra: totalLibras > 0 ? costoTotal / totalLibras : 0,
    costo_por_saco: totalSacos > 0 ? costoTotal / totalSacos : 0,
    total_viajes: viajesV.length, total_libras: totalLibras, total_sacos: totalSacos,
  };
}

// ============================================================
// PRÉSTAMOS
// ============================================================
export interface PrestamoCalc {
  total_pagado: number;
  pagado_capital: number;
  pagado_interes: number;
  cuotas_restantes: number;
  proxima_cuota: Date;
  dias_hasta_proxima: number;
  vencida: boolean;
}

export function calcPrestamo(p: Prestamo, pagos: PagoPrestamo[]): PrestamoCalc {
  const pagosP = pagos.filter(pa => pa.prestamo_id === p.id);
  const pagadoCapital = pagosP.filter(pa => pa.tipo === 'capital').reduce((s, pa) => s + pa.monto, 0);
  const pagadoInteres = pagosP.filter(pa => pa.tipo === 'interes').reduce((s, pa) => s + pa.monto, 0);
  const totalPagado = pagadoCapital + pagadoInteres;
  const cuotasRestantes = p.cuota_mensual > 0 ? Math.ceil(p.saldo_actual / p.cuota_mensual) : 0;
  const ultimaPago = pagosP.sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime())[0];
  const base = ultimaPago ? new Date(ultimaPago.fecha) : new Date(p.fecha_inicio);
  const proximaCuota = addDays(base, 30);
  const diasHasta = daysBetween(new Date(), proximaCuota);
  return {
    total_pagado: totalPagado, pagado_capital: pagadoCapital, pagado_interes: pagadoInteres,
    cuotas_restantes: cuotasRestantes, proxima_cuota: proximaCuota,
    dias_hasta_proxima: diasHasta, vencida: diasHasta < 0,
  };
}

// ============================================================
// METAS — progreso y cumplimiento
// ============================================================
export interface MetaCalc {
  porcentaje_cumplimiento: number;
  restante: number;
  dias_restantes: number | null;
  estado: 'en_camino' | 'al_dia' | 'atrasada' | 'completada' | 'vencida';
}

export function calcMeta(m: Meta): MetaCalc {
  const pct = m.valor_objetivo > 0 ? (m.valor_actual / m.valor_objetivo) * 100 : 0;
  const restante = m.valor_objetivo - m.valor_actual;
  let diasRestantes: number | null = null;
  if (m.fecha_limite) diasRestantes = daysBetween(new Date(), new Date(m.fecha_limite));

  let estado: MetaCalc['estado'] = 'en_camino';
  if (pct >= 100) estado = 'completada';
  else if (diasRestantes !== null && diasRestantes < 0) estado = 'vencida';
  else if (diasRestantes !== null && diasRestantes <= 7 && pct < 80) estado = 'atrasada';
  else if (pct >= 50) estado = 'al_dia';

  return { porcentaje_cumplimiento: pct, restante, dias_restantes: diasRestantes, estado };
}

// ============================================================
// SALUD DE LA FINCA (0-100) — Centro de Control V3
// ============================================================
export interface FarmHealth {
  score: number;
  estado: 'excelente' | 'bueno' | 'regular' | 'critico';
  desglose: { financiero: number; produccion: number; inventario: number; alertas: number; metas: number };
  factores: string[];
}

export function calcFarmHealth(
  kpis: DashboardKPIs,
  semFin: ReturnType<typeof calcSemaforoFinanciero>,
  alertasCount: number,
  metas: Meta[],
): FarmHealth {
  let financiero = semFin.estado === 'verde' ? 30 : semFin.estado === 'amarillo' ? 15 : 0;
  let produccion = kpis.cumplimiento_pct >= 95 ? 25 : kpis.cumplimiento_pct >= 80 ? 15 : kpis.cumplimiento_pct > 0 ? 5 : 0;
  let inventario = Math.max(0, 15 - kpis.inventario_critico * 3 - kpis.inventos_por_vencer * 2);
  let alertasScore = Math.max(0, 15 - alertasCount * 2);
  let metasScore = 0;
  const activas = metas.filter(m => m.estado === 'activa');
  if (activas.length > 0) {
    const avg = activas.reduce((s, m) => s + Math.min(100, (m.valor_actual / m.valor_objetivo) * 100), 0) / activas.length;
    metasScore = Math.round((avg / 100) * 15);
  } else if (metas.length > 0) {
    metasScore = 15;
  }
  const score = financiero + produccion + inventario + alertasScore + metasScore;
  let estado: FarmHealth['estado'] = 'critico';
  if (score >= 80) estado = 'excelente';
  else if (score >= 60) estado = 'bueno';
  else if (score >= 40) estado = 'regular';
  const factores: string[] = [];
  if (semFin.estado === 'rojo') factores.push('Pérdida operacional');
  if (kpis.cumplimiento_pct < 80 && kpis.cumplimiento_pct > 0) factores.push('Producción por debajo del objetivo');
  if (kpis.inventario_critico > 0) factores.push(`${kpis.inventario_critico} insumos en stock crítico`);
  if (alertasCount > 5) factores.push(`${alertasCount} alertas activas`);
  if (factores.length === 0) factores.push('Todo en orden');
  return { score, estado, desglose: { financiero, produccion, inventario, alertas: alertasScore, metas: metasScore }, factores };
}

// ============================================================
// RENTABILIDAD POR LOTE, FILA, VEHÍCULO
// ============================================================
export function rentabilidadPorLote(
  lotes: Lote[], cosechas: Cosecha[], gastos: Gasto[], filas: Fila[],
): RentabilidadItem[] {
  return lotes.map(l => {
    const filasL = filas.filter(f => f.lote_id === l.id);
    const ingr = cosechas.filter(c => filasL.some(f => f.id === c.fila_id)).reduce((s, c) => s + c.cantidad_libras * c.precio_por_libra, 0);
    const costos = gastos.filter(g => g.parcela_id === l.parcela_id).reduce((s, g) => s + g.monto, 0) * 0.3;
    const ganancia = ingr - costos;
    return { id: l.id, nombre: l.nombre, ingresos: ingr, costos, ganancia, margen_pct: ingr > 0 ? (ganancia / ingr) * 100 : 0, roi: costos > 0 ? (ganancia / costos) * 100 : 0 };
  });
}

export function rentabilidadPorFila(
  filas: Fila[], cosechas: Cosecha[], gastos: Gasto[],
): RentabilidadItem[] {
  return filas.map(f => {
    const ingr = cosechas.filter(c => c.fila_id === f.id).reduce((s, c) => s + c.cantidad_libras * c.precio_por_libra, 0);
    const costos = gastos.filter(g => g.parcela_id === f.parcela_id).reduce((s, g) => s + g.monto, 0) * 0.1;
    const ganancia = ingr - costos;
    return { id: f.id, nombre: f.etiqueta || `Fila ${f.numero}`, ingresos: ingr, costos, ganancia, margen_pct: ingr > 0 ? (ganancia / ingr) * 100 : 0, roi: costos > 0 ? (ganancia / costos) * 100 : 0 };
  });
}

export function rentabilidadPorVehiculo(
  vehiculos: Vehiculo[], viajes: Viaje[], ventas: Venta[],
): RentabilidadItem[] {
  return vehiculos.map(v => {
    const viajesV = viajes.filter(vi => vi.vehiculo_id === v.id);
    const ingr = viajesV.reduce((s, vi) => s + vi.libras_transportadas * (ventas.find(ve => ve.vehiculo_id === v.id)?.precio_por_libra ?? 0), 0);
    const costos = viajesV.reduce((s, vi) => s + vi.combustible_costo, 0) + v.costo_mantenimiento;
    const ganancia = ingr - costos;
    return { id: v.id, nombre: v.nombre, ingresos: ingr, costos, ganancia, margen_pct: ingr > 0 ? (ganancia / ingr) * 100 : 0, roi: costos > 0 ? (ganancia / costos) * 100 : 0 };
  });
}

// ============================================================
// RENTABILIDAD POR PERIODO (diaria/semanal/mensual/anual)
// ============================================================
export type PeriodoTipo = 'diaria' | 'semanal' | 'mensual' | 'anual';

export interface RentabilidadPeriodo {
  etiqueta: string;
  ingresos: number;
  costos: number;
  ganancia: number;
  margen_pct: number;
}

export function rentabilidadPorPeriodo(
  tipo: PeriodoTipo, ventas: Venta[], gastos: Gasto[],
): RentabilidadPeriodo[] {
  const now = new Date();
  const results: RentabilidadPeriodo[] = [];
  if (tipo === 'diaria') {
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now); d.setDate(d.getDate() - i);
      const etiqueta = isSameDay(d, now) ? 'Hoy' : d.toLocaleDateString('es-DO', { weekday: 'short', day: 'numeric' });
      const ingr = ventas.filter(v => isSameDay(v.fecha, d)).reduce((s, v) => s + v.total, 0);
      const cost = gastos.filter(g => isSameDay(g.fecha, d)).reduce((s, g) => s + g.monto, 0);
      results.push({ etiqueta, ingresos: ingr, costos: cost, ganancia: ingr - cost, margen_pct: ingr > 0 ? ((ingr - cost) / ingr) * 100 : 0 });
    }
  } else if (tipo === 'semanal') {
    for (let i = 3; i >= 0; i--) {
      const end = new Date(now); end.setDate(end.getDate() - i * 7);
      const start = new Date(end); start.setDate(start.getDate() - 6);
      const etiqueta = `Sem ${4 - i}`;
      const ingr = ventas.filter(v => { const f = new Date(v.fecha); return f >= start && f <= end; }).reduce((s, v) => s + v.total, 0);
      const cost = gastos.filter(g => { const f = new Date(g.fecha); return f >= start && f <= end; }).reduce((s, g) => s + g.monto, 0);
      results.push({ etiqueta, ingresos: ingr, costos: cost, ganancia: ingr - cost, margen_pct: ingr > 0 ? ((ingr - cost) / ingr) * 100 : 0 });
    }
  } else if (tipo === 'mensual') {
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const nextM = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
      const etiqueta = d.toLocaleDateString('es-DO', { month: 'short' });
      const ingr = ventas.filter(v => { const f = new Date(v.fecha); return f >= d && f < nextM; }).reduce((s, v) => s + v.total, 0);
      const cost = gastos.filter(g => { const f = new Date(g.fecha); return f >= d && f < nextM; }).reduce((s, g) => s + g.monto, 0);
      results.push({ etiqueta, ingresos: ingr, costos: cost, ganancia: ingr - cost, margen_pct: ingr > 0 ? ((ingr - cost) / ingr) * 100 : 0 });
    }
  } else {
    const cy = now.getFullYear();
    for (let y = cy - 2; y <= cy; y++) {
      const etiqueta = `${y}`;
      const ingr = ventas.filter(v => new Date(v.fecha).getFullYear() === y).reduce((s, v) => s + v.total, 0);
      const cost = gastos.filter(g => new Date(g.fecha).getFullYear() === y).reduce((s, g) => s + g.monto, 0);
      results.push({ etiqueta, ingresos: ingr, costos: cost, ganancia: ingr - cost, margen_pct: ingr > 0 ? ((ingr - cost) / ingr) * 100 : 0 });
    }
  }
  return results;
}

// ============================================================
// AGENDA DEL DÍA — tareas para hoy
// ============================================================
export interface AgendaItem {
  tipo: string;
  titulo: string;
  detalle: string;
  prioridad: 'alta' | 'media' | 'baja';
  entidad_id?: string;
}

export function calcAgenda(
  riego: Riego[], fertilizacion: Fertilizacion[], semilleros: Semillero[],
  metas: Meta[],
): AgendaItem[] {
  const now = new Date();
  const items: AgendaItem[] = [];

  riego.forEach(r => {
    if (r.fecha_proximo_riego && daysBetween(now, new Date(r.fecha_proximo_riego)) <= 1) {
      items.push({ tipo: 'riego', titulo: 'Regar parcela', detalle: r.parcelas?.nombre || 'Sin parcela', prioridad: 'alta', entidad_id: r.id });
    }
  });
  fertilizacion.forEach(f => {
    if (f.fecha_proxima_aplicacion && daysBetween(now, new Date(f.fecha_proxima_aplicacion)) <= 1) {
      items.push({ tipo: 'fertilizacion', titulo: 'Fertilizar', detalle: `${f.producto} — ${f.parcelas?.nombre || ''}`, prioridad: 'alta', entidad_id: f.id });
    }
  });
  semilleros.forEach(s => {
    if (s.estado === 'activo') {
      const dias = daysBetween(now, addDays(new Date(s.fecha_siembra), s.dias_para_trasplante));
      if (dias >= 0 && dias <= 3) {
        items.push({ tipo: 'semillero', titulo: 'Trasplantar semillero', detalle: s.cultivos?.nombre || 'Semillero', prioridad: 'alta', entidad_id: s.id });
      }
    }
  });
  metas.forEach(m => {
    if (m.estado === 'activa' && m.fecha_limite) {
      const dias = daysBetween(now, new Date(m.fecha_limite));
      if (dias <= 7 && dias >= 0 && (m.valor_actual / m.valor_objetivo) < 100) {
        items.push({ tipo: 'meta', titulo: `Meta: ${m.titulo}`, detalle: `${dias} días restantes`, prioridad: 'media', entidad_id: m.id });
      }
    }
  });

  return items.sort((a, b) => {
    const order = { alta: 0, media: 1, baja: 2 };
    return order[a.prioridad] - order[b.prioridad];
  });
}
