import { useState, useEffect } from 'react';
import { DataProvider, useData } from './lib/DataContext';
import { Layout, type PageKey } from './components/Layout';
import { AlertasPanel } from './components/AlertasPanel';
import { Onboarding } from './components/Onboarding';
import { QuickActionFAB } from './components/QuickActionFAB';
import { generarAlertas } from './lib/alerts';
import { Spinner } from './components/ui';
import type { Profile } from './lib/types';
import { DashboardPage } from './pages/Dashboard';
import { SemillerosPage } from './pages/Semilleros';
import { CultivosPage } from './pages/Cultivos';
import { ParcelasPage } from './pages/Parcelas';
import { FilasPage } from './pages/Filas';
import { ProduccionPage } from './pages/Produccion';
import { CosechasPage } from './pages/Cosechas';
import { CalendarioPage } from './pages/Calendario';
import { LunarPage } from './pages/Lunar';
import { RiegoPage } from './pages/Riego';
import { FertilizacionPage } from './pages/Fertilizacion';
import { PlagasPage } from './pages/Plagas';
import { InventarioPage } from './pages/Inventario';
import { HerramientasPage } from './pages/Herramientas';
import { VehiculosPage } from './pages/Vehiculos';
import { GastosPage } from './pages/Gastos';
import { VentasPage } from './pages/Ventas';
import { ClientesPage } from './pages/Clientes';
import { MercadosPage } from './pages/Mercados';
import { CacaoPage } from './pages/Cacao';
import { ReportesPage } from './pages/Reportes';
import { ConfiguracionPage } from './pages/Configuracion';
import { AsistentePage } from './pages/Asistente';
import { TrabajadoresPage } from './pages/Trabajadores';
import { TrasplantesPage } from './pages/Trasplantes';
import { LotesPage } from './pages/Lotes';
import { ComprasPage } from './pages/Compras';
import { ClimaPage } from './pages/Clima';
import { MetasPage } from './pages/Metas';
import { CentroInteligenciaPage } from './pages/CentroInteligencia';

function AppInner() {
  const [page, setPage] = useState<PageKey>('dashboard');
  const [alertsOpen, setAlertsOpen] = useState(false);
  const [onboarded, setOnboarded] = useState<boolean>(false);
  const data = useData();

  useEffect(() => {
    const profileId = localStorage.getItem('mi-tierra-profile-id');
    if (profileId) setOnboarded(true);
  }, []);

  const handleOnboarded = (profile: Profile) => {
    localStorage.setItem('mi-tierra-profile-id', profile.id);
    setOnboarded(true);
  };

  if (!onboarded) {
    return <Onboarding onComplete={handleOnboarded} />;
  }

  if (data.loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <Spinner size="lg" />
          <p className="text-slate-400 mt-4 font-medium">Cargando Mi Tierra...</p>
        </div>
      </div>
    );
  }

  if (data.error) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="text-center max-w-md">
          <p className="text-red-600 font-semibold text-lg">Error de conexión</p>
          <p className="text-slate-500 mt-2 text-sm">{data.error}</p>
          <button onClick={() => data.refresh()} className="mt-4 px-4 py-2 bg-brand-600 text-white rounded-xl font-semibold">Reintentar</button>
        </div>
      </div>
    );
  }

  const alertas = data.config ? generarAlertas({
    parcelas: data.parcelas, cosechas: data.cosechas, gastos: data.gastos,
    inventario: data.inventario, ventas: data.ventas, prestamos: data.prestamos,
    semilleros: data.semilleros, plagas: data.plagas, riego: data.riego,
    metas: data.metas, trasplantes: data.trasplantes, trabajadores: data.trabajadores,
    config: data.config,
  }) : [];

  const pages: Record<PageKey, React.ReactNode> = {
    dashboard: <DashboardPage onNavigate={setPage} />,
    centrointeligencia: <CentroInteligenciaPage onNavigate={setPage} />,
    asistente: <AsistentePage />,
    semilleros: <SemillerosPage />,
    trasplantes: <TrasplantesPage />,
    cultivos: <CultivosPage />,
    parcelas: <ParcelasPage />,
    lotes: <LotesPage />,
    filas: <FilasPage />,
    produccion: <ProduccionPage />,
    cosechas: <CosechasPage />,
    calendario: <CalendarioPage />,
    lunar: <LunarPage />,
    clima: <ClimaPage />,
    metas: <MetasPage />,
    riego: <RiegoPage />,
    fertilizacion: <FertilizacionPage />,
    plagas: <PlagasPage />,
    inventario: <InventarioPage />,
    herramientas: <HerramientasPage />,
    vehiculos: <VehiculosPage />,
    trabajadores: <TrabajadoresPage />,
    gastos: <GastosPage />,
    ventas: <VentasPage />,
    compras: <ComprasPage />,
    clientes: <ClientesPage />,
    mercados: <MercadosPage />,
    cacao: <CacaoPage />,
    reportes: <ReportesPage />,
    configuracion: <ConfiguracionPage />,
  };

  return (
    <>
      <Layout current={page} onNavigate={setPage} onToggleAlerts={() => setAlertsOpen(true)}>
        {pages[page]}
      </Layout>
      <AlertasPanel open={alertsOpen} onClose={() => setAlertsOpen(false)} alertas={alertas} />
      <QuickActionFAB />
    </>
  );
}

export default function App() {
  return (
    <DataProvider>
      <AppInner />
    </DataProvider>
  );
}
