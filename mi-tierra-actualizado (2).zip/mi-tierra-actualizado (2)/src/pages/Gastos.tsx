import { useState } from 'react';
import { Plus, Pencil, Trash2, Receipt, Coins } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtMoney, fmtDate, todayISO, startOfMonth } from '../lib/format';
import { GASTO_SUBCATEGORIAS } from '../lib/calculations';
import { Button, Modal, Field, inputClass, Table, Th, Td, PageHeader, EmptyState, Card, Badge, KpiCard } from '../components/ui';
import type { Gasto } from '../lib/types';

const GRUPOS = Object.keys(GASTO_SUBCATEGORIAS);

const catColors: Record<string, 'slate' | 'green' | 'red' | 'amber' | 'blue' | 'earth'> = {
  'Inversión inicial': 'blue', 'Producción': 'green', 'Mano de obra': 'blue',
  'Transporte': 'red', 'Comercialización': 'amber', 'Otros': 'slate',
};

function findGroup(subcat: string): string {
  for (const [g, subs] of Object.entries(GASTO_SUBCATEGORIAS)) {
    if (subs.includes(subcat)) return g;
  }
  return 'Otros';
}

const empty = (): Partial<Gasto> => ({
  categoria: GRUPOS[0], subcategoria: '', descripcion: '', monto: 0, fecha: todayISO(),
  parcela_id: '', trabajador_id: '',
});

export function GastosPage() {
  const { gastos, parcelas, trabajadores, config } = useData();
  const crud = useCrud<Gasto>('gastos');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Gasto | null>(null);
  const [form, setForm] = useState<Partial<Gasto>>(empty());
  const moneda = config?.moneda || 'RD$';

  const openNew = () => { setEditing(null); setForm(empty()); setModal(true); };
  const openEdit = (g: Gasto) => { setEditing(g); setForm(g); setModal(true); };
  const save = async () => {
    const payload = {
      ...form,
      parcela_id: form.parcela_id || null,
      trabajador_id: form.trabajador_id || null,
      descripcion: form.descripcion || null,
      subcategoria: form.subcategoria || null,
    };
    if (editing) await crud.update(editing.id, payload);
    else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => { if (confirm('¿Eliminar gasto?')) await crud.remove(id); };

  const totalGastos = gastos.reduce((s, g) => s + g.monto, 0);
  const sMes = startOfMonth();
  const gastosMes = gastos.filter(g => new Date(g.fecha) >= sMes).reduce((s, g) => s + g.monto, 0);

  const now = new Date();
  const byMonth = new Map<string, number>();
  gastos.forEach(g => {
    const d = new Date(g.fecha);
    if (d.getFullYear() === now.getFullYear()) {
      const key = d.toLocaleDateString('es-DO', { month: 'short' });
      byMonth.set(key, (byMonth.get(key) ?? 0) + g.monto);
    }
  });

  const subcatsForGroup = GASTO_SUBCATEGORIAS[form.categoria || GRUPOS[0]] || [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Gastos"
        subtitle="Registro de egresos por categoría, subcategoría, parcela y trabajador"
        action={<Button onClick={openNew}><Plus size={18} /> Nuevo Gasto</Button>}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <KpiCard label="Total Gastos" value={fmtMoney(totalGastos, moneda)} icon={<Coins size={20} />} accent="red" subtitle={`${gastos.length} registros`} />
        <KpiCard label="Gastos del Mes" value={fmtMoney(gastosMes, moneda)} icon={<Receipt size={20} />} accent="amber" subtitle={now.toLocaleDateString('es-DO', { month: 'long', year: 'numeric' })} />
        <KpiCard label="Gastos del Año" value={fmtMoney(Array.from(byMonth.values()).reduce((s, v) => s + v, 0), moneda)} icon={<Coins size={20} />} accent="blue" subtitle={`${byMonth.size} meses con movimientos`} />
      </div>

      {byMonth.size > 0 && (
        <Card title="Gastos por Mes" className="p-0">
          <div className="p-5 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            {Array.from(byMonth.entries()).map(([mes, monto]) => (
              <div key={mes} className="p-3 rounded-xl bg-slate-50">
                <p className="text-xs text-slate-400 capitalize">{mes}</p>
                <p className="text-sm font-bold text-slate-800 tabular-nums">{fmtMoney(monto, moneda)}</p>
              </div>
            ))}
          </div>
        </Card>
      )}

      {gastos.length === 0 ? (
        <EmptyState icon={<Receipt size={32} />} title="Sin gastos registrados" message="Registra tus egresos para llevar el control de costos por categoría y parcela." action={<Button onClick={openNew}><Plus size={18} /> Registrar primer gasto</Button>} />
      ) : (
        <Card className="p-0">
          <Table>
            <thead><tr>
              <Th>Fecha</Th><Th>Categoría</Th><Th>Subcategoría</Th><Th>Descripción</Th>
              <Th>Parcela</Th><Th>Trabajador</Th><Th className="text-right">Monto</Th><Th></Th>
            </tr></thead>
            <tbody>
              {gastos.map(g => {
                const grupo = GRUPOS.includes(g.categoria) ? g.categoria : findGroup(g.categoria);
                return (
                  <tr key={g.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                    <Td className="whitespace-nowrap">{fmtDate(g.fecha)}</Td>
                    <Td><Badge color={catColors[grupo] || 'slate'}>{grupo}</Badge></Td>
                    <Td className="text-slate-600">{g.subcategoria || g.categoria}</Td>
                    <Td className="text-slate-600">{g.descripcion || '—'}</Td>
                    <Td className="text-slate-600">{g.parcelas?.nombre || '—'}</Td>
                    <Td className="text-slate-600">{g.trabajadores?.nombre || '—'}</Td>
                    <Td className="text-right tabular-nums font-bold text-red-600">{fmtMoney(g.monto, moneda)}</Td>
                    <Td>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" onClick={() => openEdit(g)}><Pencil size={14} /></Button>
                        <Button variant="ghost" size="sm" onClick={() => del(g.id)} className="text-red-600"><Trash2 size={14} /></Button>
                      </div>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </Card>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Gasto' : 'Nuevo Gasto'} size="lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Categoría" required>
            <select className={inputClass} value={form.categoria || GRUPOS[0]} onChange={e => setForm({ ...form, categoria: e.target.value, subcategoria: '' })}>
              {GRUPOS.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Subcategoría" required>
            <select className={inputClass} value={form.subcategoria || ''} onChange={e => setForm({ ...form, subcategoria: e.target.value })}>
              <option value="">— Seleccionar —</option>
              {subcatsForGroup.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Fecha" required><input type="date" className={inputClass} value={form.fecha || ''} onChange={e => setForm({ ...form, fecha: e.target.value })} /></Field>
          <Field label="Monto" required><input type="number" step="0.01" className={inputClass} value={form.monto ?? 0} onChange={e => setForm({ ...form, monto: +e.target.value })} /></Field>
          <div className="sm:col-span-2"><Field label="Descripción"><input className={inputClass} value={form.descripcion || ''} onChange={e => setForm({ ...form, descripcion: e.target.value })} placeholder="Detalle del gasto" /></Field></div>
          <Field label="Parcela">
            <select className={inputClass} value={form.parcela_id || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value })}>
              <option value="">— Ninguna —</option>
              {parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
            </select>
          </Field>
          <Field label="Trabajador">
            <select className={inputClass} value={form.trabajador_id || ''} onChange={e => setForm({ ...form, trabajador_id: e.target.value })}>
              <option value="">— Ninguno —</option>
              {trabajadores.map(t => <option key={t.id} value={t.id}>{t.nombre}</option>)}
            </select>
          </Field>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}
