import { useState } from 'react';
import { Plus, Pencil, Trash2, Rows as RowsIcon } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtDate, fmtNum } from '../lib/format';
import { Button, Modal, Field, inputClass, PageHeader, EmptyState, Card, Badge } from '../components/ui';
import type { Fila } from '../lib/types';

const empty = (parcelaId = ''): Partial<Fila> => ({
  parcela_id: parcelaId, numero: 1, etiqueta: '', cantidad_plantas: 0,
  fecha_trasplante: '', estado: 'activa', produccion_esperada_por_planta: 0,
});

export function FilasPage() {
  const { filas, parcelas, cultivos } = useData();
  const crud = useCrud<Fila>('filas');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Fila | null>(null);
  const [form, setForm] = useState<Partial<Fila>>(empty());

  const openNew = () => { setEditing(null); setForm(empty(parcelas[0]?.id || '')); setModal(true); };
  const openEdit = (f: Fila) => { setEditing(f); setForm(f); setModal(true); };
  const save = async () => {
    const payload = { ...form, fecha_trasplante: form.fecha_trasplante || null };
    if (editing) await crud.update(editing.id, payload); else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => { if (confirm('¿Eliminar fila?')) await crud.remove(id); };

  return (
    <div>
      <PageHeader title="Filas" subtitle="Filas de cultivo dentro de cada parcela" action={<Button onClick={openNew} disabled={parcelas.length === 0}><Plus size={18} /> Nueva Fila</Button>} />
      {filas.length === 0 ? (
        <EmptyState icon={<RowsIcon size={32} />} title="Sin filas registradas" message={parcelas.length === 0 ? 'Primero crea una parcela.' : 'Agrega filas a tus parcelas para registrar plantas y producción.'} action={parcelas.length > 0 ? <Button onClick={openNew}><Plus size={18} /> Crear fila</Button> : undefined} />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filas.map(f => {
            const parcela = parcelas.find(p => p.id === f.parcela_id);
            const cultivo = cultivos.find(c => c.id === parcela?.cultivo_id);
            const esperadaTotal = f.cantidad_plantas * (f.produccion_esperada_por_planta || cultivo?.produccion_esperada_por_planta || 0);
            return (
              <Card key={f.id} className="p-5">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <RowsIcon className="text-brand-600" size={18} />
                      <h3 className="font-bold text-slate-800">Fila {f.numero}{f.etiqueta ? ` · ${f.etiqueta}` : ''}</h3>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">{parcela?.nombre} {cultivo && `· ${cultivo.nombre}`}</p>
                  </div>
                  <Badge color={f.estado === 'activa' ? 'green' : 'slate'}>{f.estado}</Badge>
                </div>
                <div className="grid grid-cols-3 gap-3 mt-4 text-sm">
                  <div><p className="text-xs text-slate-400">Plantas</p><p className="font-bold text-slate-800">{fmtNum(f.cantidad_plantas, 0)}</p></div>
                  <div><p className="text-xs text-slate-400">Prod. esp.</p><p className="font-bold text-slate-800">{fmtNum(esperadaTotal, 1)} lb</p></div>
                  <div><p className="text-xs text-slate-400">Trasplante</p><p className="font-bold text-slate-800 text-xs">{f.fecha_trasplante ? fmtDate(f.fecha_trasplante) : '—'}</p></div>
                </div>
                <div className="flex gap-1 mt-3 pt-3 border-t border-slate-100">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(f)}><Pencil size={14} /></Button>
                  <Button variant="ghost" size="sm" onClick={() => del(f.id)} className="text-red-600"><Trash2 size={14} /></Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Fila' : 'Nueva Fila'}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Parcela" required>
            <select className={inputClass} value={form.parcela_id || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value })}>
              {parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
            </select>
          </Field>
          <Field label="Número"><input type="number" className={inputClass} value={form.numero ?? 1} onChange={e => setForm({ ...form, numero: +e.target.value })} /></Field>
          <Field label="Etiqueta"><input className={inputClass} value={form.etiqueta || ''} onChange={e => setForm({ ...form, etiqueta: e.target.value })} /></Field>
          <Field label="Cantidad de plantas"><input type="number" className={inputClass} value={form.cantidad_plantas ?? 0} onChange={e => setForm({ ...form, cantidad_plantas: +e.target.value })} /></Field>
          <Field label="Fecha de trasplante"><input type="date" className={inputClass} value={form.fecha_trasplante || ''} onChange={e => setForm({ ...form, fecha_trasplante: e.target.value })} /></Field>
          <Field label="Prod. esperada/planta (lb)"><input type="number" step="0.01" className={inputClass} value={form.produccion_esperada_por_planta ?? 0} onChange={e => setForm({ ...form, produccion_esperada_por_planta: +e.target.value })} /></Field>
          <Field label="Estado">
            <select className={inputClass} value={form.estado || 'activa'} onChange={e => setForm({ ...form, estado: e.target.value })}>
              <option value="activa">Activa</option><option value="inactiva">Inactiva</option><option value="cosechada">Cosechada</option>
            </select>
          </Field>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}
