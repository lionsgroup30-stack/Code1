import { useState } from 'react';
import { Plus, Pencil, Trash2, Leaf } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtMoney, fmtPct } from '../lib/format';
import { Button, Modal, Field, inputClass, PageHeader, EmptyState, Badge, Card } from '../components/ui';
import type { Cultivo } from '../lib/types';

const empty = (): Partial<Cultivo> => ({
  nombre: '', variedad: '', dias_germinacion: 7, dias_trasplante: 35,
  produccion_esperada_por_planta: 0, costo_esperado_por_planta: 0, costo_esperado_por_libra: 0,
  margen_objetivo: 30, color: '#10b981', activo: true,
});

export function CultivosPage() {
  const { cultivos, parcelas } = useData();
  const crud = useCrud<Cultivo>('cultivos');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Cultivo | null>(null);
  const [form, setForm] = useState<Partial<Cultivo>>(empty());

  const openNew = () => { setEditing(null); setForm(empty()); setModal(true); };
  const openEdit = (c: Cultivo) => { setEditing(c); setForm(c); setModal(true); };
  const save = async () => { if (editing) await crud.update(editing.id, form); else await crud.insert(form); setModal(false); };
  const del = async (id: string) => { if (confirm('¿Eliminar cultivo?')) await crud.remove(id); };

  return (
    <div>
      <PageHeader title="Cultivos" subtitle="Catálogo de cultivos y variedades con metas de producción y costo" action={<Button onClick={openNew}><Plus size={18} /> Nuevo Cultivo</Button>} />
      {cultivos.length === 0 ? (
        <EmptyState icon={<Leaf size={32} />} title="Sin cultivos" message="Registra cultivos para definir metas de producción y costos esperados." action={<Button onClick={openNew}><Plus size={18} /> Crear cultivo</Button>} />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {cultivos.map(c => {
            const numParcelas = parcelas.filter(p => p.cultivo_id === c.id).length;
            return (
              <Card key={c.id} className="p-5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: (c.color || '#10b981') + '20' }}>
                      <Leaf size={24} style={{ color: c.color || '#10b981' }} />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-800">{c.nombre}</h3>
                      {c.variedad && <p className="text-xs text-slate-400">{c.variedad}</p>}
                    </div>
                  </div>
                  <Badge color={c.activo ? 'green' : 'slate'}>{c.activo ? 'Activo' : 'Inactivo'}</Badge>
                </div>
                <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
                  <Info label="Parcelas" value={`${numParcelas}`} />
                  <Info label="Germinación" value={`${c.dias_germinacion} días`} />
                  <Info label="Trasplante" value={`${c.dias_trasplante} días`} />
                  <Info label="Prod./planta" value={`${c.produccion_esperada_por_planta} lb`} />
                  <Info label="Costo/planta" value={fmtMoney(c.costo_esperado_por_planta)} />
                  <Info label="Costo/libra" value={fmtMoney(c.costo_esperado_por_libra)} />
                </div>
                <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-100">
                  <span className="text-xs text-slate-400">Margen objetivo: <strong className="text-slate-700">{fmtPct(c.margen_objetivo, 0)}</strong></span>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm" onClick={() => openEdit(c)}><Pencil size={14} /></Button>
                    <Button variant="ghost" size="sm" onClick={() => del(c.id)} className="text-red-600"><Trash2 size={14} /></Button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Cultivo' : 'Nuevo Cultivo'} size="lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Nombre" required><input className={inputClass} value={form.nombre || ''} onChange={e => setForm({ ...form, nombre: e.target.value })} /></Field>
          <Field label="Variedad"><input className={inputClass} value={form.variedad || ''} onChange={e => setForm({ ...form, variedad: e.target.value })} /></Field>
          <Field label="Días germinación"><input type="number" className={inputClass} value={form.dias_germinacion ?? 7} onChange={e => setForm({ ...form, dias_germinacion: +e.target.value })} /></Field>
          <Field label="Días trasplante"><input type="number" className={inputClass} value={form.dias_trasplante ?? 35} onChange={e => setForm({ ...form, dias_trasplante: +e.target.value })} /></Field>
          <Field label="Prod. esperada/planta (lb)"><input type="number" step="0.01" className={inputClass} value={form.produccion_esperada_por_planta ?? 0} onChange={e => setForm({ ...form, produccion_esperada_por_planta: +e.target.value })} /></Field>
          <Field label="Costo esperado/planta"><input type="number" step="0.01" className={inputClass} value={form.costo_esperado_por_planta ?? 0} onChange={e => setForm({ ...form, costo_esperado_por_planta: +e.target.value })} /></Field>
          <Field label="Costo esperado/libra"><input type="number" step="0.01" className={inputClass} value={form.costo_esperado_por_libra ?? 0} onChange={e => setForm({ ...form, costo_esperado_por_libra: +e.target.value })} /></Field>
          <Field label="Margen objetivo (%)"><input type="number" step="0.1" className={inputClass} value={form.margen_objetivo ?? 30} onChange={e => setForm({ ...form, margen_objetivo: +e.target.value })} /></Field>
          <Field label="Color"><input type="color" className="h-11 w-full rounded-xl border border-slate-300" value={form.color || '#10b981'} onChange={e => setForm({ ...form, color: e.target.value })} /></Field>
          <Field label="Estado">
            <select className={inputClass} value={form.activo ? '1' : '0'} onChange={e => setForm({ ...form, activo: e.target.value === '1' })}>
              <option value="1">Activo</option><option value="0">Inactivo</option>
            </select>
          </Field>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return <div><p className="text-xs text-slate-400">{label}</p><p className="font-semibold text-slate-800">{value}</p></div>;
}
