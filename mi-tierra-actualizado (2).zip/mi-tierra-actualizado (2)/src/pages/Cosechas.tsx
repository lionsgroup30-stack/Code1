import { useState } from 'react';
import { Plus, Pencil, Trash2, ShoppingBasket } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtMoney, fmtNum, fmtDate, todayISO } from '../lib/format';
import { Button, Modal, Field, inputClass, Table, Th, Td, PageHeader, EmptyState, Card } from '../components/ui';
import type { Cosecha } from '../lib/types';

const empty = (parcelaId = ''): Partial<Cosecha> => ({
  parcela_id: parcelaId, fila_id: '', fecha: todayISO(), cantidad_libras: 0,
  precio_por_libra: 0, mercado_id: '', observaciones: '',
});

export function CosechasPage() {
  const { cosechas, parcelas, filas, mercados, config } = useData();
  const crud = useCrud<Cosecha>('cosechas');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Cosecha | null>(null);
  const [form, setForm] = useState<Partial<Cosecha>>(empty());

  const openNew = () => { setEditing(null); setForm(empty(parcelas[0]?.id || '')); setModal(true); };
  const openEdit = (c: Cosecha) => { setEditing(c); setForm(c); setModal(true); };
  const save = async () => {
    const payload = { ...form, fila_id: form.fila_id || null, mercado_id: form.mercado_id || null };
    if (editing) await crud.update(editing.id, payload); else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => { if (confirm('¿Eliminar cosecha?')) await crud.remove(id); };
  const moneda = config?.moneda || 'RD$';

  return (
    <div>
      <PageHeader title="Cosechas" subtitle="Registro de producción real por parcela y fila" action={<Button onClick={openNew} disabled={parcelas.length === 0}><Plus size={18} /> Nueva Cosecha</Button>} />
      {cosechas.length === 0 ? (
        <EmptyState icon={<ShoppingBasket size={32} />} title="Sin cosechas" message={parcelas.length === 0 ? 'Primero crea una parcela.' : 'Registra cosechas para comparar producción real vs esperada.'} action={parcelas.length > 0 ? <Button onClick={openNew}><Plus size={18} /> Registrar cosecha</Button> : undefined} />
      ) : (
        <Card className="p-0">
          <Table>
            <thead><tr>
              <Th>Fecha</Th><Th>Parcela</Th><Th>Fila</Th><Th>Mercado</Th>
              <Th className="text-right">Libras</Th><Th className="text-right">Precio/lb</Th>
              <Th className="text-right">Total</Th><Th></Th>
            </tr></thead>
            <tbody>
              {cosechas.map(c => (
                <tr key={c.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                  <Td>{fmtDate(c.fecha)}</Td>
                  <Td className="font-medium">{c.parcelas?.nombre || '—'}</Td>
                  <Td>{c.filas ? `Fila ${c.filas.numero}` : '—'}</Td>
                  <Td>{c.mercados?.nombre || '—'}</Td>
                  <Td className="text-right tabular-nums">{fmtNum(c.cantidad_libras)}</Td>
                  <Td className="text-right tabular-nums">{fmtMoney(c.precio_por_libra, moneda)}</Td>
                  <Td className="text-right tabular-nums font-bold">{fmtMoney(c.cantidad_libras * c.precio_por_libra, moneda)}</Td>
                  <Td>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" onClick={() => openEdit(c)}><Pencil size={14} /></Button>
                      <Button variant="ghost" size="sm" onClick={() => del(c.id)} className="text-red-600"><Trash2 size={14} /></Button>
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Cosecha' : 'Nueva Cosecha'}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Parcela" required>
            <select className={inputClass} value={form.parcela_id || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value })}>
              {parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
            </select>
          </Field>
          <Field label="Fila">
            <select className={inputClass} value={form.fila_id || ''} onChange={e => setForm({ ...form, fila_id: e.target.value })}>
              <option value="">— Toda la parcela —</option>
              {filas.filter(f => f.parcela_id === form.parcela_id).map(f => <option key={f.id} value={f.id}>Fila {f.numero}</option>)}
            </select>
          </Field>
          <Field label="Fecha" required><input type="date" className={inputClass} value={form.fecha || ''} onChange={e => setForm({ ...form, fecha: e.target.value })} /></Field>
          <Field label="Mercado">
            <select className={inputClass} value={form.mercado_id || ''} onChange={e => setForm({ ...form, mercado_id: e.target.value })}>
              <option value="">— Seleccionar —</option>
              {mercados.map(m => <option key={m.id} value={m.id}>{m.nombre}</option>)}
            </select>
          </Field>
          <Field label="Cantidad (libras)" required><input type="number" step="0.01" className={inputClass} value={form.cantidad_libras ?? 0} onChange={e => setForm({ ...form, cantidad_libras: +e.target.value })} /></Field>
          <Field label="Precio por libra"><input type="number" step="0.01" className={inputClass} value={form.precio_por_libra ?? 0} onChange={e => setForm({ ...form, precio_por_libra: +e.target.value })} /></Field>
          <div className="sm:col-span-2"><Field label="Observaciones"><textarea className={inputClass} rows={2} value={form.observaciones || ''} onChange={e => setForm({ ...form, observaciones: e.target.value })} /></Field></div>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}
