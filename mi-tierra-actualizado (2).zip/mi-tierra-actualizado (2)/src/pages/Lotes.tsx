import { useState } from 'react';
import { Plus, Pencil, Trash2, Grid2x2, Trees, Layers } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtNum, fmtDate } from '../lib/format';
import {
  Button, Modal, Field, inputClass, PageHeader, EmptyState, Card,
  Table, Th, Td, Badge, KpiCard,
} from '../components/ui';
import type { Lote } from '../lib/types';

const ESTADOS = ['activo', 'en_preparacion', 'inactivo'] as const;

const estadoBadge: Record<string, 'green' | 'amber' | 'slate'> = {
  activo: 'green',
  en_preparacion: 'amber',
  inactivo: 'slate',
};

const estadoLabel: Record<string, string> = {
  activo: 'Activo',
  en_preparacion: 'En preparación',
  inactivo: 'Inactivo',
};

const empty = (parcelaId = ''): Partial<Lote> => ({
  nombre: '',
  parcela_id: parcelaId,
  area_tareas: 0,
  estado: 'activo',
});

export function LotesPage() {
  const { lotes, parcelas, filas } = useData();
  const crud = useCrud<Lote>('lotes');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Lote | null>(null);
  const [form, setForm] = useState<Partial<Lote>>(empty());

  // ---- KPIs ----
  const total = lotes.length;
  const areaTotal = lotes.reduce((s, l) => s + (l.area_tareas || 0), 0);
  const activos = lotes.filter(l => l.estado === 'activo').length;
  const filasPorLote = total > 0
    ? lotes.reduce((s, l) => s + filas.filter(f => f.lote_id === l.id).length, 0) / total
    : 0;

  // ---- Helpers ----
  const parcelaNombre = (id: string) =>
    parcelas.find(p => p.id === id)?.nombre ?? '—';
  const filasCount = (loteId: string) =>
    filas.filter(f => f.lote_id === loteId).length;

  // ---- Handlers ----
  const openNew = () => {
    setEditing(null);
    setForm(empty(parcelas[0]?.id || ''));
    setModal(true);
  };
  const openEdit = (l: Lote) => { setEditing(l); setForm(l); setModal(true); };
  const save = async () => {
    const payload = { ...form, area_tareas: Number(form.area_tareas) || 0 };
    if (editing) await crud.update(editing.id, payload);
    else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => {
    if (confirm('¿Eliminar lote?')) await crud.remove(id);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Lotes"
        subtitle="Subdivisiones de parcelas"
        action={
          <Button onClick={openNew} disabled={parcelas.length === 0}>
            <Plus size={18} /> Nuevo Lote
          </Button>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          label="Total Lotes"
          value={`${total}`}
          subtitle={`${activos} activos · ${total - activos} inactivos`}
          icon={<Grid2x2 size={20} />}
          accent="brand"
        />
        <KpiCard
          label="Área Total"
          value={fmtNum(areaTotal, 1)}
          unit="tareas"
          subtitle="Suma de áreas de lotes"
          icon={<Layers size={20} />}
          accent="green"
        />
        <KpiCard
          label="Lotes Activos"
          value={`${activos}`}
          subtitle={total > 0 ? `${((activos / total) * 100).toFixed(0)}% del total` : '—'}
          icon={<Trees size={20} />}
          accent="amber"
        />
        <KpiCard
          label="Filas por Lote"
          value={fmtNum(filasPorLote, 1)}
          subtitle="Promedio de filas"
          icon={<Grid2x2 size={20} />}
          accent="blue"
        />
      </div>

      {/* Tabla o estado vacío */}
      {lotes.length === 0 ? (
        <EmptyState
          icon={<Grid2x2 size={32} />}
          title="Sin lotes registrados"
          message={
            parcelas.length === 0
              ? 'Primero crea una parcela para poder subdividirla en lotes.'
              : 'Subdivide tus parcelas en lotes para un control más detallado de filas y producción.'
          }
          action={
            parcelas.length > 0 ? (
              <Button onClick={openNew}><Plus size={18} /> Crear lote</Button>
            ) : undefined
          }
        />
      ) : (
        <Card className="overflow-hidden">
          <Table>
            <thead className="bg-slate-50/80">
              <tr>
                <Th>Nombre</Th>
                <Th>Parcela</Th>
                <Th>Área (tareas)</Th>
                <Th>Estado</Th>
                <Th>Filas</Th>
                <Th className="text-right">Acciones</Th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {lotes.map(l => {
                const numFilas = filasCount(l.id);
                return (
                  <tr key={l.id} className="hover:bg-slate-50/60 transition-colors">
                    <Td>
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-brand-50 flex items-center justify-center shrink-0">
                          <Grid2x2 className="text-brand-600" size={18} />
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-slate-800 truncate">{l.nombre}</p>
                          <p className="text-xs text-slate-400">Creado {fmtDate(l.created_at)}</p>
                        </div>
                      </div>
                    </Td>
                    <Td>
                      <span className="inline-flex items-center gap-1.5 text-slate-600">
                        <Trees size={14} className="text-slate-400" />
                        {parcelaNombre(l.parcela_id)}
                      </span>
                    </Td>
                    <Td>
                      <span className="font-semibold tabular-nums text-slate-800">
                        {fmtNum(l.area_tareas, 1)}
                      </span>
                      <span className="text-xs text-slate-400 ml-1">tareas</span>
                    </Td>
                    <Td>
                      <Badge color={estadoBadge[l.estado] ?? 'slate'}>
                        {estadoLabel[l.estado] ?? l.estado}
                      </Badge>
                    </Td>
                    <Td>
                      <span className="inline-flex items-center gap-1.5 text-slate-600">
                        <Layers size={14} className="text-slate-400" />
                        {numFilas}
                      </span>
                    </Td>
                    <Td className="text-right">
                      <div className="inline-flex gap-1">
                        <Button variant="ghost" size="sm" onClick={() => openEdit(l)}>
                          <Pencil size={14} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => del(l.id)}
                          className="text-red-600"
                        >
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </Card>
      )}

      {/* Modal formulario */}
      <Modal
        open={modal}
        onClose={() => setModal(false)}
        title={editing ? 'Editar Lote' : 'Nuevo Lote'}
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Nombre" required>
            <input
              className={inputClass}
              value={form.nombre || ''}
              onChange={e => setForm({ ...form, nombre: e.target.value })}
              placeholder="Ej. Lote A1"
            />
          </Field>
          <Field label="Parcela" required>
            <select
              className={inputClass}
              value={form.parcela_id || ''}
              onChange={e => setForm({ ...form, parcela_id: e.target.value })}
            >
              {parcelas.map(p => (
                <option key={p.id} value={p.id}>{p.nombre}</option>
              ))}
            </select>
          </Field>
          <Field label="Área (tareas)">
            <input
              type="number"
              step="0.01"
              min="0"
              className={inputClass}
              value={form.area_tareas ?? 0}
              onChange={e => setForm({ ...form, area_tareas: +e.target.value })}
            />
          </Field>
          <Field label="Estado">
            <select
              className={inputClass}
              value={form.estado || 'activo'}
              onChange={e => setForm({ ...form, estado: e.target.value })}
            >
              {ESTADOS.map(e => (
                <option key={e} value={e}>{estadoLabel[e]}</option>
              ))}
            </select>
          </Field>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving || !form.nombre || !form.parcela_id}>
            {editing ? 'Guardar' : 'Crear'}
          </Button>
        </div>
      </Modal>
    </div>
  );
}
