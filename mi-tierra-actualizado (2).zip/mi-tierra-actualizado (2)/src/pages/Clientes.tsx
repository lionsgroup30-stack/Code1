import { useState } from 'react';
import { Plus, Pencil, Trash2, Users, Phone, Mail, Trophy, Award } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtMoney } from '../lib/format';
import { Button, Modal, Field, inputClass, Table, Th, Td, PageHeader, EmptyState, Card, Badge, StatBar } from '../components/ui';
import type { Cliente } from '../lib/types';

const empty = (): Partial<Cliente> => ({
  nombre: '', telefono: '', email: '', direccion: '', credito_limite: 0,
});

export function ClientesPage() {
  const { clientes, ventas, config } = useData();
  const crud = useCrud<Cliente>('clientes');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Cliente | null>(null);
  const [form, setForm] = useState<Partial<Cliente>>(empty());
  const moneda = config?.moneda || 'RD$';

  const openNew = () => { setEditing(null); setForm(empty()); setModal(true); };
  const openEdit = (c: Cliente) => { setEditing(c); setForm(c); setModal(true); };
  const save = async () => {
    const payload = { ...form, telefono: form.telefono || null, email: form.email || null, direccion: form.direccion || null };
    if (editing) await crud.update(editing.id, payload);
    else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => { if (confirm('¿Eliminar cliente?')) await crud.remove(id); };

  const stats = clientes.map(c => {
    const ventasC = ventas.filter(v => v.cliente_id === c.id);
    const totalCompras = ventasC.reduce((s, v) => s + v.total, 0);
    const balancePend = ventasC.filter(v => v.estado_pago === 'pendiente').reduce((s, v) => s + v.total, 0);
    return { cliente: c, totalCompras, balancePend, numVentas: ventasC.length };
  }).sort((a, b) => b.totalCompras - a.totalCompras);

  const ranking = stats.map((s, i) => ({ ...s, ranking: i + 1 }));
  const top3 = ranking.slice(0, 3);
  const maxCompras = top3[0]?.totalCompras || 1;

  const rankBadge = (pos: number) => {
    if (pos === 1) return { color: 'bg-amber-100 text-amber-700', icon: <Trophy size={16} className="text-amber-500" /> };
    if (pos === 2) return { color: 'bg-slate-200 text-slate-600', icon: <Award size={16} className="text-slate-400" /> };
    if (pos === 3) return { color: 'bg-orange-100 text-orange-700', icon: <Award size={16} className="text-orange-500" /> };
    return { color: 'bg-slate-100 text-slate-400', icon: null };
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Clientes"
        subtitle="Gestión de clientes, compras y balances pendientes"
        action={<Button onClick={openNew}><Plus size={18} /> Nuevo Cliente</Button>}
      />

      {/* Top 3 ranking */}
      {top3.length > 0 && top3.some(t => t.totalCompras > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {top3.map(({ cliente, totalCompras, balancePend, numVentas, ranking: pos }) => {
            const rb = rankBadge(pos);
            return (
              <Card key={cliente.id} className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${rb.color}`}>
                      #{pos}
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-800">{cliente.nombre}</h3>
                      <p className="text-xs text-slate-400">{numVentas} compras</p>
                    </div>
                  </div>
                  {rb.icon}
                </div>
                <div className="space-y-2">
                  <StatBar value={totalCompras} max={maxCompras} color="brand" label="Compras" />
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-xs text-slate-400">Total compras</span>
                    <span className="font-bold text-slate-900 tabular-nums">{fmtMoney(totalCompras, moneda)}</span>
                  </div>
                  {balancePend > 0 && (
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-amber-600">Balance pendiente</span>
                      <span className="font-semibold text-amber-700 tabular-nums">{fmtMoney(balancePend, moneda)}</span>
                    </div>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {clientes.length === 0 ? (
        <EmptyState icon={<Users size={32} />} title="Sin clientes registrados" message="Registra tus clientes para llevar el control de compras, balances y rankings." action={<Button onClick={openNew}><Plus size={18} /> Registrar primer cliente</Button>} />
      ) : (
        <Card className="p-0">
          <Table>
            <thead><tr>
              <Th>#</Th><Th>Nombre</Th><Th>Contacto</Th>
              <Th className="text-right">Crédito límite</Th>
              <Th className="text-right">Total compras</Th>
              <Th className="text-right">Balance pend.</Th><Th></Th>
            </tr></thead>
            <tbody>
              {ranking.map(({ cliente, totalCompras, balancePend, ranking: pos }) => (
                <tr key={cliente.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                  <Td>
                    <span className={`inline-flex items-center justify-center w-7 h-7 rounded-lg text-xs font-bold ${rankBadge(pos).color}`}>
                      {pos}
                    </span>
                  </Td>
                  <Td className="font-medium">{cliente.nombre}</Td>
                  <Td>
                    <div className="flex flex-col gap-0.5 text-xs text-slate-500">
                      {cliente.telefono && <span className="flex items-center gap-1"><Phone size={12} /> {cliente.telefono}</span>}
                      {cliente.email && <span className="flex items-center gap-1"><Mail size={12} /> {cliente.email}</span>}
                      {!cliente.telefono && !cliente.email && <span>—</span>}
                    </div>
                  </Td>
                  <Td className="text-right tabular-nums">{fmtMoney(cliente.credito_limite, moneda)}</Td>
                  <Td className="text-right tabular-nums font-bold">{fmtMoney(totalCompras, moneda)}</Td>
                  <Td className="text-right tabular-nums">
                    {balancePend > 0 ? <Badge color="amber">{fmtMoney(balancePend, moneda)}</Badge> : <span className="text-slate-400">—</span>}
                  </Td>
                  <Td>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" onClick={() => openEdit(cliente)}><Pencil size={14} /></Button>
                      <Button variant="ghost" size="sm" onClick={() => del(cliente.id)} className="text-red-600"><Trash2 size={14} /></Button>
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Cliente' : 'Nuevo Cliente'}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2"><Field label="Nombre" required><input className={inputClass} value={form.nombre || ''} onChange={e => setForm({ ...form, nombre: e.target.value })} /></Field></div>
          <Field label="Teléfono"><input className={inputClass} value={form.telefono || ''} onChange={e => setForm({ ...form, telefono: e.target.value })} /></Field>
          <Field label="Email"><input className={inputClass} value={form.email || ''} onChange={e => setForm({ ...form, email: e.target.value })} /></Field>
          <div className="sm:col-span-2"><Field label="Dirección"><input className={inputClass} value={form.direccion || ''} onChange={e => setForm({ ...form, direccion: e.target.value })} /></Field></div>
          <Field label="Crédito límite"><input type="number" step="0.01" className={inputClass} value={form.credito_limite ?? 0} onChange={e => setForm({ ...form, credito_limite: +e.target.value })} /></Field>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}
