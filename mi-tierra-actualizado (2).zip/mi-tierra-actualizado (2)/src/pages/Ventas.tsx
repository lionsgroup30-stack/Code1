import { useState } from 'react';
import { Plus, Pencil, Trash2, ShoppingBag, DollarSign, AlertCircle } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtMoney, fmtNum, fmtDate, todayISO } from '../lib/format';
import { Button, Modal, Field, inputClass, Table, Th, Td, PageHeader, EmptyState, Card, Badge, KpiCard } from '../components/ui';
import type { Venta } from '../lib/types';

const empty = (): Partial<Venta> => ({
  cliente_id: '', mercado_id: '', parcela_id: '', fecha: todayISO(), producto: '',
  cantidad_libras: 0, precio_por_libra: 0, total: 0, metodo_pago: 'efectivo', estado_pago: 'pagado',
});

export function VentasPage() {
  const { ventas, clientes, mercados, parcelas, config } = useData();
  const crud = useCrud<Venta>('ventas');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Venta | null>(null);
  const [form, setForm] = useState<Partial<Venta>>(empty());
  const moneda = config?.moneda || 'RD$';

  const openNew = () => { setEditing(null); setForm(empty()); setModal(true); };
  const openEdit = (v: Venta) => { setEditing(v); setForm(v); setModal(true); };
  const save = async () => {
    const total = (form.cantidad_libras ?? 0) * (form.precio_por_libra ?? 0);
    const payload = {
      ...form, total,
      cliente_id: form.cliente_id || null,
      mercado_id: form.mercado_id || null,
      parcela_id: form.parcela_id || null,
    };
    if (editing) await crud.update(editing.id, payload);
    else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => { if (confirm('¿Eliminar venta?')) await crud.remove(id); };

  const totalVentas = ventas.reduce((s, v) => s + v.total, 0);
  const cobrosPendientes = ventas.filter(v => v.estado_pago === 'pendiente');
  const totalPendiente = cobrosPendientes.reduce((s, v) => s + v.total, 0);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Ventas"
        subtitle="Registro de ventas y estado de cobros"
        action={<Button onClick={openNew}><Plus size={18} /> Nueva Venta</Button>}
      />

      {/* Resumen */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <KpiCard label="Total Ventas" value={fmtMoney(totalVentas, moneda)} icon={<DollarSign size={20} />} accent="green" subtitle={`${ventas.length} ventas`} />
        <KpiCard label="Cobros Pendientes" value={fmtMoney(totalPendiente, moneda)} icon={<AlertCircle size={20} />} accent="amber" subtitle={`${cobrosPendientes.length} por cobrar`} />
        <KpiCard label="Ventas Cobradas" value={fmtMoney(totalVentas - totalPendiente, moneda)} icon={<ShoppingBag size={20} />} accent="blue" subtitle="Pagadas" />
      </div>

      {ventas.length === 0 ? (
        <EmptyState icon={<ShoppingBag size={32} />} title="Sin ventas registradas" message="Registra tus ventas para llevar el control de ingresos y cobros pendientes." action={<Button onClick={openNew}><Plus size={18} /> Registrar primera venta</Button>} />
      ) : (
        <Card className="p-0">
          <Table>
            <thead><tr>
              <Th>Fecha</Th><Th>Cliente</Th><Th>Mercado</Th><Th>Producto</Th>
              <Th className="text-right">Libras</Th><Th className="text-right">Precio/lb</Th>
              <Th className="text-right">Total</Th><Th>Estado</Th><Th></Th>
            </tr></thead>
            <tbody>
              {ventas.map(v => (
                <tr key={v.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                  <Td className="whitespace-nowrap">{fmtDate(v.fecha)}</Td>
                  <Td className="font-medium">{v.clientes?.nombre || '—'}</Td>
                  <Td className="text-slate-600">{v.mercados?.nombre || '—'}</Td>
                  <Td className="text-slate-600">{v.producto || '—'}</Td>
                  <Td className="text-right tabular-nums">{fmtNum(v.cantidad_libras)}</Td>
                  <Td className="text-right tabular-nums">{fmtMoney(v.precio_por_libra, moneda)}</Td>
                  <Td className="text-right tabular-nums font-bold">{fmtMoney(v.total, moneda)}</Td>
                  <Td><Badge color={v.estado_pago === 'pagado' ? 'green' : 'amber'}>{v.estado_pago}</Badge></Td>
                  <Td>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" onClick={() => openEdit(v)}><Pencil size={14} /></Button>
                      <Button variant="ghost" size="sm" onClick={() => del(v.id)} className="text-red-600"><Trash2 size={14} /></Button>
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Venta' : 'Nueva Venta'} size="lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Cliente">
            <select className={inputClass} value={form.cliente_id || ''} onChange={e => setForm({ ...form, cliente_id: e.target.value })}>
              <option value="">— Seleccionar —</option>
              {clientes.map(c => <option key={c.id} value={c.id}>{c.nombre}</option>)}
            </select>
          </Field>
          <Field label="Mercado">
            <select className={inputClass} value={form.mercado_id || ''} onChange={e => setForm({ ...form, mercado_id: e.target.value })}>
              <option value="">— Seleccionar —</option>
              {mercados.map(m => <option key={m.id} value={m.id}>{m.nombre}</option>)}
            </select>
          </Field>
          <Field label="Parcela">
            <select className={inputClass} value={form.parcela_id || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value })}>
              <option value="">— Ninguna —</option>
              {parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
            </select>
          </Field>
          <Field label="Fecha" required><input type="date" className={inputClass} value={form.fecha || ''} onChange={e => setForm({ ...form, fecha: e.target.value })} /></Field>
          <div className="sm:col-span-2"><Field label="Producto"><input className={inputClass} value={form.producto || ''} onChange={e => setForm({ ...form, producto: e.target.value })} placeholder="Producto vendido" /></Field></div>
          <Field label="Cantidad (libras)" required><input type="number" step="0.01" className={inputClass} value={form.cantidad_libras ?? 0} onChange={e => setForm({ ...form, cantidad_libras: +e.target.value })} /></Field>
          <Field label="Precio por libra" required><input type="number" step="0.01" className={inputClass} value={form.precio_por_libra ?? 0} onChange={e => setForm({ ...form, precio_por_libra: +e.target.value })} /></Field>
          <Field label="Método de pago">
            <select className={inputClass} value={form.metodo_pago || 'efectivo'} onChange={e => setForm({ ...form, metodo_pago: e.target.value })}>
              <option value="efectivo">Efectivo</option>
              <option value="transferencia">Transferencia</option>
              <option value="cheque">Cheque</option>
            </select>
          </Field>
          <Field label="Estado de pago">
            <select className={inputClass} value={form.estado_pago || 'pagado'} onChange={e => setForm({ ...form, estado_pago: e.target.value })}>
              <option value="pagado">Pagado</option>
              <option value="pendiente">Pendiente</option>
            </select>
          </Field>
          <div className="sm:col-span-2 p-3 rounded-xl bg-slate-50 flex items-center justify-between">
            <span className="text-sm text-slate-500">Total calculado</span>
            <span className="text-lg font-bold text-slate-900 tabular-nums">{fmtMoney((form.cantidad_libras ?? 0) * (form.precio_por_libra ?? 0), moneda)}</span>
          </div>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}
