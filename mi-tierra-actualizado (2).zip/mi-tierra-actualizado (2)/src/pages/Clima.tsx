import { useState, useEffect, useCallback } from 'react';
import { CloudSun, Droplets, Wind, Thermometer, Calendar, MapPin, RefreshCw, AlertCircle } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { fmtNum, fmtDate } from '../lib/format';
import { PageHeader, Card, KpiCard, Spinner, EmptyState } from '../components/ui';

interface ForecastDay {
  fecha: string;
  temp_max: number;
  temp_min: number;
  precipitacion: number;
  viento: number;
  codigo: number;
  descripcion: string;
}

interface WeatherResponse {
  current: {
    temperatura: number;
    humedad: number;
    precipitacion: number;
    viento: number;
    codigo: number;
    descripcion: string;
  };
  forecast: ForecastDay[];
  location: { lat: number; lon: number };
}

const WEATHER_ICONS: Record<number, string> = {
  0: '☀️', 1: '🌤️', 2: '⛅', 3: '☁️', 45: '🌫️', 48: '🌫️',
  51: '🌦️', 53: '🌦️', 55: '🌧️', 61: '🌧️', 63: '🌧️', 65: '🌧️',
  71: '🌨️', 73: '🌨️', 75: '❄️', 77: '❄️',
  80: '🌧️', 81: '🌧️', 82: '⛈️', 95: '⛈️', 96: '⛈️', 99: '⛈️',
};

export function ClimaPage() {
  const data = useData();
  const [weather, setWeather] = useState<WeatherResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const lat = data.config?.latitud || 18.4861;
  const lon = data.config?.longitud || -69.9312;

  const fetchWeather = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      const res = await fetch(`${supabaseUrl}/functions/v1/clima?lat=${lat}&lon=${lon}`, {
        headers: { Authorization: `Bearer ${supabaseKey}` },
      });
      if (!res.ok) throw new Error(`Error ${res.status}`);
      const json = await res.json();
      if (json.error) throw new Error(json.error);
      setWeather(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al obtener el clima');
    } finally {
      setLoading(false);
    }
  }, [lat, lon]);

  useEffect(() => { fetchWeather(); }, [fetchWeather]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Clima"
        subtitle="Condiciones meteorológicas y pronóstico agrícola"
        action={
          <button onClick={fetchWeather} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm font-medium transition-all">
            <RefreshCw size={16} className={loading ? 'animate-spin' : ''} /> Actualizar
          </button>
        }
      />

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="text-center">
            <Spinner size="lg" />
            <p className="text-slate-400 mt-4">Obteniendo datos del clima...</p>
          </div>
        </div>
      ) : error ? (
        <Card>
          <div className="flex items-center gap-3 p-4">
            <AlertCircle className="text-red-500" size={24} />
            <div>
              <p className="font-semibold text-slate-800">Error al cargar el clima</p>
              <p className="text-sm text-slate-500">{error}</p>
            </div>
          </div>
        </Card>
      ) : !weather ? (
        <EmptyState icon={<CloudSun size={32} />} title="Sin datos" message="No se pudo obtener información del clima." />
      ) : (
        <>
          {/* Current weather */}
          <div className="bg-blue-600 rounded-2xl p-6 text-white">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 text-blue-100 text-sm">
                  <MapPin size={16} />
                  <span>{data.config?.nombre_finca || 'Mi Finca'} · Lat {lat.toFixed(4)}, Lon {lon.toFixed(4)}</span>
                </div>
                <div className="flex items-center gap-4 mt-4">
                  <span className="text-5xl">{WEATHER_ICONS[weather.current.codigo] || '🌤️'}</span>
                  <div>
                    <p className="text-5xl font-bold">{fmtNum(weather.current.temperatura)}°C</p>
                    <p className="text-blue-100 text-lg">{weather.current.descripcion}</p>
                  </div>
                </div>
              </div>
              <div className="text-right text-blue-100 text-sm">
                <p>{new Date().toLocaleDateString('es-DO', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
                <p className="capitalize">{new Date().toLocaleTimeString('es-DO', { hour: '2-digit', minute: '2-digit' })}</p>
              </div>
            </div>
          </div>

          {/* Current conditions KPIs */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <KpiCard icon={<Thermometer size={20} />} label="Temperatura" value={`${fmtNum(weather.current.temperatura)}°C`} accent="red" />
            <KpiCard icon={<Droplets size={20} />} label="Humedad" value={`${fmtNum(weather.current.humedad)}%`} accent="blue" />
            <KpiCard icon={<Wind size={20} />} label="Viento" value={`${fmtNum(weather.current.viento)} km/h`} accent="slate" />
            <KpiCard icon={<Droplets size={20} />} label="Precipitación" value={`${fmtNum(weather.current.precipitacion)} mm`} accent="green" />
          </div>

          {/* 7-day forecast */}
          <Card>
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
              <Calendar size={18} /> Pronóstico 7 días
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
              {weather.forecast.map((day, i) => (
                <div key={i} className="p-3 rounded-xl bg-slate-50 text-center">
                  <p className="text-xs font-semibold text-slate-500 capitalize">
                    {i === 0 ? 'Hoy' : new Date(day.fecha).toLocaleDateString('es-DO', { weekday: 'short' })}
                  </p>
                  <p className="text-2xl my-2">{WEATHER_ICONS[day.codigo] || '🌤️'}</p>
                  <p className="text-sm font-bold text-slate-800">{fmtNum(day.temp_max)}°</p>
                  <p className="text-xs text-slate-400">{fmtNum(day.temp_min)}°</p>
                  {day.precipitacion > 0 && (
                    <p className="text-xs text-blue-500 mt-1 flex items-center justify-center gap-1">
                      <Droplets size={10} /> {fmtNum(day.precipitacion)}mm
                    </p>
                  )}
                </div>
              ))}
            </div>
          </Card>

          {/* Agricultural recommendations */}
          <Card>
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
              <CloudSun size={18} /> Recomendaciones Agrícolas
            </h3>
            <div className="space-y-2">
              {weather.current.humedad < 50 && (
                <RecItem color="amber" text="Humedad baja — considerar aumentar frecuencia de riego" />
              )}
              {weather.current.humedad > 85 && (
                <RecItem color="blue" text="Humedad alta — vigilar aparición de hongos y plagas" />
              )}
              {weather.current.precipitacion > 5 && (
                <RecItem color="blue" text="Lluvia detectada — posponer aplicación de fertilizantes" />
              )}
              {weather.current.viento > 25 && (
                <RecItem color="red" text="Vientos fuertes — evitar aplicación de agroquímicos" />
              )}
              {weather.current.temperatura > 35 && (
                <RecItem color="red" text="Temperatura alta — asegurar hidratación de trabajadores y plantas" />
              )}
              {weather.forecast.slice(1, 4).every(d => d.precipitacion < 1) && (
                <RecItem color="amber" text="Próximos 3 días sin lluvia — planificar riego" />
              )}
              {weather.current.humedad >= 50 && weather.current.humedad <= 85 && weather.current.precipitacion < 5 && (
                <RecItem color="green" text="Condiciones favorables para actividades de campo" />
              )}
            </div>
          </Card>
        </>
      )}
    </div>
  );
}

function RecItem({ color, text }: { color: 'green' | 'amber' | 'red' | 'blue'; text: string }) {
  const colors = {
    green: 'bg-brand-50 text-brand-700 border-brand-200',
    amber: 'bg-amber-50 text-amber-700 border-amber-200',
    red: 'bg-red-50 text-red-700 border-red-200',
    blue: 'bg-blue-50 text-blue-700 border-blue-200',
  };
  return (
    <div className={`p-3 rounded-xl border text-sm font-medium ${colors[color]}`}>
      {text}
    </div>
  );
}
