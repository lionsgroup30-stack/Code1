import { useData } from '../lib/DataContext';
import type { Venta, Gasto } from '../lib/types';
import {
  rentabilidadPorParcela, rentabilidadPorMercado, rentabilidadPorCliente,
  rentabilidadPorCultivo, rentabilidadPorTrabajador, calcCostosParcela,
  calcSemaforoCostos, parcelaProduccionEsperada, parcelaProduccionReal,
  compararMercados, calcPuntoEquilibrio, calcDashboard, calcSemaforoFinanciero,
  rentabilidadPorLote, rentabilidadPorFila, rentabilidadPorVehiculo,
  rentabilidadPorPeriodo, type PeriodoTipo,
} from '../lib/calculations';
import { fmtMoney, fmtNum, fmtPct } from '../lib/format';
import { PageHeader, Card, Table, Th, Td, Semaforo, EmptyState, KpiCard, Badge } from '../components/ui';
import type { PageKey } from '../components/Layout';
import { useState } from 'react';
import {
  Trophy, TrendingUp, TrendingDown, Award, Store, Users, Sprout,
  HardHat, Scale, Target, BarChart3, MapPin, AlertTriangle, Truck, Grid2x2, Rows,
} from 'lucide-react';

export function CentroInteligenciaPage({ onNavigate }: { onNavigate: (k: PageKey) => void }) {
  const data = useData();
  if (!data.config) return null;
  const config = data.config;
  const moneda = config.moneda;

  const kpis = calcDashboard(
    data.ventas, data.gastos, data.cosechas, data.inventario, data.clientes,
    data.prestamos, config, data.parcelas, data.filas, data.viajes,
    data.vehiculos, data.mercados, data.trabajadores, 0,
  );
  const semFin = calcSemaforoFinanciero(kpis, config);

  const rentParcelas = rentabilidadPorParcela(data.parcelas, data.cosechas, data.gastos, data.ventas).sort((a, b) => b.ganancia - a.ganancia);
  const rentMercados = rentabilidadPorMercado(data.ventas, data.mercados).filter(r => r.ingresos > 0).sort((a, b) => b.ganancia - a.ganancia);
  const rentClientes = rentabilidadPorCliente(data.ventas, data.clientes).filter(r => r.ingresos > 0).sort((a, b) => b.ingresos - a.ingresos);
  const rentCultivos = rentabilidadPorCultivo(data.cultivos, data.parcelas, data.cosechas, data.gastos).filter(r => r.ingresos > 0).sort((a, b) => b.ganancia - a.ganancia);
  const rentTrabajadores = rentabilidadPorTrabajador(data.trabajadores, data.cosechas, data.gastos).sort((a, b) => b.ganancia - a.ganancia);

  const mejorParcela = rentParcelas[0];
  const peorParcela = rentParcelas[rentParcelas.length - 1];
  const mejorMercado = rentMercados[0];
  const mejorCliente = rentClientes[0];
  const mejorCultivo = rentCultivos[0];
  const mejorTrabajador = rentTrabajadores[0];

  const rentLotes = rentabilidadPorLote(data.lotes, data.cosechas, data.gastos, data.filas).sort((a, b) => b.ganancia - a.ganancia);
  const rentFilas = rentabilidadPorFila(data.filas, data.cosechas, data.gastos).sort((a, b) => b.ganancia - a.ganancia).slice(0, 10);
  const rentVehiculos = rentabilidadPorVehiculo(data.vehiculos, data.viajes, data.ventas).sort((a, b) => b.ganancia - a.ganancia);

  // Cost comparison for markets
  const costoBaseLibra = kpis.costo_por_libra || 0;
  const comparacion = compararMercados(data.mercados, costoBaseLibra);

  // Break-even
  const costosFijos = data.gastos.filter(g => ['Inversión inicial', 'Construcciones', 'Equipos', 'Herramientas'].includes(g.categoria)).reduce((s, g) => s + g.monto, 0);
  const precioPromedio = kpis.precio_promedio || 0;
  const puntoEquilibrio = calcPuntoEquilibrio(costosFijos, precioPromedio, costoBaseLibra);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Centro de Inteligencia"
        subtitle="Análisis de rentabilidad, rankings y comparativas para toma de decisiones"
      />

      {/* Resumen financiero */}
      <div className={`rounded-2xl p-6 border ${
        semFin.estado === 'verde' ? 'bg-brand-50 border-brand-200' :
        semFin.estado === 'amarillo' ? 'bg-amber-50 border-amber-200' :
        'bg-red-50 border-red-200'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Trophy className="text-amber-500" size={28} />
            <div>
              <p className="text-sm font-semibold text-slate-500 uppercase tracking-wide">Estado Financiero</p>
              <p className="text-2xl font-bold text-slate-900">{semFin.etiqueta}</p>
            </div>
            <Semaforo estado={semFin.estado} label={`Margen ${fmtPct(semFin.margen_real)}`} size="lg" />
          </div>
          <div className="grid grid-cols-3 gap-6 text-right">
            <div><p className="text-xs text-slate-400 font-semibold">INGRESOS</p><p className="text-lg font-bold text-slate-800">{fmtMoney(kpis.ingresos_total, moneda)}</p></div>
            <div><p className="text-xs text-slate-400 font-semibold">GASTOS</p><p className="text-lg font-bold text-slate-800">{fmtMoney(kpis.gastos_total, moneda)}</p></div>
            <div><p className="text-xs text-slate-400 font-semibold">GANANCIA</p><p className={`text-lg font-bold ${kpis.ganancia >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtMoney(kpis.ganancia, moneda)}</p></div>
          </div>
        </div>
      </div>

      {/* Best/Worst highlights */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {mejorParcela && (
          <KpiCard icon={<TrendingUp size={20} />} label="Mejor Parcela" value={mejorParcela.nombre} accent="green" subtitle={`Ganancia: ${fmtMoney(mejorParcela.ganancia, moneda)}`} />
        )}
        {peorParcela && peorParcela.ganancia < mejorParcela?.ganancia && (
          <KpiCard icon={<TrendingDown size={20} />} label="Peor Parcela" value={peorParcela.nombre} accent="red" subtitle={`Ganancia: ${fmtMoney(peorParcela.ganancia, moneda)}`} />
        )}
        {mejorMercado && (
          <KpiCard icon={<Store size={20} />} label="Mejor Mercado" value={mejorMercado.nombre} accent="blue" subtitle={`Ganancia: ${fmtMoney(mejorMercado.ganancia, moneda)}`} />
        )}
        {mejorCliente && (
          <KpiCard icon={<Users size={20} />} label="Mejor Cliente" value={mejorCliente.nombre} accent="green" subtitle={`Ingresos: ${fmtMoney(mejorCliente.ingresos, moneda)}`} />
        )}
        {mejorCultivo && (
          <KpiCard icon={<Sprout size={20} />} label="Mejor Cultivo" value={mejorCultivo.nombre} accent="green" subtitle={`Ganancia: ${fmtMoney(mejorCultivo.ganancia, moneda)}`} />
        )}
        {mejorTrabajador && (
          <KpiCard icon={<HardHat size={20} />} label="Mejor Trabajador" value={mejorTrabajador.nombre} accent="blue" subtitle={`Ganancia: ${fmtMoney(mejorTrabajador.ganancia, moneda)}`} />
        )}
      </div>

      {/* Rankings grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <RankingCard title="Ranking de Parcelas" icon={<BarChart3 size={18} />} items={rentParcelas} moneda={moneda} onNavigate={onNavigate} pageKey="parcelas" />
        <RankingCard title="Ranking de Mercados" icon={<Store size={18} />} items={rentMercados} moneda={moneda} onNavigate={onNavigate} pageKey="mercados" />
        <RankingCard title="Ranking de Clientes" icon={<Users size={18} />} items={rentClientes} moneda={moneda} onNavigate={onNavigate} pageKey="clientes" />
        <RankingCard title="Ranking de Cultivos" icon={<Sprout size={18} />} items={rentCultivos} moneda={moneda} onNavigate={onNavigate} pageKey="cultivos" />
      </div>

      {/* Trabajadores ranking */}
      {rentTrabajadores.length > 0 && (
        <Card>
          <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><HardHat size={18} /> Ranking de Trabajadores por Rentabilidad</h3>
          <Table>
            <thead><tr>
              <Th>#</Th><Th>Trabajador</Th><Th className="text-right">Ingresos</Th>
              <Th className="text-right">Costos</Th><Th className="text-right">Ganancia</Th><Th className="text-right">ROI</Th><Th>Estado</Th>
            </tr></thead>
            <tbody>
              {rentTrabajadores.map((r, i) => (
                <tr key={r.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                  <Td className="font-bold text-slate-400">{i + 1}</Td>
                  <Td className="font-medium text-slate-700">{r.nombre}</Td>
                  <Td className="text-right tabular-nums">{fmtMoney(r.ingresos, moneda)}</Td>
                  <Td className="text-right tabular-nums text-red-600">{fmtMoney(r.costos, moneda)}</Td>
                  <Td className={`text-right tabular-nums font-bold ${r.ganancia >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtMoney(r.ganancia, moneda)}</Td>
                  <Td className="text-right tabular-nums">{fmtPct(r.roi)}</Td>
                  <Td><Semaforo estado={r.margen_pct >= 20 ? 'verde' : r.margen_pct >= 5 ? 'amarillo' : 'rojo'} label={fmtPct(r.margen_pct)} size="sm" /></Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      )}

      {/* Lotes, Filas, Vehiculos rankings */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {rentLotes.length > 0 && (
          <RankingCard title="Rentabilidad por Lote" icon={<Grid2x2 size={18} />} items={rentLotes} moneda={moneda} onNavigate={onNavigate} pageKey="lotes" />
        )}
        {rentFilas.length > 0 && (
          <RankingCard title="Rentabilidad por Fila" icon={<Rows size={18} />} items={rentFilas} moneda={moneda} onNavigate={onNavigate} pageKey="filas" />
        )}
        {rentVehiculos.length > 0 && (
          <RankingCard title="Rentabilidad por Vehículo" icon={<Truck size={18} />} items={rentVehiculos} moneda={moneda} onNavigate={onNavigate} pageKey="vehiculos" />
        )}
      </div>

      {/* Period rentability */}
      <PeriodRentabilidad ventas={data.ventas} gastos={data.gastos} moneda={moneda} />

      {/* Market comparison */}
      {comparacion.length > 0 && (
        <Card>
          <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Scale size={18} /> Comparación de Mercados</h3>
          <Table>
            <thead><tr>
              <Th>Mercado</Th><Th className="text-right">Precio/Lb</Th><Th className="text-right">Transporte</Th>
              <Th className="text-right">Precio Neto</Th><Th className="text-right">Rentabilidad/Lb</Th><Th>Recomendación</Th>
            </tr></thead>
            <tbody>
              {comparacion.map(c => (
                <tr key={c.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                  <Td className="font-medium text-slate-700">{c.nombre}</Td>
                  <Td className="text-right tabular-nums">{fmtMoney(c.precio_libra, moneda)}</Td>
                  <Td className="text-right tabular-nums text-red-600">{fmtMoney(c.costo_transporte, moneda)}</Td>
                  <Td className="text-right tabular-nums font-semibold">{fmtMoney(c.precio_neto, moneda)}</Td>
                  <Td className={`text-right tabular-nums font-bold ${c.rentabilidad_libra >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtMoney(c.rentabilidad_libra, moneda)}</Td>
                  <Td>{c.es_mejor ? <Badge color="green"><Award size={12} className="inline mr-1" />Mejor opción</Badge> : <span className="text-slate-400 text-sm">—</span>}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      )}

      {/* Break-even analysis */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <KpiCard icon={<Target size={20} />} label="Punto de Equilibrio" value={fmtNum(puntoEquilibrio)} unit="lbs" accent="blue" subtitle="Libras a vender para cubrir costos fijos" />
        <KpiCard icon={<Scale size={20} />} label="Costo Base por Libra" value={fmtMoney(costoBaseLibra, moneda)} accent="amber" subtitle="Costo promedio de producción" />
        <KpiCard icon={<TrendingUp size={20} />} label="Precio Promedio Venta" value={fmtMoney(precioPromedio, moneda)} unit="/lb" accent="green" subtitle="Precio promedio de venta" />
      </div>

      {/* Cost analysis per parcela */}
      {data.parcelas.length > 0 && (
        <Card>
          <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><BarChart3 size={18} /> Análisis de Costos por Parcela</h3>
          <Table>
            <thead><tr>
              <Th>Parcela</Th><Th className="text-right">Costo Total</Th><Th className="text-right">Costo/Planta</Th>
              <Th className="text-right">Costo/Libra</Th><Th className="text-right">Costo/Tarea</Th><Th>Estado</Th>
            </tr></thead>
            <tbody>
              {data.parcelas.map(p => {
                const costos = calcCostosParcela(p, data.gastos, data.filas, data.cosechas);
                const sem = calcSemaforoCostos(p.cultivos, costos, config.porcentaje_alerta_costos || 20);
                return (
                  <tr key={p.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                    <Td className="font-medium text-slate-700">{p.nombre}</Td>
                    <Td className="text-right tabular-nums">{fmtMoney(costos.costo_total, moneda)}</Td>
                    <Td className="text-right tabular-nums">{fmtMoney(costos.costo_por_planta, moneda)}</Td>
                    <Td className="text-right tabular-nums">{fmtMoney(costos.costo_por_libra, moneda)}</Td>
                    <Td className="text-right tabular-nums">{fmtMoney(costos.costo_por_tarea, moneda)}</Td>
                    <Td><Semaforo estado={sem.estado} label={sem.alerta ? 'Sobre costo' : 'En rango'} size="sm" /></Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </Card>
      )}
    </div>
  );
}

function RankingCard({ title, icon, items, moneda, onNavigate, pageKey }: {
  title: string;
  icon: React.ReactNode;
  items: { id: string; nombre: string; ingresos: number; costos: number; ganancia: number; margen_pct: number; roi: number }[];
  moneda: string;
  onNavigate: (k: PageKey) => void;
  pageKey: PageKey;
}) {
  return (
    <Card>
      <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
        {icon} {title}
        <button onClick={() => onNavigate(pageKey)} className="ml-auto text-xs text-brand-600 hover:underline">Ver detalles →</button>
      </h3>
      {items.length === 0 ? <EmptyState message="Sin datos disponibles" /> : (
        <div className="space-y-2">
          {items.slice(0, 8).map((r, i) => (
            <div key={r.id} className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors">
              <span className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                i === 0 ? 'bg-amber-100 text-amber-700' : i === 1 ? 'bg-slate-200 text-slate-600' : i === 2 ? 'bg-orange-100 text-orange-700' : 'bg-slate-100 text-slate-400'
              }`}>{i + 1}</span>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-slate-700 truncate">{r.nombre}</p>
                <p className="text-xs text-slate-400">{fmtMoney(r.ingresos, moneda)} ingresos · {fmtPct(r.margen_pct)} margen</p>
              </div>
              <span className={`font-bold tabular-nums ${r.ganancia >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtMoney(r.ganancia, moneda)}</span>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}

function PeriodRentabilidad({ ventas, gastos, moneda }: { ventas: Venta[]; gastos: Gasto[]; moneda: string }) {
  const [periodo, setPeriodo] = useState<PeriodoTipo>('mensual');
  const data = rentabilidadPorPeriodo(periodo, ventas, gastos);
  const periodos: { key: PeriodoTipo; label: string }[] = [
    { key: 'diaria', label: 'Diaria' }, { key: 'semanal', label: 'Semanal' },
    { key: 'mensual', label: 'Mensual' }, { key: 'anual', label: 'Anual' },
  ];
  return (
    <Card>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-slate-800 flex items-center gap-2"><TrendingUp size={18} /> Rentabilidad por Periodo</h3>
        <div className="flex gap-1.5">
          {periodos.map(p => (
            <button key={p.key} onClick={() => setPeriodo(p.key)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${periodo === p.key ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
              {p.label}
            </button>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
        {data.map((d, i) => (
          <div key={i} className="p-3 rounded-xl bg-slate-50 text-center">
            <p className="text-xs text-slate-400 font-semibold capitalize">{d.etiqueta}</p>
            <p className={`text-sm font-bold mt-1 ${d.ganancia >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtMoney(d.ganancia, moneda)}</p>
            <p className="text-[10px] text-slate-400 mt-0.5">{fmtPct(d.margen_pct)} margen</p>
          </div>
        ))}
      </div>
    </Card>
  );
}
