import { useState } from 'react';
import { Plus, Pencil, Trash2, Truck } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { calcVehiculoStats } from '../lib/calculations';
import { fmtMoney, fmtNum, fmtDate, todayISO } from '../lib/format';
import { Button, Modal, Field, inputClass, PageHeader, EmptyState, Card } from '../components/ui';
import type { Vehiculo, Viaje } from '../lib/types';

export function VehiculosPage() {
  const { vehiculos, viajes, config } = useData();
  const vCrud = useCrud<Vehiculo>('vehiculos');
  const viaCrud = useCrud<Viaje>('viajes');
  const [vModal, setVModal] = useState(false);
  const [viaModal, setViaModal] = useState(false);
  const [editing, setEditing] = useState<Vehiculo | null>(null);
  const [vForm, setVForm] = useState<Partial<Vehiculo>>({});
  const [viaForm, setViaForm] = useState<Partial<Viaje>>({});
  const moneda = config?.moneda || 'RD$';

  const openVNew = () => { setEditing(null); setVForm({ nombre: '', modelo: '', placa: '', kilometraje: 0 }); setVModal(true); };
  const openVEdit = (v: Vehiculo) => { setEditing(v); setVForm(v); setVModal(true); };
  const saveV = async () => { if (editing) await vCrud.update(editing.id, vForm); else await vCrud.insert(vForm); setVModal(false); };
  const delV = async (id: string) => { if (confirm('¿Eliminar vehículo?')) await vCrud.remove(id); };

  const openViaNew = (vid: string) => { setViaForm({ vehiculo_id: vid, fecha: todayISO(), kilometros: 0, combustible_litros: 0, combustible_costo: 0, sacos_transportados: 0, libras_transportadas: 0 }); setViaModal(true); };
  const saveVia = async () => { await viaCrud.insert(viaForm); setViaModal(false); };

  return (
    <div className="space-y-6">
      <PageHeader title="Vehículos" subtitle="Control de transporte, combustible y costos por viaje" action={<Button onClick={openVNew}><Plus size={18} /> Nuevo Vehículo</Button>} />

      {vehiculos.length === 0 ? (
        <EmptyState icon={<Truck size={32} />} title="Sin vehículos" message="Registra tus vehículos para calcular costos por viaje, libra y saco transportado." action={<Button onClick={openVNew}><Plus size={18} /> Agregar vehículo</Button>} />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {vehiculos.map(v => {
            const stats = calcVehiculoStats(v, viajes);
            const viajeroViajes = viajes.filter(vi => vi.vehiculo_id === v.id).slice(0, 5);
            return (
              <Card key={v.id} className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center"><Truck className="text-slate-600" size={24} /></div>
                    <div>
                      <h3 className="font-bold text-slate-800">{v.nombre}</h3>
                      <p className="text-xs text-slate-400">{v.modelo} {v.placa && `· ${v.placa}`}</p>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm" onClick={() => openVEdit(v)}><Pencil size={14} /></Button>
                    <Button variant="ghost" size="sm" onClick={() => delV(v.id)} className="text-red-600"><Trash2 size={14} /></Button>
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-3 text-sm mb-4">
                  <Stat label="Viajes" value={`${stats.total_viajes}`} />
                  <Stat label="Costo/viaje" value={fmtMoney(stats.costo_por_viaje, moneda)} />
                  <Stat label="Costo/libra" value={fmtMoney(stats.costo_por_libra, moneda)} />
                  <Stat label="Costo/saco" value={fmtMoney(stats.costo_por_saco, moneda)} />
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 mb-3">
                  <span className="text-sm text-slate-600">Costo total: <strong className="text-slate-800">{fmtMoney(stats.costo_total, moneda)}</strong></span>
                  <span className="text-sm text-slate-600">Km: <strong className="text-slate-800">{fmtNum(v.kilometraje, 0)}</strong></span>
                </div>
                <Button size="sm" variant="secondary" onClick={() => openViaNew(v.id)}><Plus size={14} /> Registrar viaje</Button>
                {viajeroViajes.length > 0 && (
                  <div className="mt-3 space-y-1.5">
                    <p className="text-xs font-semibold text-slate-400 uppercase">Viajes recientes</p>
                    {viajeroViajes.map(vi => (
                      <div key={vi.id} className="flex justify-between text-xs text-slate-600 py-1.5 border-b border-slate-50">
                        <span>{fmtDate(vi.fecha)} · {vi.origen || '—'} → {vi.destino || '—'}</span>
                        <span className="font-semibold">{fmtMoney(vi.combustible_costo, moneda)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      <Modal open={vModal} onClose={() => setVModal(false)} title={editing ? 'Editar Vehículo' : 'Nuevo Vehículo'}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Nombre" required><input className={inputClass} value={vForm.nombre || ''} onChange={e => setVForm({ ...vForm, nombre: e.target.value })} /></Field>
          <Field label="Modelo"><input className={inputClass} value={vForm.modelo || ''} onChange={e => setVForm({ ...vForm, modelo: e.target.value })} /></Field>
          <Field label="Placa"><input className={inputClass} value={vForm.placa || ''} onChange={e => setVForm({ ...vForm, placa: e.target.value })} /></Field>
          <Field label="Kilometraje"><input type="number" className={inputClass} value={vForm.kilometraje ?? 0} onChange={e => setVForm({ ...vForm, kilometraje: +e.target.value })} /></Field>
          <Field label="Fecha mantenimiento"><input type="date" className={inputClass} value={vForm.fecha_mantenimiento || ''} onChange={e => setVForm({ ...vForm, fecha_mantenimiento: e.target.value })} /></Field>
          <Field label="Costo mantenimiento"><input type="number" step="0.01" className={inputClass} value={vForm.costo_mantenimiento ?? 0} onChange={e => setVForm({ ...vForm, costo_mantenimiento: +e.target.value })} /></Field>
        </div>
        <div className="flex justify-end gap-2 mt-5"><Button variant="secondary" onClick={() => setVModal(false)}>Cancelar</Button><Button onClick={saveV} disabled={vCrud.saving}>{editing ? 'Guardar' : 'Crear'}</Button></div>
      </Modal>

      <Modal open={viaModal} onClose={() => setViaModal(false)} title="Registrar Viaje">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Fecha"><input type="date" className={inputClass} value={viaForm.fecha || ''} onChange={e => setViaForm({ ...viaForm, fecha: e.target.value })} /></Field>
          <Field label="Origen"><input className={inputClass} value={viaForm.origen || ''} onChange={e => setViaForm({ ...viaForm, origen: e.target.value })} /></Field>
          <Field label="Destino"><input className={inputClass} value={viaForm.destino || ''} onChange={e => setViaForm({ ...viaForm, destino: e.target.value })} /></Field>
          <Field label="Kilómetros"><input type="number" step="0.1" className={inputClass} value={viaForm.kilometros ?? 0} onChange={e => setViaForm({ ...viaForm, kilometros: +e.target.value })} /></Field>
          <Field label="Combustible (litros)"><input type="number" step="0.1" className={inputClass} value={viaForm.combustible_litros ?? 0} onChange={e => setViaForm({ ...viaForm, combustible_litros: +e.target.value })} /></Field>
          <Field label="Combustible (costo)"><input type="number" step="0.01" className={inputClass} value={viaForm.combustible_costo ?? 0} onChange={e => setViaForm({ ...viaForm, combustible_costo: +e.target.value })} /></Field>
          <Field label="Sacos transportados"><input type="number" className={inputClass} value={viaForm.sacos_transportados ?? 0} onChange={e => setViaForm({ ...viaForm, sacos_transportados: +e.target.value })} /></Field>
          <Field label="Libras transportadas"><input type="number" step="0.01" className={inputClass} value={viaForm.libras_transportadas ?? 0} onChange={e => setViaForm({ ...viaForm, libras_transportadas: +e.target.value })} /></Field>
        </div>
        <div className="flex justify-end gap-2 mt-5"><Button variant="secondary" onClick={() => setViaModal(false)}>Cancelar</Button><Button onClick={saveVia} disabled={viaCrud.saving}>Registrar</Button></div>
      </Modal>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return <div><p className="text-xs text-slate-400">{label}</p><p className="font-semibold text-slate-800 text-sm">{value}</p></div>;
}
