import { useState } from 'react';
import { Plus, Pencil, Trash2, MoveRight, Sprout, Calendar, HardHat } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtDate, fmtInt, todayISO, daysBetween } from '../lib/format';
import { Button, Modal, Field, inputClass, PageHeader, EmptyState, Card, Table, Th, Td, Badge, KpiCard } from '../components/ui';
import type { Trasplante } from '../lib/types';

const empty = (): Partial<Trasplante> => ({
  semillero_id: '', parcela_id: '', lote_id: '', fila_id: '', fecha: todayISO(),
  cantidad_plantas: 0, trabajador_id: '', observaciones: '',
});

export function TrasplantesPage() {
  const { trasplantes, parcelas, lotes, filas, semilleros, trabajadores } = useData();
  const crud = useCrud<Trasplante>('trasplantes');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Trasplante | null>(null);
  const [form, setForm] = useState<Partial<Trasplante>>(empty());

  const openNew = () => { setEditing(null); setForm(empty()); setModal(true); };
  const openEdit = (t: Trasplante) => { setEditing(t); setForm(t); setModal(true); };

  const save = async () => {
    const payload = {
      ...form,
      semillero_id: form.semillero_id || null,
      lote_id: form.lote_id || null,
      fila_id: form.fila_id || null,
      trabajador_id: form.trabajador_id || null,
      observaciones: form.observaciones || null,
    };
    if (editing) await crud.update(editing.id, payload);
    else await crud.insert(payload);
    setModal(false);
  };

  const del = async (id: string) => { if (confirm('¿Eliminar trasplante?')) await crud.remove(id); };

  const totalTrasplantes = trasplantes.length;
  const totalPlantas = trasplantes.reduce((s, t) => s + (t.cantidad_plantas || 0), 0);
  const proximos = trasplantes.filter(t => {
    const d = daysBetween(t.fecha);
    return d >= -7 && d <= 0;
  }).length;
  const atrasados = trasplantes.filter(t => daysBetween(t.fecha) > 0).length;

  const semilleroLabel = (id: string | null) => {
    if (!id) return null;
    const s = semilleros.find(x => x.id === id);
    return s?.cultivos?.nombre || s?.variedad || 'Semillero';
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Trasplantes"
        subtitle="Movimiento de plántulas de semillero a campo"
        action={<Button onClick={openNew} disabled={parcelas.length === 0}><Plus size={18} /> Nuevo Trasplante</Button>}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="Total Trasplantes" value={fmtInt(totalTrasplantes)} icon={<Sprout size={20} />} accent="green" subtitle={`${totalPlantas.toLocaleString('es-DO')} plantas`} />
        <KpiCard label="Plantas Trasplantadas" value={fmtInt(totalPlantas)} icon={<MoveRight size={20} />} accent="blue" subtitle="Acumulado histórico" />
        <KpiCard label="Próximos (7 días)" value={fmtInt(proximos)} icon={<Calendar size={20} />} accent="amber" subtitle="Programados esta semana" />
        <KpiCard label="Atrasados" value={fmtInt(atrasados)} icon={<HardHat size={20} />} accent="red" subtitle="Fecha vencida" />
      </div>

      {trasplantes.length === 0 ? (
        <EmptyState
          icon={<Sprout size={32} />}
          title="Sin trasplantes registrados"
          message={parcelas.length === 0 ? 'Primero crea una parcela para registrar trasplantes.' : 'Registra el movimiento de plántulas del semillero al campo.'}
          action={parcelas.length > 0 ? <Button onClick={openNew}><Plus size={18} /> Registrar trasplante</Button> : undefined}
        />
      ) : (
        <Card className="p-0">
          <Table>
            <thead><tr>
              <Th>Fecha</Th><Th>Semillero</Th><Th>Parcela</Th><Th>Lote</Th><Th>Fila</Th>
              <Th className="text-right">Plantas</Th><Th>Trabajador</Th><Th></Th>
            </tr></thead>
            <tbody>
              {trasplantes.map(t => {
                const dias = daysBetween(t.fecha);
                return (
                  <tr key={t.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                    <Td className="whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <span>{fmtDate(t.fecha)}</span>
                        {dias > 0 && <Badge color="red">Atrasado</Badge>}
                        {dias >= -7 && dias < 0 && <Badge color="amber">Próximo</Badge>}
                      </div>
                    </Td>
                    <Td className="font-medium">{semilleroLabel(t.semillero_id) || '—'}</Td>
                    <Td className="font-medium">{t.parcelas?.nombre || '—'}</Td>
                    <Td className="text-slate-600">{t.lotes?.nombre || '—'}</Td>
                    <Td className="text-slate-600">{t.filas ? `Fila ${t.filas.numero}` : '—'}</Td>
                    <Td className="text-right tabular-nums font-bold">{fmtInt(t.cantidad_plantas)}</Td>
                    <Td className="text-slate-600">{t.trabajadores?.nombre || '—'}</Td>
                    <Td>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" onClick={() => openEdit(t)}><Pencil size={14} /></Button>
                        <Button variant="ghost" size="sm" onClick={() => del(t.id)} className="text-red-600"><Trash2 size={14} /></Button>
                      </div>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </Card>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Trasplante' : 'Nuevo Trasplante'} size="lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Semillero">
            <select className={inputClass} value={form.semillero_id || ''} onChange={e => setForm({ ...form, semillero_id: e.target.value })}>
              <option value="">— Ninguno —</option>
              {semilleros.map(s => <option key={s.id} value={s.id}>{s.variedad || s.cultivos?.nombre || 'Semillero'}</option>)}
            </select>
          </Field>
          <Field label="Parcela" required>
            <select className={inputClass} value={form.parcela_id || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value, lote_id: '', fila_id: '' })}>
              <option value="">— Seleccionar —</option>
              {parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
            </select>
          </Field>
          <Field label="Lote" hint="Opcional — filtrado por parcela">
            <select className={inputClass} value={form.lote_id || ''} onChange={e => setForm({ ...form, lote_id: e.target.value })} disabled={!form.parcela_id}>
              <option value="">— Ninguno —</option>
              {lotes.filter(l => l.parcela_id === form.parcela_id).map(l => <option key={l.id} value={l.id}>{l.nombre}</option>)}
            </select>
          </Field>
          <Field label="Fila" hint="Opcional — filtrado por parcela">
            <select className={inputClass} value={form.fila_id || ''} onChange={e => setForm({ ...form, fila_id: e.target.value })} disabled={!form.parcela_id}>
              <option value="">— Ninguna —</option>
              {filas.filter(f => f.parcela_id === form.parcela_id).map(f => <option key={f.id} value={f.id}>Fila {f.numero}{f.etiqueta ? ` · ${f.etiqueta}` : ''}</option>)}
            </select>
          </Field>
          <Field label="Fecha" required><input type="date" className={inputClass} value={form.fecha || ''} onChange={e => setForm({ ...form, fecha: e.target.value })} /></Field>
          <Field label="Cantidad de plantas" required><input type="number" className={inputClass} value={form.cantidad_plantas ?? 0} onChange={e => setForm({ ...form, cantidad_plantas: +e.target.value })} /></Field>
          <Field label="Trabajador">
            <select className={inputClass} value={form.trabajador_id || ''} onChange={e => setForm({ ...form, trabajador_id: e.target.value })}>
              <option value="">— Ninguno —</option>
              {trabajadores.map(t => <option key={t.id} value={t.id}>{t.nombre}</option>)}
            </select>
          </Field>
          <div className="sm:col-span-2"><Field label="Observaciones"><textarea className={inputClass} rows={2} value={form.observaciones || ''} onChange={e => setForm({ ...form, observaciones: e.target.value })} /></Field></div>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}
