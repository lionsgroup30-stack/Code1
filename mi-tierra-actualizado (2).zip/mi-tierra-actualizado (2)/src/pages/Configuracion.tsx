import { useState } from 'react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { Button, Field, inputClass, PageHeader, Card } from '../components/ui';
import { Settings, Save, CheckCircle2 } from 'lucide-react';
import type { Configuracion } from '../lib/types';

export function ConfiguracionPage() {
  const { config, refresh } = useData();
  const crud = useCrud<Configuracion>('configuracion');
  const [form, setForm] = useState<Partial<Configuracion>>(config || {});
  const [saved, setSaved] = useState(false);

  const save = async () => {
    await crud.update('1', form);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    refresh();
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <PageHeader title="Configuración" subtitle="Parámetros globales del sistema" />

      <Card className="p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-brand-100 flex items-center justify-center"><Settings className="text-brand-600" size={20} /></div>
          <h3 className="font-bold text-slate-800">Parámetros Generales</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Nombre de la finca"><input className={inputClass} value={form.nombre_finca || ''} onChange={e => setForm({ ...form, nombre_finca: e.target.value })} /></Field>
          <Field label="Moneda"><input className={inputClass} value={form.moneda || 'RD$'} onChange={e => setForm({ ...form, moneda: e.target.value })} /></Field>
          <Field label="Capital inicial" hint="Capital de arranque del negocio"><input type="number" step="0.01" className={inputClass} value={form.capital_inicial ?? 0} onChange={e => setForm({ ...form, capital_inicial: +e.target.value })} /></Field>
          <Field label="Margen objetivo (%)" hint="Por encima = semáforo verde"><input type="number" step="0.1" className={inputClass} value={form.margen_objetivo ?? 30} onChange={e => setForm({ ...form, margen_objetivo: +e.target.value })} /></Field>
          <Field label="Alerta de costo (%)" hint="Alertar cuando el costo supere este porcentaje"><input type="number" step="0.1" className={inputClass} value={form.porcentaje_alerta_costo ?? 15} onChange={e => setForm({ ...form, porcentaje_alerta_costo: +e.target.value })} /></Field>
          <Field label="Días para trasplante (default)" hint="Días por defecto para trasplante de semilleros"><input type="number" className={inputClass} value={form.dias_trasplante_default ?? 35} onChange={e => setForm({ ...form, dias_trasplante_default: +e.target.value })} /></Field>
          <Field label="Latitud" hint="Coordenada de la finca para el módulo de clima"><input type="number" step="0.0001" className={inputClass} value={form.latitud ?? 18.4861} onChange={e => setForm({ ...form, latitud: +e.target.value })} /></Field>
          <Field label="Longitud" hint="Coordenada de la finca para el módulo de clima"><input type="number" step="0.0001" className={inputClass} value={form.longitud ?? -69.9312} onChange={e => setForm({ ...form, longitud: +e.target.value })} /></Field>
        </div>

        <div className="flex items-center gap-3 mt-6">
          <Button onClick={save} disabled={crud.saving}><Save size={18} /> Guardar configuración</Button>
          {saved && <span className="flex items-center gap-1.5 text-brand-600 font-semibold text-sm animate-fade-in"><CheckCircle2 size={18} /> Guardado</span>}
        </div>
      </Card>

      <Card className="p-6">
        <h3 className="font-bold text-slate-800 mb-4">Centro de Rentabilidad — Resumen</h3>
        <p className="text-sm text-slate-500 mb-4">El sistema calcula automáticamente los siguientes indicadores en todas las pantallas:</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-sm">
          {['Rentabilidad por lote', 'Rentabilidad por fila', 'Rentabilidad por planta', 'Rentabilidad por cultivo', 'Rentabilidad por cliente', 'Rentabilidad por mercado', 'Punto de equilibrio', 'Flujo de caja proyectado', 'ROI', 'Margen bruto', 'Margen neto', 'Costo por libra/planta/lote/tarea/fila'].map(item => (
            <div key={item} className="p-2.5 rounded-xl bg-slate-50 text-slate-700 text-xs font-medium">{item}</div>
          ))}
        </div>
      </Card>

      <Card className="p-6">
        <h3 className="font-bold text-slate-800 mb-2">Arquitectura del Sistema</h3>
        <div className="space-y-2 text-sm text-slate-600">
          <p>• Base de datos normalizada con 22 tablas relacionadas</p>
          <p>• Frontend separado del backend (Supabase)</p>
          <p>• Lógica de negocio en módulos independientes</p>
          <p>• Componentes reutilizables</p>
          <p>• Actualización en tiempo real</p>
          <p>• Diseño preparado para multi-finca y multi-usuario futuro</p>
        </div>
      </Card>
    </div>
  );
}
