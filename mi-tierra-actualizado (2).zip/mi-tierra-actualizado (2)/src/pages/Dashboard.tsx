import { useEffect, useState } from 'react';
import {
  Wallet, Sprout, Factory, Target, AlertCircle,
  Droplets, FlaskConical,
} from 'lucide-react';
import { useData } from '../lib/DataContext';
import { calcDashboard, calcSemaforoFinanciero, calcAgenda } from '../lib/calculations';
import { obtenerInfoFaseLunar } from '../lib/lunar';
import { generarAlertas } from '../lib/alerts';
import { fmtMoney, fmtNum, fmtPct } from '../lib/format';
import { KpiCard, Semaforo, Card, EmptyState } from '../components/ui';
import type { PageKey } from '../components/Layout';

const SEMAFORO_BG: Record<string, string> = {
  verde: 'bg-brand-50 border-brand-200',
  amarillo: 'bg-amber-50 border-amber-200',
  rojo: 'bg-red-50 border-red-200',
};

const WEATHER_ICONS: Record<number, string> = {
  0: '☀️', 1: '🌤️', 2: '⛅', 3: '☁️', 45: '🌫️', 48: '🌫️',
  51: '🌦️', 53: '🌦️', 55: '🌧️', 61: '🌧️', 63: '🌧️', 65: '🌧️',
  71: '🌨️', 73: '🌨️', 75: '❄️', 77: '❄️',
  80: '🌧️', 81: '🌧️', 82: '⛈️', 95: '⛈️', 96: '⛈️', 99: '⛈️',
};

interface ClimaResumen {
  temperatura: number;
  descripcion: string;
  codigo: number;
}

export function DashboardPage({ onNavigate }: { onNavigate: (k: PageKey) => void }) {
  const data = useData();
  const config = data.config;
  const lat = config?.latitud || 18.4861;
  const lon = config?.longitud || -69.9312;

  const [clima, setClima] = useState<ClimaResumen | null>(null);

  useEffect(() => {
    if (!config) return;
    let cancelled = false;
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
    fetch(`${supabaseUrl}/functions/v1/clima?lat=${lat}&lon=${lon}`, {
      headers: { Authorization: `Bearer ${supabaseKey}` },
    })
      .then(res => res.json())
      .then(json => {
        if (!cancelled && json?.current) {
          setClima({
            temperatura: json.current.temperatura,
            descripcion: json.current.descripcion,
            codigo: json.current.codigo,
          });
        }
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, [config, lat, lon]);

  if (!config) return null;
  const moneda = config.moneda;

  const alertas = generarAlertas({
    parcelas: data.parcelas, cosechas: data.cosechas, gastos: data.gastos,
    inventario: data.inventario, ventas: data.ventas, prestamos: data.prestamos,
    semilleros: data.semilleros, plagas: data.plagas, riego: data.riego,
    metas: data.metas, trasplantes: data.trasplantes, trabajadores: data.trabajadores,
    config,
  });

  const kpis = calcDashboard(
    data.ventas, data.gastos, data.cosechas, data.inventario, data.clientes,
    data.prestamos, config, data.parcelas, data.filas, data.viajes,
    data.vehiculos, data.mercados, data.trabajadores, alertas.length,
  );
  const semFin = calcSemaforoFinanciero(kpis, config);
  const agenda = calcAgenda(data.riego, data.fertilizacion, data.semilleros, data.metas);
  const luna = obtenerInfoFaseLunar(new Date());

  return (
    <div className="space-y-6">
      {/* Cómo va tu finca: semáforo financiero */}
      <div className={`rounded-2xl p-5 border ${SEMAFORO_BG[semFin.estado]}`}>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Cómo va tu finca</p>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-2xl font-bold text-slate-900">{semFin.etiqueta}</span>
              <Semaforo estado={semFin.estado} label={`Margen ${fmtPct(semFin.margen_real)}`} />
            </div>
          </div>
          <div className="flex gap-6">
            <div>
              <p className="text-xs text-slate-400 font-semibold">GANANCIA</p>
              <p className={`text-lg font-bold ${kpis.ganancia >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtMoney(kpis.ganancia, moneda)}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 font-semibold">CAJA</p>
              <p className="text-lg font-bold text-slate-800">{fmtMoney(kpis.caja, moneda)}</p>
            </div>
          </div>
        </div>
      </div>

      {/* KPIs esenciales */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard icon={<Wallet size={18} />} label="Gastos del mes" value={fmtMoney(kpis.gastos_total, moneda)} color="amber" small />
        <KpiCard icon={<Sprout size={18} />} label="Producción esperada" value={fmtNum(kpis.produccion_estimada)} unit="lbs" color="slate" small />
        <KpiCard icon={<Factory size={18} />} label="Producción real" value={fmtNum(kpis.produccion_real)} unit="lbs" color="blue" small />
        <KpiCard icon={<Target size={18} />} label="Cumplimiento de metas" value={fmtPct(kpis.cumplimiento_pct)} color={kpis.cumplimiento_pct >= 95 ? 'green' : kpis.cumplimiento_pct >= 80 ? 'amber' : 'red'} small />
      </div>

      {/* Agenda + Alertas + Clima/Luna */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card title="Agenda de hoy">
          <div className="p-5">
            {agenda.length === 0 ? (
              <EmptyState message="No hay tareas pendientes para hoy." />
            ) : (
              <div className="space-y-3">
                {agenda.slice(0, 5).map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <span className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 flex-shrink-0">
                      {item.tipo === 'riego' ? <Droplets size={16} /> : item.tipo === 'fertilizacion' ? <FlaskConical size={16} /> : item.tipo === 'semillero' ? <Sprout size={16} /> : <Target size={16} />}
                    </span>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-700 truncate">{item.titulo}</p>
                      <p className="text-xs text-slate-400 truncate">{item.detalle}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Card>

        <Card title="Alertas" action={alertas.length > 0 ? <span className="text-xs text-slate-400">{alertas.length} total</span> : undefined}>
          <div className="p-5">
            {alertas.length === 0 ? (
              <EmptyState message="Sin alertas. Todo bajo control." />
            ) : (
              <div className="space-y-3">
                {alertas.slice(0, 5).map(a => (
                  <div key={a.id} className="flex items-start gap-3">
                    <span className={`w-2 h-2 mt-1.5 rounded-full flex-shrink-0 ${a.severidad === 'critical' ? 'bg-red-500' : a.severidad === 'warning' ? 'bg-amber-500' : 'bg-slate-400'}`} />
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-700 truncate">{a.titulo}</p>
                      <p className="text-xs text-slate-400 truncate">{a.mensaje}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Card>

        <Card title="Clima y luna" action={<button onClick={() => onNavigate('clima')} className="text-xs text-brand-600 hover:underline">Ver más →</button>}>
          <div className="p-5 space-y-4">
            <div className="flex items-center gap-3">
              <span className="text-2xl leading-none flex-shrink-0">{clima ? WEATHER_ICONS[clima.codigo] || '🌤️' : '⏳'}</span>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-slate-700 truncate">
                  {clima ? `${fmtNum(clima.temperatura)}°C` : 'Cargando clima...'}
                </p>
                {clima && <p className="text-xs text-slate-400 truncate">{clima.descripcion}</p>}
              </div>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-2xl leading-none flex-shrink-0">{luna.icono}</span>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-slate-700 capitalize truncate">{luna.fase}</p>
                <p className="text-xs text-slate-400">{luna.recomendacion}</p>
                {luna.actividades_recomendadas.length > 0 && (
                  <p className="text-xs text-brand-700 mt-1 truncate">Ideal para: {luna.actividades_recomendadas.slice(0, 2).join(', ')}</p>
                )}
              </div>
            </div>
          </div>
        </Card>
      </div>

      {alertas.length === 0 && agenda.length === 0 && (
        <Card>
          <div className="p-5">
            <EmptyState icon={<AlertCircle size={28} />} title="Todo tranquilo por hoy" message="No hay tareas pendientes ni alertas activas." />
          </div>
        </Card>
      )}
    </div>
  );
}
