import { useData } from '../lib/DataContext';
import { calcProduccion, parcelaProduccionEsperada, parcelaProduccionReal, parcelaTotalPlantas, calcCostosParcela } from '../lib/calculations';
import { fmtMoney, fmtNum, fmtPct } from '../lib/format';
import { Card, Table, Th, Td, PageHeader, EmptyState, Semaforo, StatBar } from '../components/ui';
import { Wheat, Sprout, TrendingUp } from 'lucide-react';

export function ProduccionPage() {
  const { parcelas, filas, cosechas, gastos, cultivos, config } = useData();
  const moneda = config?.moneda || 'RD$';

  if (parcelas.length === 0) {
    return <div><PageHeader title="Producción" subtitle="Rendimiento por planta, fila, parcela y cultivo" /><EmptyState icon={<Wheat size={32} />} title="Sin datos" message="Registra parcelas y cosechas para ver el análisis de producción." /></div>;
  }

  const totalEsperada = parcelas.reduce((s, p) => s + parcelaProduccionEsperada(p, filas), 0);
  const totalReal = parcelas.reduce((s, p) => s + parcelaProduccionReal(p, cosechas), 0);
  const totalPlantas = parcelas.reduce((s, p) => s + parcelaTotalPlantas(p, filas), 0);
  const produccionGlobal = calcProduccion(totalEsperada, totalReal, parcelas[0]?.precio_esperado_libra || 0);

  return (
    <div className="space-y-6">
      <PageHeader title="Producción" subtitle="Rendimiento por planta, fila, parcela y cultivo" />

      {/* Resumen global */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-5">
          <div className="flex items-center gap-3"><Sprout className="text-brand-600" size={24} /><div><p className="text-xs text-slate-400">Producción total</p><p className="text-2xl font-bold text-slate-900">{fmtNum(totalReal)} lb</p></div></div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-3"><Wheat className="text-amber-600" size={24} /><div><p className="text-xs text-slate-400">Esperada total</p><p className="text-2xl font-bold text-slate-900">{fmtNum(totalEsperada)} lb</p></div></div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-3"><TrendingUp className="text-blue-600" size={24} /><div><p className="text-xs text-slate-400">Cumplimiento</p><p className="text-2xl font-bold text-slate-900">{fmtPct(produccionGlobal.cumplimiento, 0)}</p></div></div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-3"><Sprout className="text-brand-600" size={24} /><div><p className="text-xs text-slate-400">Total plantas</p><p className="text-2xl font-bold text-slate-900">{fmtNum(totalPlantas, 0)}</p></div></div>
        </Card>
      </div>

      {/* Producción por parcela */}
      <Card title="Producción por Parcela" className="p-0">
        <Table>
          <thead><tr>
            <Th>Parcela</Th><Th>Cultivo</Th><Th className="text-right">Plantas</Th>
            <Th className="text-right">Esperada</Th><Th className="text-right">Real</Th>
            <Th>Cumplimiento</Th><Th>Semáforo</Th>
          </tr></thead>
          <tbody>
            {parcelas.map(p => {
              const esperada = parcelaProduccionEsperada(p, filas);
              const real = parcelaProduccionReal(p, cosechas);
              const precio = p.precio_esperado_libra || p.cultivos?.costo_esperado_por_libra || 0;
              const prod = calcProduccion(esperada, real, precio);
              const plantas = parcelaTotalPlantas(p, filas);
              return (
                <tr key={p.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                  <Td className="font-medium">{p.nombre}</Td>
                  <Td>{p.cultivos?.nombre || '—'}</Td>
                  <Td className="text-right tabular-nums">{fmtNum(plantas, 0)}</Td>
                  <Td className="text-right tabular-nums">{fmtNum(esperada)}</Td>
                  <Td className="text-right tabular-nums font-semibold">{fmtNum(real)}</Td>
                  <Td><div className="w-32"><StatBar value={real} max={esperada} color={prod.semaforo === 'rojo' ? 'red' : prod.semaforo === 'azul' ? 'blue' : prod.semaforo === 'verde' ? 'brand' : 'amber'} /></div></Td>
                  <Td><Semaforo estado={prod.semaforo} label={fmtPct(prod.cumplimiento, 0)} size="sm" /></Td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      </Card>

      {/* Rendimiento por planta y costo */}
      <Card title="Rendimiento por Planta y Costos" className="p-0">
        <Table>
          <thead><tr>
            <Th>Parcela</Th><Th className="text-right">Prod./planta</Th>
            <Th className="text-right">Costo/planta</Th><Th className="text-right">Costo/libra</Th>
            <Th className="text-right">Costo/fila</Th><Th className="text-right">Costo total</Th>
          </tr></thead>
          <tbody>
            {parcelas.map(p => {
              const costos = calcCostosParcela(p, gastos, filas, cosechas);
              const plantas = parcelaTotalPlantas(p, filas);
              const real = parcelaProduccionReal(p, cosechas);
              return (
                <tr key={p.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                  <Td className="font-medium">{p.nombre}</Td>
                  <Td className="text-right tabular-nums">{plantas > 0 ? fmtNum(real / plantas) + ' lb' : '—'}</Td>
                  <Td className="text-right tabular-nums">{fmtMoney(costos.costo_por_planta, moneda)}</Td>
                  <Td className="text-right tabular-nums">{fmtMoney(costos.costo_por_libra, moneda)}</Td>
                  <Td className="text-right tabular-nums">{fmtMoney(costos.costo_por_fila, moneda)}</Td>
                  <Td className="text-right tabular-nums font-bold">{fmtMoney(costos.costo_total, moneda)}</Td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      </Card>

      {/* Rendimiento por cultivo */}
      <Card title="Rendimiento por Cultivo" className="p-0">
        <Table>
          <thead><tr>
            <Th>Cultivo</Th><Th className="text-right">Parcelas</Th>
            <Th className="text-right">Producción</Th><Th className="text-right">Plantas</Th>
            <Th className="text-right">Prod./planta</Th>
          </tr></thead>
          <tbody>
            {cultivos.map(c => {
              const pcs = parcelas.filter(p => p.cultivo_id === c.id);
              const real = pcs.reduce((s, p) => s + parcelaProduccionReal(p, cosechas), 0);
              const plantas = pcs.reduce((s, p) => s + parcelaTotalPlantas(p, filas), 0);
              return (
                <tr key={c.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                  <Td className="font-medium">{c.nombre}</Td>
                  <Td className="text-right tabular-nums">{pcs.length}</Td>
                  <Td className="text-right tabular-nums font-semibold">{fmtNum(real)} lb</Td>
                  <Td className="text-right tabular-nums">{fmtNum(plantas, 0)}</Td>
                  <Td className="text-right tabular-nums">{plantas > 0 ? fmtNum(real / plantas) + ' lb' : '—'}</Td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      </Card>
    </div>
  );
}
