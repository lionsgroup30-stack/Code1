import { useState } from 'react';
import { Plus, Pencil, Trash2, MapPin, Truck, Trophy, Store } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtMoney, fmtNum } from '../lib/format';
import { compararMercados } from '../lib/calculations';
import { Button, Modal, Field, inputClass, Table, Th, Td, PageHeader, EmptyState, Card, Badge, KpiCard } from '../components/ui';
import type { Mercado } from '../lib/types';

const empty = (): Partial<Mercado> => ({
  nombre: '', ubicacion: '', costo_transporte: 0, precio_referencia_libra: 0,
});

export function MercadosPage() {
  const { mercados, gastos, cosechas, config } = useData();
  const crud = useCrud<Mercado>('mercados');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Mercado | null>(null);
  const [form, setForm] = useState<Partial<Mercado>>(empty());
  const moneda = config?.moneda || 'RD$';

  const openNew = () => { setEditing(null); setForm(empty()); setModal(true); };
  const openEdit = (m: Mercado) => { setEditing(m); setForm(m); setModal(true); };
  const save = async () => {
    const payload = { ...form, ubicacion: form.ubicacion || null };
    if (editing) await crud.update(editing.id, payload);
    else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => { if (confirm('¿Eliminar mercado?')) await crud.remove(id); };

  // Average costo_por_libra from gastos as the base cost
  const totalLibras = cosechas.reduce((s, c) => s + c.cantidad_libras, 0);
  const totalGastos = gastos.reduce((s, g) => s + g.monto, 0);
  const costoBaseLibra = totalLibras > 0 ? totalGastos / totalLibras : 0;

  const comparacion = compararMercados(mercados, costoBaseLibra);
  const mejor = comparacion.find(c => c.es_mejor);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Mercados"
        subtitle="Puntos de venta y análisis de rentabilidad por mercado"
        action={<Button onClick={openNew}><Plus size={18} /> Nuevo Mercado</Button>}
      />

      {/* Resumen */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <KpiCard label="Mercados registrados" value={fmtNum(mercados.length, 0)} icon={<Store size={20} />} accent="blue" />
        <KpiCard label="Costo base por libra" value={fmtMoney(costoBaseLibra, moneda)} icon={<Truck size={20} />} accent="amber" subtitle="Promedio de gastos" />
        {mejor ? (
          <KpiCard label="Mejor mercado" value={mejor.nombre} icon={<Trophy size={20} />} accent="green" subtitle={`Rentabilidad: ${fmtMoney(mejor.rentabilidad_libra, moneda)}/lb`} />
        ) : (
          <KpiCard label="Mejor mercado" value="—" icon={<Trophy size={20} />} accent="default" subtitle="Sin datos" />
        )}
      </div>

      {/* Tabla de mercados */}
      {mercados.length === 0 ? (
        <EmptyState icon={<Store size={32} />} title="Sin mercados registrados" message="Registra tus mercados para comparar rentabilidad y decidir dónde vender." action={<Button onClick={openNew}><Plus size={18} /> Registrar primer mercado</Button>} />
      ) : (
        <Card className="p-0">
          <Table>
            <thead><tr>
              <Th>Nombre</Th><Th>Ubicación</Th>
              <Th className="text-right">Costo transporte</Th>
              <Th className="text-right">Precio ref./lb</Th><Th></Th>
            </tr></thead>
            <tbody>
              {mercados.map(m => (
                <tr key={m.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                  <Td className="font-medium">{m.nombre}</Td>
                  <Td className="text-slate-600">{m.ubicacion ? <span className="flex items-center gap-1"><MapPin size={12} /> {m.ubicacion}</span> : '—'}</Td>
                  <Td className="text-right tabular-nums">{fmtMoney(m.costo_transporte, moneda)}</Td>
                  <Td className="text-right tabular-nums font-semibold">{fmtMoney(m.precio_referencia_libra, moneda)}</Td>
                  <Td>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" onClick={() => openEdit(m)}><Pencil size={14} /></Button>
                      <Button variant="ghost" size="sm" onClick={() => del(m.id)} className="text-red-600"><Trash2 size={14} /></Button>
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      )}

      {/* Comparación de mercados */}
      {comparacion.length > 0 && (
        <Card title="Comparación de Rentabilidad por Mercado" className="p-0">
          <div className="p-5">
            <p className="text-xs text-slate-500 mb-4">
              Precio neto = precio/lb − costo transporte · Rentabilidad/lb = precio neto − costo base ({fmtMoney(costoBaseLibra, moneda)}/lb)
            </p>
            <Table>
              <thead><tr>
                <Th>Mercado</Th><Th className="text-right">Precio/lb</Th>
                <Th className="text-right">Transporte</Th><Th className="text-right">Precio neto</Th>
                <Th className="text-right">Rentabilidad/lb</Th><Th></Th>
              </tr></thead>
              <tbody>
                {comparacion.map(c => (
                  <tr key={c.id} className={`border-t border-slate-50 ${c.es_mejor ? 'bg-brand-50/50' : 'hover:bg-slate-50/50'}`}>
                    <Td className="font-medium">
                      <span className="flex items-center gap-2">
                        {c.nombre}
                        {c.es_mejor && <Badge color="green">Mejor</Badge>}
                      </span>
                    </Td>
                    <Td className="text-right tabular-nums">{fmtMoney(c.precio_libra, moneda)}</Td>
                    <Td className="text-right tabular-nums text-red-600">{fmtMoney(c.costo_transporte, moneda)}</Td>
                    <Td className="text-right tabular-nums font-semibold">{fmtMoney(c.precio_neto, moneda)}</Td>
                    <Td className="text-right tabular-nums font-bold">
                      <span className={c.rentabilidad_libra >= 0 ? 'text-brand-600' : 'text-red-600'}>
                        {fmtMoney(c.rentabilidad_libra, moneda)}
                      </span>
                    </Td>
                    <Td>{c.es_mejor && <Trophy className="text-amber-500" size={18} />}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </Card>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Mercado' : 'Nuevo Mercado'}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2"><Field label="Nombre" required><input className={inputClass} value={form.nombre || ''} onChange={e => setForm({ ...form, nombre: e.target.value })} /></Field></div>
          <div className="sm:col-span-2"><Field label="Ubicación"><input className={inputClass} value={form.ubicacion || ''} onChange={e => setForm({ ...form, ubicacion: e.target.value })} /></Field></div>
          <Field label="Costo de transporte" hint="Costo por viaje o por libra"><input type="number" step="0.01" className={inputClass} value={form.costo_transporte ?? 0} onChange={e => setForm({ ...form, costo_transporte: +e.target.value })} /></Field>
          <Field label="Precio de referencia por libra"><input type="number" step="0.01" className={inputClass} value={form.precio_referencia_libra ?? 0} onChange={e => setForm({ ...form, precio_referencia_libra: +e.target.value })} /></Field>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}
