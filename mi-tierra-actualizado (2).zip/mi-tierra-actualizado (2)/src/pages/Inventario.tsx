import { useState } from 'react';
import { Plus, Pencil, Trash2, Package, AlertTriangle, DollarSign, Boxes } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtMoney, fmtNum } from '../lib/format';
import { Button, Modal, Field, inputClass, PageHeader, EmptyState, Card, Badge, KpiCard } from '../components/ui';
import type { InventarioItem } from '../lib/types';

const empty = (): Partial<InventarioItem> => ({
  nombre: '', categoria: 'Otros', unidad: 'unidad', stock_actual: 0, stock_minimo: 0, costo_unitario: 0,
});

const CATEGORIAS = ['Semillas', 'Fertilizantes', 'Fungicidas', 'Insecticidas', 'Herbicidas', 'Herramientas', 'Combustible', 'Sacos', 'Mallas', 'Equipos', 'Otros'];

const catColor = (c: string): 'green' | 'amber' | 'blue' | 'red' | 'earth' | 'slate' => {
  switch (c) {
    case 'Semillas': return 'green';
    case 'Fertilizantes': return 'blue';
    case 'Fungicidas':
    case 'Insecticidas':
    case 'Herbicidas': return 'amber';
    case 'Herramientas':
    case 'Equipos': return 'earth';
    case 'Combustible': return 'red';
    default: return 'slate';
  }
};

export function InventarioPage() {
  const { inventario, config } = useData();
  const crud = useCrud<InventarioItem>('inventario');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<InventarioItem | null>(null);
  const [form, setForm] = useState<Partial<InventarioItem>>(empty());

  const moneda = config?.moneda || 'RD$';

  const openNew = () => { setEditing(null); setForm(empty()); setModal(true); };
  const openEdit = (i: InventarioItem) => { setEditing(i); setForm(i); setModal(true); };
  const save = async () => {
    if (editing) await crud.update(editing.id, form); else await crud.insert(form);
    setModal(false);
  };
  const del = async (id: string) => { if (confirm('¿Eliminar item de inventario?')) await crud.remove(id); };

  const totalItems = inventario.length;
  const valorTotal = inventario.reduce((s, i) => s + (i.stock_actual ?? 0) * (i.costo_unitario ?? 0), 0);
  const bajoMinimo = inventario.filter(i => (i.stock_actual ?? 0) <= (i.stock_minimo ?? 0)).length;

  return (
    <div>
      <PageHeader title="Inventario" subtitle="Control de existencias y valor de inventario" action={<Button onClick={openNew}><Plus size={18} /> Nuevo Item</Button>} />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <KpiCard label="Total items" value={`${totalItems}`} icon={<Boxes size={20} />} accent="blue" />
        <KpiCard label="Valor inventario" value={fmtMoney(valorTotal, moneda)} icon={<DollarSign size={20} />} accent="green" />
        <KpiCard label="Bajo mínimo" value={`${bajoMinimo}`} icon={<AlertTriangle size={20} />} accent={bajoMinimo > 0 ? 'red' : 'default'} subtitle={bajoMinimo > 0 ? 'Requiere reposición' : 'Todo en orden'} />
      </div>

      {inventario.length === 0 ? (
        <EmptyState icon={<Package size={32} />} title="Sin items en inventario" message="Registra tus insumos, herramientas y materiales." action={<Button onClick={openNew}><Plus size={18} /> Crear item</Button>} />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {inventario.map(i => {
            const valor = (i.stock_actual ?? 0) * (i.costo_unitario ?? 0);
            const bajo = (i.stock_actual ?? 0) <= (i.stock_minimo ?? 0);
            return (
              <Card key={i.id} className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <Package className="text-brand-600 shrink-0" size={20} />
                      <h3 className="font-bold text-slate-800 truncate">{i.nombre}</h3>
                    </div>
                    <div className="mt-1.5"><Badge color={catColor(i.categoria)}>{i.categoria}</Badge></div>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button variant="ghost" size="sm" onClick={() => openEdit(i)}><Pencil size={14} /></Button>
                    <Button variant="ghost" size="sm" onClick={() => del(i.id)} className="text-red-600"><Trash2 size={14} /></Button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className={`p-3 rounded-xl ${bajo ? 'bg-red-50 ring-1 ring-red-200' : 'bg-slate-50'}`}>
                    <p className="text-xs text-slate-400 font-medium flex items-center gap-1">
                      {bajo && <AlertTriangle size={12} className="text-red-500" />} Stock actual
                    </p>
                    <p className={`text-lg font-bold tabular-nums ${bajo ? 'text-red-700' : 'text-slate-800'}`}>{fmtNum(i.stock_actual, 0)} {i.unidad}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50">
                    <p className="text-xs text-slate-400 font-medium">Stock mínimo</p>
                    <p className="text-lg font-bold text-slate-700 tabular-nums">{fmtNum(i.stock_minimo, 0)} {i.unidad}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50">
                    <p className="text-xs text-slate-400 font-medium">Costo unitario</p>
                    <p className="text-sm font-bold text-slate-800">{fmtMoney(i.costo_unitario, moneda)}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-brand-50">
                    <p className="text-xs text-brand-500 font-medium">Valor total</p>
                    <p className="text-sm font-bold text-brand-800">{fmtMoney(valor, moneda)}</p>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Item' : 'Nuevo Item'}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Nombre" required><input className={inputClass} value={form.nombre || ''} onChange={e => setForm({ ...form, nombre: e.target.value })} /></Field>
          <Field label="Categoría">
            <select className={inputClass} value={form.categoria || 'Otros'} onChange={e => setForm({ ...form, categoria: e.target.value })}>
              {CATEGORIAS.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Unidad"><input className={inputClass} value={form.unidad || 'unidad'} onChange={e => setForm({ ...form, unidad: e.target.value })} /></Field>
          <Field label="Stock actual" required><input type="number" step="0.01" className={inputClass} value={form.stock_actual ?? 0} onChange={e => setForm({ ...form, stock_actual: +e.target.value })} /></Field>
          <Field label="Stock mínimo"><input type="number" step="0.01" className={inputClass} value={form.stock_minimo ?? 0} onChange={e => setForm({ ...form, stock_minimo: +e.target.value })} /></Field>
          <Field label="Costo unitario"><input type="number" step="0.01" className={inputClass} value={form.costo_unitario ?? 0} onChange={e => setForm({ ...form, costo_unitario: +e.target.value })} /></Field>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}
