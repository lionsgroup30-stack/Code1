import { useState } from 'react';
import { Plus, Pencil, Trash2, Droplets } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtNum, fmtDate, todayISO } from '../lib/format';
import { Button, Modal, Field, inputClass, Table, Th, Td, PageHeader, EmptyState, Card } from '../components/ui';
import type { Riego } from '../lib/types';

const empty = (parcelaId = ''): Partial<Riego> => ({
  parcela_id: parcelaId, fecha: todayISO(), hora: '', cantidad_litros: 0, duracion_min: 0, costo: 0, trabajador_id: '', fecha_proximo_riego: '', observaciones: '',
});

function startOfWeekISO(d = new Date()): string {
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  const ws = new Date(d);
  ws.setDate(diff);
  return ws.toISOString().split('T')[0];
}

export function RiegoPage() {
  const { riego, parcelas, trabajadores } = useData();
  const crud = useCrud<Riego>('riego');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Riego | null>(null);
  const [form, setForm] = useState<Partial<Riego>>(empty());

  const openNew = () => { setEditing(null); setForm(empty(parcelas[0]?.id || '')); setModal(true); };
  const openEdit = (r: Riego) => { setEditing(r); setForm(r); setModal(true); };
  const save = async () => {
    const payload = { ...form, parcela_id: form.parcela_id || null, trabajador_id: form.trabajador_id || null, fecha_proximo_riego: form.fecha_proximo_riego || null, hora: form.hora || null };
    if (editing) await crud.update(editing.id, payload); else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => { if (confirm('¿Eliminar registro de riego?')) await crud.remove(id); };

  const thisMonth = todayISO().slice(0, 7);
  const weekStart = startOfWeekISO();
  const litrosMes = riego.filter(r => (r.fecha || '').slice(0, 7) === thisMonth).reduce((s, r) => s + (r.cantidad_litros ?? 0), 0);
  const riegosSemana = riego.filter(r => (r.fecha || '') >= weekStart).length;

  return (
    <div>
      <PageHeader title="Riego" subtitle="Registro de riego por parcela" action={<Button onClick={openNew} disabled={parcelas.length === 0}><Plus size={18} /> Nuevo Riego</Button>} />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <Card className="p-5">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">Litros este mes</p>
          <p className="text-2xl font-bold text-slate-900 mt-1 tabular-nums">{fmtNum(litrosMes, 0)} L</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">Riegos esta semana</p>
          <p className="text-2xl font-bold text-slate-900 mt-1 tabular-nums">{riegosSemana}</p>
        </Card>
      </div>

      {riego.length === 0 ? (
        <EmptyState icon={<Droplets size={32} />} title="Sin registros de riego" message={parcelas.length === 0 ? 'Primero crea una parcela.' : 'Registra los riegos aplicados a cada parcela.'} action={parcelas.length > 0 ? <Button onClick={openNew}><Plus size={18} /> Registrar riego</Button> : undefined} />
      ) : (
        <Card className="p-0">
          <Table>
            <thead><tr>
              <Th>Fecha</Th><Th>Parcela</Th><Th>Responsable</Th><Th className="text-right">Litros</Th>
              <Th className="text-right">Duración (min)</Th><Th>Próximo</Th><Th></Th>
            </tr></thead>
            <tbody>
              {riego.map(r => (
                <tr key={r.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                  <Td>{fmtDate(r.fecha)}</Td>
                  <Td className="font-medium">{r.parcelas?.nombre || '—'}</Td>
                  <Td className="text-slate-500">{r.trabajadores?.nombre || '—'}</Td>
                  <Td className="text-right tabular-nums">{fmtNum(r.cantidad_litros, 0)}</Td>
                  <Td className="text-right tabular-nums">{fmtNum(r.duracion_min, 0)}</Td>
                  <Td className="text-slate-500">{r.fecha_proximo_riego ? fmtDate(r.fecha_proximo_riego) : '—'}</Td>
                  <Td>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" onClick={() => openEdit(r)}><Pencil size={14} /></Button>
                      <Button variant="ghost" size="sm" onClick={() => del(r.id)} className="text-red-600"><Trash2 size={14} /></Button>
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Riego' : 'Nuevo Riego'}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Parcela" required>
            <select className={inputClass} value={form.parcela_id || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value })}>
              {parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
            </select>
          </Field>
          <Field label="Fecha" required><input type="date" className={inputClass} value={form.fecha || ''} onChange={e => setForm({ ...form, fecha: e.target.value })} /></Field>
          <Field label="Cantidad (litros)" required><input type="number" step="0.01" className={inputClass} value={form.cantidad_litros ?? 0} onChange={e => setForm({ ...form, cantidad_litros: +e.target.value })} /></Field>
          <Field label="Duración (min)" required><input type="number" step="0.01" className={inputClass} value={form.duracion_min ?? 0} onChange={e => setForm({ ...form, duracion_min: +e.target.value })} /></Field>
          <Field label="Hora"><input type="time" className={inputClass} value={form.hora || ''} onChange={e => setForm({ ...form, hora: e.target.value })} /></Field>
          <Field label="Costo"><input type="number" step="0.01" className={inputClass} value={form.costo ?? 0} onChange={e => setForm({ ...form, costo: +e.target.value })} /></Field>
          <Field label="Responsable">
            <select className={inputClass} value={form.trabajador_id || ''} onChange={e => setForm({ ...form, trabajador_id: e.target.value })}>
              <option value="">— Ninguno —</option>
              {trabajadores.map(t => <option key={t.id} value={t.id}>{t.nombre}</option>)}
            </select>
          </Field>
          <Field label="Próximo riego"><input type="date" className={inputClass} value={form.fecha_proximo_riego || ''} onChange={e => setForm({ ...form, fecha_proximo_riego: e.target.value })} /></Field>
          <div className="sm:col-span-2"><Field label="Observaciones"><textarea className={inputClass} rows={2} value={form.observaciones || ''} onChange={e => setForm({ ...form, observaciones: e.target.value })} /></Field></div>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}
