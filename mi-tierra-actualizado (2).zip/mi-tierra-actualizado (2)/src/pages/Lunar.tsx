import { obtenerInfoFaseLunar, generarCalendarioLunar, type FaseLunar } from '../lib/lunar';
import { fmtDate } from '../lib/format';
import { Card, PageHeader } from '../components/ui';
import { Check, X } from 'lucide-react';

const FASE_COLORS: Record<string, string> = {
  'Luna Nueva': 'bg-slate-700',
  'Cuarto Creciente': 'bg-blue-600',
  'Luna Llena': 'bg-amber-500',
  'Cuarto Menguante': 'bg-indigo-600',
};

export function LunarPage() {
  const hoy = new Date();
  const faseHoy = obtenerInfoFaseLunar(hoy);
  const calendario = generarCalendarioLunar(30, hoy);
  const cambiosFase = calendario.filter((f, i) => i === 0 || f.fase !== calendario[i - 1].fase);

  return (
    <div className="space-y-6">
      <PageHeader title="Calendario Lunar" subtitle="Fases lunares y recomendaciones agrícolas (solo orientativo)" />

      {/* Fase actual */}
      <Card className="p-0 overflow-hidden">
        <div className={`${FASE_COLORS[faseHoy.fase]} p-8 text-white`}>
          <div className="flex items-center gap-6">
            <div className="text-6xl">{faseHoy.icono}</div>
            <div>
              <p className="text-sm opacity-80 uppercase tracking-wide">Fase actual · {fmtDate(hoy)}</p>
              <h2 className="text-3xl font-bold mt-1">{faseHoy.fase}</h2>
              <p className="text-sm opacity-90 mt-2">{faseHoy.recomendacion}</p>
            </div>
          </div>
        </div>
        <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase mb-2">Actividades recomendadas</p>
            <div className="space-y-1.5">
              {faseHoy.actividades_recomendadas.map(a => (
                <div key={a} className="flex items-center gap-2 text-sm text-brand-700"><Check size={16} />{a}</div>
              ))}
            </div>
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase mb-2">Evitar</p>
            <div className="space-y-1.5">
              {faseHoy.actividades_evitar.map(a => (
                <div key={a} className="flex items-center gap-2 text-sm text-red-600"><X size={16} />{a}</div>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {/* Calendario 30 días */}
      <Card title="Próximos 30 días" className="p-0">
        <div className="p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {cambiosFase.map((f, i) => <FaseCard key={i} fase={f} />)}
        </div>
      </Card>

      {/* Calendario diario */}
      <Card title="Calendario diario" className="p-0">
        <div className="p-5 overflow-x-auto">
          <div className="flex gap-2 min-w-max">
            {calendario.map((f, i) => (
              <div key={i} className={`flex flex-col items-center p-3 rounded-xl min-w-[80px] ${f.fase === faseHoy.fase && i === 0 ? 'bg-brand-50 ring-2 ring-brand-300' : 'bg-slate-50'}`}>
                <span className="text-2xl">{f.icono}</span>
                <span className="text-xs font-bold text-slate-700 mt-1">{f.fecha.getDate()}/{f.fecha.getMonth() + 1}</span>
                <span className="text-[10px] text-slate-400 text-center mt-0.5">{f.fase}</span>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}

function FaseCard({ fase }: { fase: FaseLunar }) {
  return (
    <div className={`rounded-xl ${FASE_COLORS[fase.fase]} p-4 text-white`}>
      <div className="flex items-center gap-3">
        <span className="text-3xl">{fase.icono}</span>
        <div>
          <p className="text-xs opacity-80">{fmtDate(fase.fecha)}</p>
          <p className="font-bold">{fase.fase}</p>
        </div>
      </div>
      <p className="text-xs opacity-90 mt-2">{fase.recomendacion}</p>
    </div>
  );
}
