import { useState } from 'react';
import {
  Plus, Pencil, Trash2, Target, Calendar, TrendingUp, CheckCircle, AlertCircle,
} from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { calcMeta } from '../lib/calculations';
import { fmtDate, fmtNum, fmtPct, todayISO, daysBetween } from '../lib/format';
import {
  Button, Modal, Field, inputClass, PageHeader, EmptyState, Badge, KpiCard, StatBar, Semaforo,
} from '../components/ui';
import type { Meta } from '../lib/types';

const TIPOS = ['produccion', 'ventas', 'costos', 'area', 'otro'] as const;
const ESTADOS = ['activa', 'completada', 'cancelada'] as const;

const tipoLabel: Record<string, string> = {
  produccion: 'Producción',
  ventas: 'Ventas',
  costos: 'Costos',
  area: 'Área',
  otro: 'Otro',
};

const tipoBadge: Record<string, 'green' | 'blue' | 'red' | 'amber' | 'slate'> = {
  produccion: 'green',
  ventas: 'blue',
  costos: 'red',
  area: 'amber',
  otro: 'slate',
};

const estadoLabel: Record<string, string> = {
  activa: 'Activa',
  completada: 'Completada',
  cancelada: 'Cancelada',
};

// Mapeo del estado calculado al semáforo de UI
const calcToSemaforo: Record<string, 'verde' | 'amarillo' | 'rojo' | 'azul'> = {
  completada: 'verde',
  al_dia: 'verde',
  en_camino: 'amarillo',
  atrasada: 'rojo',
  vencida: 'rojo',
};

const calcEstadoLabel: Record<string, string> = {
  completada: 'Completada',
  al_dia: 'Al día',
  en_camino: 'En camino',
  atrasada: 'Atrasada',
  vencida: 'Vencida',
};

const empty = (): Partial<Meta> => ({
  titulo: '',
  descripcion: '',
  tipo: 'produccion',
  valor_objetivo: 0,
  valor_actual: 0,
  unidad: 'lb',
  fecha_limite: '',
  estado: 'activa',
});

export function MetasPage() {
  const { metas } = useData();
  const crud = useCrud<Meta>('metas');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Meta | null>(null);
  const [form, setForm] = useState<Partial<Meta>>(empty());

  // ---- KPIs ----
  const total = metas.length;
  const completadas = metas.filter(m => {
    if (m.estado === 'completada') return true;
    const c = calcMeta(m);
    return c.estado === 'completada';
  }).length;
  const activas = metas.filter(m => m.estado === 'activa' && calcMeta(m).estado !== 'completada').length;
  const atrasadasVencidas = metas.filter(m => {
    if (m.estado !== 'activa') return false;
    const c = calcMeta(m);
    return c.estado === 'atrasada' || c.estado === 'vencida';
  }).length;

  // ---- Handlers ----
  const openNew = () => { setEditing(null); setForm(empty()); setModal(true); };
  const openEdit = (m: Meta) => { setEditing(m); setForm(m); setModal(true); };

  const save = async () => {
    const payload = {
      ...form,
      valor_objetivo: Number(form.valor_objetivo) || 0,
      valor_actual: Number(form.valor_actual) || 0,
      descripcion: form.descripcion || null,
      fecha_limite: form.fecha_limite || null,
    };
    if (editing) await crud.update(editing.id, payload);
    else await crud.insert(payload);
    setModal(false);
  };

  const del = async (id: string) => {
    if (confirm('¿Eliminar esta meta?')) await crud.remove(id);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Planificador de Metas"
        subtitle="Establece y monitorea tus objetivos"
        action={<Button onClick={openNew}><Plus size={18} /> Nueva Meta</Button>}
      />

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          label="Total Metas"
          value={`${total}`}
          subtitle={`${activas} activas · ${completadas} completadas`}
          icon={<Target size={20} />}
          accent="brand"
        />
        <KpiCard
          label="Completadas"
          value={`${completadas}`}
          subtitle={total > 0 ? `${((completadas / total) * 100).toFixed(0)}% del total` : '—'}
          icon={<CheckCircle size={20} />}
          accent="green"
        />
        <KpiCard
          label="Metas Activas"
          value={`${activas}`}
          subtitle="En seguimiento"
          icon={<TrendingUp size={20} />}
          accent="blue"
        />
        <KpiCard
          label="Atrasadas / Vencidas"
          value={`${atrasadasVencidas}`}
          subtitle="Requieren atención"
          icon={<AlertCircle size={20} />}
          accent={atrasadasVencidas > 0 ? 'red' : 'default'}
        />
      </div>

      {/* Grid de tarjetas o estado vacío */}
      {metas.length === 0 ? (
        <EmptyState
          icon={<Target size={32} />}
          title="Sin metas registradas"
          message="Define tus objetivos de producción, ventas, costos o área y monitorea tu progreso automáticamente."
          action={<Button onClick={openNew}><Plus size={18} /> Crear primera meta</Button>}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {metas.map(m => {
            const calc = calcMeta(m);
            const semEstado = calcToSemaforo[calc.estado] ?? 'amarillo';
            const barraColor =
              calc.estado === 'completada' ? 'brand' :
              calc.estado === 'al_dia' ? 'brand' :
              calc.estado === 'en_camino' ? 'amber' :
              'red';
            return (
              <div
                key={m.id}
                className="bg-white rounded-2xl border border-slate-200/70 shadow-sm p-5 hover:shadow-md transition-all duration-200 flex flex-col"
              >
                {/* Encabezado */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <Target className="text-brand-600 shrink-0" size={20} />
                      <h3 className="font-bold text-slate-800 truncate">{m.titulo}</h3>
                    </div>
                    {m.descripcion && (
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2">{m.descripcion}</p>
                    )}
                    <p className="text-[11px] text-slate-300 mt-0.5">
                      Creada hace {daysBetween(m.created_at)} días
                    </p>
                  </div>
                  <Badge color={tipoBadge[m.tipo] ?? 'slate'}>{tipoLabel[m.tipo] ?? m.tipo}</Badge>
                </div>

                {/* Barra de progreso */}
                <div className="mt-1">
                  <StatBar
                    value={calc.porcentaje_cumplimiento}
                    max={100}
                    color={barraColor}
                    label="Cumplimiento"
                  />
                </div>

                {/* Valores actual / objetivo */}
                <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-xs text-slate-400">Actual</p>
                    <p className="font-semibold tabular-nums text-slate-800">
                      {fmtNum(m.valor_actual, 0)} <span className="text-xs font-normal text-slate-400">{m.unidad}</span>
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Objetivo</p>
                    <p className="font-semibold tabular-nums text-slate-800">
                      {fmtNum(m.valor_objetivo, 0)} <span className="text-xs font-normal text-slate-400">{m.unidad}</span>
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Cumplimiento</p>
                    <p className="font-semibold tabular-nums text-slate-800">{fmtPct(calc.porcentaje_cumplimiento, 0)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Restante</p>
                    <p className="font-semibold tabular-nums text-slate-800">
                      {fmtNum(Math.max(0, calc.restante), 0)} <span className="text-xs font-normal text-slate-400">{m.unidad}</span>
                    </p>
                  </div>
                </div>

                {/* Fecha límite / días restantes */}
                <div className="mt-4 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 text-sm text-slate-600">
                    <Calendar size={14} className="text-slate-400" />
                    {m.fecha_limite ? fmtDate(m.fecha_limite) : 'Sin fecha'}
                  </div>
                  {calc.estado === 'completada' ? (
                    <Badge color="green"><CheckCircle size={12} /> Completada</Badge>
                  ) : calc.dias_restantes === null ? (
                    <span className="text-xs text-slate-400">Sin plazo</span>
                  ) : calc.dias_restantes < 0 ? (
                    <Badge color="red">Vencida</Badge>
                  ) : (
                    <span className={`text-xs font-semibold ${calc.dias_restantes <= 7 ? 'text-red-600' : 'text-slate-500'}`}>
                      {calc.dias_restantes} días restantes
                    </span>
                  )}
                </div>

                {/* Estado semáforo */}
                <div className="mt-4 flex items-center justify-between">
                  <Semaforo estado={semEstado} label={calcEstadoLabel[calc.estado] ?? calc.estado} size="sm" />
                  {m.estado === 'cancelada' && <Badge color="slate">Cancelada</Badge>}
                </div>

                {/* Acciones */}
                <div className="flex gap-2 mt-4 pt-3 border-t border-slate-100">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(m)}>
                    <Pencil size={14} /> Editar
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => del(m.id)} className="text-red-600">
                    <Trash2 size={14} />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal formulario */}
      <Modal
        open={modal}
        onClose={() => setModal(false)}
        title={editing ? 'Editar Meta' : 'Nueva Meta'}
        size="lg"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <Field label="Título" required>
              <input
                className={inputClass}
                value={form.titulo || ''}
                onChange={e => setForm({ ...form, titulo: e.target.value })}
                placeholder="Ej. Producción de cacao Q3"
              />
            </Field>
          </div>
          <div className="sm:col-span-2">
            <Field label="Descripción">
              <textarea
                className={inputClass}
                rows={2}
                value={form.descripcion || ''}
                onChange={e => setForm({ ...form, descripcion: e.target.value })}
                placeholder="Describe el objetivo de la meta…"
              />
            </Field>
          </div>
          <Field label="Tipo" required>
            <select
              className={inputClass}
              value={form.tipo || 'produccion'}
              onChange={e => setForm({ ...form, tipo: e.target.value })}
            >
              {TIPOS.map(t => <option key={t} value={t}>{tipoLabel[t]}</option>)}
            </select>
          </Field>
          <Field label="Unidad">
            <input
              className={inputClass}
              value={form.unidad || ''}
              onChange={e => setForm({ ...form, unidad: e.target.value })}
              placeholder="lb, kg, $, tareas…"
            />
          </Field>
          <Field label="Valor objetivo" required>
            <input
              type="number"
              step="0.01"
              min="0"
              className={inputClass}
              value={form.valor_objetivo ?? 0}
              onChange={e => setForm({ ...form, valor_objetivo: +e.target.value })}
            />
          </Field>
          <Field label="Valor actual">
            <input
              type="number"
              step="0.01"
              min="0"
              className={inputClass}
              value={form.valor_actual ?? 0}
              onChange={e => setForm({ ...form, valor_actual: +e.target.value })}
            />
          </Field>
          <Field label="Fecha límite" hint="Opcional">
            <input
              type="date"
              min={todayISO()}
              className={inputClass}
              value={form.fecha_limite || ''}
              onChange={e => setForm({ ...form, fecha_limite: e.target.value })}
            />
          </Field>
          <Field label="Estado">
            <select
              className={inputClass}
              value={form.estado || 'activa'}
              onChange={e => setForm({ ...form, estado: e.target.value })}
            >
              {ESTADOS.map(e => <option key={e} value={e}>{estadoLabel[e]}</option>)}
            </select>
          </Field>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving || !form.titulo}>
            {editing ? 'Guardar' : 'Crear'}
          </Button>
        </div>
      </Modal>
    </div>
  );
}
