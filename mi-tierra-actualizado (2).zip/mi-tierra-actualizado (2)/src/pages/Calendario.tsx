import { useData } from '../lib/DataContext';
import { generarCalendarioAgricola, type ActividadAgricola } from '../lib/lunar';
import { fmtDate } from '../lib/format';
import { Card, PageHeader, EmptyState, Badge } from '../components/ui';
import { CalendarDays, AlertCircle, Clock } from 'lucide-react';

export function CalendarioPage() {
  const { parcelas, cultivos } = useData();
  const actividades = generarCalendarioAgricola(parcelas, cultivos);
  const pendientes = actividades.filter(a => a.estado === 'pendiente' && a.dias_restantes >= 0 && a.dias_restantes <= 7);
  const vencidas = actividades.filter(a => a.dias_restantes < 0);
  const proximas = actividades.filter(a => a.dias_restantes > 7).slice(0, 10);

  return (
    <div className="space-y-6">
      <PageHeader title="Calendario Agrícola" subtitle="Actividades generadas automáticamente según la edad del cultivo" />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="p-5"><div className="flex items-center gap-3"><AlertCircle className="text-red-500" size={24} /><div><p className="text-xs text-slate-400">Vencidas</p><p className="text-2xl font-bold text-red-600">{vencidas.length}</p></div></div></Card>
        <Card className="p-5"><div className="flex items-center gap-3"><Clock className="text-amber-500" size={24} /><div><p className="text-xs text-slate-400">Próximas (7 días)</p><p className="text-2xl font-bold text-amber-600">{pendientes.length}</p></div></div></Card>
        <Card className="p-5"><div className="flex items-center gap-3"><CalendarDays className="text-brand-600" size={24} /><div><p className="text-xs text-slate-400">Total actividades</p><p className="text-2xl font-bold text-slate-800">{actividades.length}</p></div></div></Card>
      </div>

      {actividades.length === 0 ? (
        <EmptyState icon={<CalendarDays size={32} />} title="Sin actividades" message="Registra parcelas con fecha de siembra para generar el calendario automático." />
      ) : (
        <div className="space-y-6">
          {vencidas.length > 0 && (
            <Card title="Vencidas" className="p-0">
              <div className="p-4 space-y-2">
                {vencidas.map(a => <ActividadRow key={a.id} a={a} />)}
              </div>
            </Card>
          )}
          {pendientes.length > 0 && (
            <Card title="Próximas 7 días" className="p-0">
              <div className="p-4 space-y-2">
                {pendientes.map(a => <ActividadRow key={a.id} a={a} />)}
              </div>
            </Card>
          )}
          {proximas.length > 0 && (
            <Card title="Próximas actividades" className="p-0">
              <div className="p-4 space-y-2">
                {proximas.map(a => <ActividadRow key={a.id} a={a} />)}
              </div>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}

function ActividadRow({ a }: { a: ActividadAgricola }) {
  const vencida = a.dias_restantes < 0;
  const proxima = a.dias_restantes >= 0 && a.dias_restantes <= 7;
  return (
    <div className={`flex items-center gap-3 p-3 rounded-xl ${vencida ? 'bg-red-50' : proxima ? 'bg-amber-50' : 'bg-slate-50'}`}>
      <span className="text-2xl">{a.icono}</span>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-slate-800 text-sm">{a.actividad}</p>
        <p className="text-xs text-slate-500">{a.parcela_nombre} · {fmtDate(a.fecha_programada)}</p>
      </div>
      {vencida ? <Badge color="red">Vencida {Math.abs(a.dias_restantes)}d</Badge> :
       proxima ? <Badge color="amber">En {a.dias_restantes}d</Badge> :
       <Badge color="slate">{a.dias_restantes}d</Badge>}
    </div>
  );
}
