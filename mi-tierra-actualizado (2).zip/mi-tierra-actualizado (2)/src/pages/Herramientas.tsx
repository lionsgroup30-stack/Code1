import { useState } from 'react';
import { Plus, Pencil, Trash2, Wrench, Calendar, Tag } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtMoney, fmtDate, todayISO } from '../lib/format';
import { Button, Modal, Field, inputClass, PageHeader, EmptyState, Card, Badge } from '../components/ui';
import type { Herramienta } from '../lib/types';

const empty = (): Partial<Herramienta> => ({
  nombre: '', tipo: '', estado: 'bueno', fecha_compra: todayISO(), costo: 0, observaciones: '',
});

const estadoColor = (s: string): 'green' | 'amber' | 'red' => s === 'bueno' ? 'green' : s === 'regular' ? 'amber' : 'red';
const estadoLabel = (s: string): string => s === 'bueno' ? 'Bueno' : s === 'regular' ? 'Regular' : 'Malo';

export function HerramientasPage() {
  const { herramientas, config } = useData();
  const crud = useCrud<Herramienta>('herramientas');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Herramienta | null>(null);
  const [form, setForm] = useState<Partial<Herramienta>>(empty());

  const moneda = config?.moneda || 'RD$';

  const openNew = () => { setEditing(null); setForm(empty()); setModal(true); };
  const openEdit = (h: Herramienta) => { setEditing(h); setForm(h); setModal(true); };
  const save = async () => {
    const payload = { ...form, tipo: form.tipo || null, fecha_compra: form.fecha_compra || null };
    if (editing) await crud.update(editing.id, payload); else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => { if (confirm('¿Eliminar herramienta?')) await crud.remove(id); };

  return (
    <div>
      <PageHeader title="Herramientas" subtitle="Inventario de herramientas y equipos de trabajo" action={<Button onClick={openNew}><Plus size={18} /> Nueva Herramienta</Button>} />

      {herramientas.length === 0 ? (
        <EmptyState icon={<Wrench size={32} />} title="Sin herramientas registradas" message="Registra tus herramientas y equipos de trabajo." action={<Button onClick={openNew}><Plus size={18} /> Crear herramienta</Button>} />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {herramientas.map(h => (
            <Card key={h.id} className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <Wrench className="text-brand-600 shrink-0" size={20} />
                    <h3 className="font-bold text-slate-800 truncate">{h.nombre}</h3>
                  </div>
                  {h.tipo && <p className="text-xs text-slate-400 mt-1 flex items-center gap-1"><Tag size={12} />{h.tipo}</p>}
                </div>
                <div className="flex gap-1 shrink-0">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(h)}><Pencil size={14} /></Button>
                  <Button variant="ghost" size="sm" onClick={() => del(h.id)} className="text-red-600"><Trash2 size={14} /></Button>
                </div>
              </div>

              <div className="flex items-center gap-2 mb-3">
                <Badge color={estadoColor(h.estado)}>{estadoLabel(h.estado)}</Badge>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-slate-50">
                  <p className="text-xs text-slate-400 font-medium flex items-center gap-1"><Calendar size={12} /> Compra</p>
                  <p className="text-sm font-semibold text-slate-800">{fmtDate(h.fecha_compra)}</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-50">
                  <p className="text-xs text-slate-400 font-medium">Costo</p>
                  <p className="text-sm font-bold text-slate-800">{fmtMoney(h.costo, moneda)}</p>
                </div>
                {h.observaciones && (
                  <div className="col-span-2 p-3 rounded-xl bg-slate-50">
                    <p className="text-xs text-slate-400 font-medium">Observaciones</p>
                    <p className="text-sm text-slate-600">{h.observaciones}</p>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Herramienta' : 'Nueva Herramienta'}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Nombre" required><input className={inputClass} value={form.nombre || ''} onChange={e => setForm({ ...form, nombre: e.target.value })} /></Field>
          <Field label="Tipo"><input className={inputClass} value={form.tipo || ''} onChange={e => setForm({ ...form, tipo: e.target.value })} /></Field>
          <Field label="Estado">
            <select className={inputClass} value={form.estado || 'bueno'} onChange={e => setForm({ ...form, estado: e.target.value })}>
              <option value="bueno">Bueno</option><option value="regular">Regular</option><option value="malo">Malo</option>
            </select>
          </Field>
          <Field label="Fecha de compra"><input type="date" className={inputClass} value={form.fecha_compra || ''} onChange={e => setForm({ ...form, fecha_compra: e.target.value })} /></Field>
          <Field label="Costo"><input type="number" step="0.01" className={inputClass} value={form.costo ?? 0} onChange={e => setForm({ ...form, costo: +e.target.value })} /></Field>
          <div className="sm:col-span-2"><Field label="Observaciones"><textarea className={inputClass} rows={2} value={form.observaciones || ''} onChange={e => setForm({ ...form, observaciones: e.target.value })} /></Field></div>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}
