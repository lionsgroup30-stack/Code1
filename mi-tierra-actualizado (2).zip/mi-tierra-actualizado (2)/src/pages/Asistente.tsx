import { useData } from '../lib/DataContext';
import { generarRecomendaciones, type Recomendacion } from '../lib/assistant';
import { generarAlertas } from '../lib/alerts';
import { fmtMoney, fmtNum, fmtPct } from '../lib/format';
import { calcDashboard, calcSemaforoFinanciero, rentabilidadPorParcela, rentabilidadPorMercado, rentabilidadPorCultivo, calcPuntoEquilibrio } from '../lib/calculations';
import { Card, PageHeader, EmptyState, Semaforo, KpiCard } from '../components/ui';
import { Brain, TrendingUp, AlertCircle, Award, Target, Lightbulb, PiggyBank, Scale, BarChart3 } from 'lucide-react';

const CAT_ICONS: Record<string, typeof Brain> = {
  produccion: TrendingUp, costos: Scale, finanzas: PiggyBank, inventario: Target,
  comercial: Award, trabajador: Brain, metas: Target, alerta: AlertCircle,
};
const CAT_COLORS: Record<string, string> = {
  produccion: 'bg-brand-50 text-brand-700', costos: 'bg-amber-50 text-amber-700',
  finanzas: 'bg-blue-50 text-blue-700', inventario: 'bg-red-50 text-red-700',
  comercial: 'bg-green-50 text-green-700', trabajador: 'bg-slate-100 text-slate-700',
  metas: 'bg-amber-50 text-amber-700', alerta: 'bg-red-50 text-red-700',
};
const PRIO_COLORS: Record<string, string> = {
  alta: 'border-red-200 bg-red-50', media: 'border-amber-200 bg-amber-50', baja: 'border-blue-200 bg-blue-50',
};

export function AsistentePage() {
  const data = useData();
  if (!data.config) return null;
  const config = data.config;
  const moneda = config.moneda;

  const alertas = generarAlertas({
    parcelas: data.parcelas, cosechas: data.cosechas, gastos: data.gastos,
    inventario: data.inventario, ventas: data.ventas, prestamos: data.prestamos,
    semilleros: data.semilleros, plagas: data.plagas, riego: data.riego,
    metas: data.metas, trasplantes: data.trasplantes, trabajadores: data.trabajadores,
    config,
  });

  const kpis = calcDashboard(
    data.ventas, data.gastos, data.cosechas, data.inventario, data.clientes,
    data.prestamos, config, data.parcelas, data.filas, data.viajes,
    data.vehiculos, data.mercados, data.trabajadores, alertas.length,
  );
  const semFin = calcSemaforoFinanciero(kpis, config);

  const recs = generarRecomendaciones({
    parcelas: data.parcelas, cosechas: data.cosechas, gastos: data.gastos,
    ventas: data.ventas, clientes: data.clientes, mercados: data.mercados,
    inventario: data.inventario, semilleros: data.semilleros, prestamos: data.prestamos,
    trabajadores: data.trabajadores, metas: data.metas, compras: data.compras,
    viajes: data.viajes, vehiculos: data.vehiculos, config, kpis, semaforoFinanciero: semFin,
  });

  const costosFijos = data.gastos.filter(g => !g.parcela_id).reduce((s, g) => s + g.monto, 0);
  const precioPromedio = data.ventas.length > 0 ? data.ventas.reduce((s, v) => s + v.precio_por_libra, 0) / data.ventas.length : 0;
  const puntoEquilibrio = calcPuntoEquilibrio(costosFijos, precioPromedio, kpis.costo_por_libra);

  const rentParcelas = rentabilidadPorParcela(data.parcelas, data.cosechas, data.gastos, data.ventas);
  const rentMercados = rentabilidadPorMercado(data.ventas, data.mercados).filter(m => m.ingresos > 0).sort((a, b) => b.ganancia - a.ganancia);
  const rentCultivos = rentabilidadPorCultivo(data.cultivos, data.parcelas, data.cosechas, data.gastos).filter(r => r.ingresos > 0);

  const flujoSemanal = kpis.ganancia > 0 ? kpis.ganancia / 12 : 0;
  const flujoProyectado = Array.from({ length: 6 }, (_, i) => ({
    mes: i + 1,
    acumulado: kpis.caja + flujoSemanal * 4 * (i + 1),
  }));

  return (
    <div className="space-y-6">
      <PageHeader title="Asistente Agrícola Inteligente" subtitle="Análisis automático, recomendaciones y proyecciones en tiempo real" />

      <div className={`rounded-2xl p-6 border ${semFin.estado === 'verde' ? 'bg-brand-50 border-brand-200' : semFin.estado === 'amarillo' ? 'bg-amber-50 border-amber-200' : 'bg-red-50 border-red-200'}`}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-sm"><Brain className="text-brand-600" size={28} /></div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-slate-500 uppercase">Estado del Negocio</p>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-2xl font-bold text-slate-900">{semFin.etiqueta}</span>
              <Semaforo estado={semFin.estado} label={`Margen ${fmtPct(semFin.margen_real)}`} />
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-slate-500">Utilidad acumulada</p>
            <p className={`text-2xl font-bold ${semFin.utilidad >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtMoney(semFin.utilidad, moneda)}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="Punto de equilibrio" value={`${fmtNum(puntoEquilibrio)} lb`} icon={<Target size={20} />} subtitle="Libras para cubrir costos fijos" />
        <KpiCard label="Flujo semanal" value={fmtMoney(flujoSemanal, moneda)} icon={<TrendingUp size={20} />} accent={flujoSemanal > 0 ? 'green' : 'red'} subtitle="Ganancia proyectada" />
        <KpiCard label="Alertas activas" value={`${alertas.length}`} icon={<AlertCircle size={20} />} accent={alertas.length > 0 ? 'red' : 'green'} />
        <KpiCard label="Recomendaciones" value={`${recs.length}`} icon={<Lightbulb size={20} />} accent="blue" />
      </div>

      <Card title="Recomendaciones Automáticas" className="p-0">
        <div className="p-5">
          {recs.length === 0 ? (
            <EmptyState icon={<Lightbulb size={32} />} title="Sin recomendaciones" message="El sistema generará recomendaciones automáticamente cuando registres datos." />
          ) : (
            <div className="space-y-3">
              {recs.map((r, i) => <RecomendacionCard key={i} r={r} />)}
            </div>
          )}
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Rentabilidad por Parcela" className="p-0">
          <div className="p-5 space-y-3">
            {rentParcelas.length === 0 ? <EmptyState title="Sin datos" /> : rentParcelas.sort((a, b) => b.margen_pct - a.margen_pct).map((r, i) => (
              <div key={r.id} className="flex items-center justify-between p-3 rounded-xl bg-slate-50">
                <div className="flex items-center gap-3">
                  <span className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${i === 0 ? 'bg-amber-100 text-amber-700' : 'bg-slate-200 text-slate-600'}`}>{i + 1}</span>
                  <div><p className="font-semibold text-slate-800 text-sm">{r.nombre}</p><p className="text-xs text-slate-400">{fmtMoney(r.ingresos, moneda)} ingresos</p></div>
                </div>
                <span className={`text-sm font-bold ${r.margen_pct >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtPct(r.margen_pct)}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card title="Comparación de Mercados" className="p-0">
          <div className="p-5 space-y-3">
            {rentMercados.length === 0 ? <EmptyState title="Sin ventas por mercado" /> : rentMercados.map((m, i) => (
              <div key={m.id} className="flex items-center justify-between p-3 rounded-xl bg-slate-50">
                <div><p className="font-semibold text-slate-800 text-sm">{m.nombre}</p><p className="text-xs text-slate-400">{fmtMoney(m.ingresos, moneda)} · {fmtMoney(m.costos, moneda)} transporte</p></div>
                <div className="text-right"><p className={`text-sm font-bold ${m.ganancia >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtMoney(m.ganancia, moneda)}</p>{i === 0 && <p className="text-[10px] text-amber-600 font-semibold">Mejor opción</p>}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card title="Flujo de Caja Proyectado (6 meses)" className="p-0">
        <div className="p-5">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {flujoProyectado.map(f => (
              <div key={f.mes} className="text-center p-3 rounded-xl bg-slate-50">
                <p className="text-xs text-slate-400">Mes {f.mes}</p>
                <p className={`text-sm font-bold ${f.acumulado >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtMoney(f.acumulado, moneda)}</p>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {rentCultivos.length > 0 && (
        <Card title="Rentabilidad por Cultivo" className="p-0">
          <div className="p-5 space-y-3">
            {rentCultivos.sort((a, b) => b.margen_pct - a.margen_pct).map((c) => (
              <div key={c.id} className="flex items-center justify-between p-3 rounded-xl bg-slate-50">
                <div className="flex items-center gap-3">
                  <BarChart3 className="text-slate-400" size={18} />
                  <p className="font-semibold text-slate-800 text-sm">{c.nombre}</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-slate-600">{fmtMoney(c.ingresos, moneda)}</span>
                  <span className={`text-sm font-bold ${c.margen_pct >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtPct(c.margen_pct)}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

function RecomendacionCard({ r }: { r: Recomendacion }) {
  const Icon = CAT_ICONS[r.tipo] || Lightbulb;
  return (
    <div className={`p-4 rounded-xl border ${PRIO_COLORS[r.prioridad]}`}>
      <div className="flex items-start gap-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${CAT_COLORS[r.tipo] || 'bg-slate-100 text-slate-700'}`}><Icon size={20} /></div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <p className="font-bold text-slate-800 text-sm">{r.titulo}</p>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${r.prioridad === 'alta' ? 'bg-red-200 text-red-700' : r.prioridad === 'media' ? 'bg-amber-200 text-amber-700' : 'bg-blue-200 text-blue-700'}`}>{r.prioridad}</span>
          </div>
          <p className="text-sm text-slate-600 mt-1">{r.mensaje}</p>
          <p className="text-xs text-slate-500 mt-1.5 flex items-center gap-1"><Lightbulb size={14} />{r.accion}</p>
        </div>
      </div>
    </div>
  );
}
