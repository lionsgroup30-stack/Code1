import { useState } from 'react';
import { useData } from '../lib/DataContext';
import { rentabilidadPorParcela, rentabilidadPorMercado, rentabilidadPorCliente, rentabilidadPorCultivo, GASTO_CATEGORIAS } from '../lib/calculations';
import { fmtMoney, fmtPct, fmtDate, startOfMonth, startOfYear, startOfWeek } from '../lib/format';
import { Card, PageHeader, Button, Table, Th, Td, EmptyState, Badge } from '../components/ui';
import { FileBarChart, FileSpreadsheet, FileText, Calendar, TrendingUp, TrendingDown } from 'lucide-react';

type Periodo = 'dia' | 'semana' | 'mes' | 'anio';

export function ReportesPage() {
  const data = useData();
  const [periodo, setPeriodo] = useState<Periodo>('mes');
  if (!data.config) return null;
  const moneda = data.config.moneda;

  const now = new Date();
  const inicio = periodo === 'dia' ? now : periodo === 'semana' ? startOfWeek(now) : periodo === 'mes' ? startOfMonth(now) : startOfYear(now);

  const ventasP = data.ventas.filter(v => new Date(v.fecha) >= inicio);
  const gastosP = data.gastos.filter(g => new Date(g.fecha) >= inicio);
  const cosechasP = data.cosechas.filter(c => new Date(c.fecha) >= inicio);

  const totalVentas = ventasP.reduce((s, v) => s + v.total, 0);
  const totalGastos = gastosP.reduce((s, g) => s + g.monto, 0);
  const ganancia = totalVentas - totalGastos;
  const margen = totalVentas > 0 ? (ganancia / totalVentas) * 100 : 0;

  // Gastos por categoría
  const gastosPorCategoria = GASTO_CATEGORIAS.map(cat => ({
    categoria: cat,
    monto: gastosP.filter(g => g.categoria === cat).reduce((s, g) => s + g.monto, 0),
  })).filter(g => g.monto > 0).sort((a, b) => b.monto - a.monto);

  const rentParcelas = rentabilidadPorParcela(data.parcelas, data.cosechas, data.gastos, data.ventas);
  const rentMercados = rentabilidadPorMercado(data.ventas, data.mercados).filter(m => m.ingresos > 0);
  const rentClientes = rentabilidadPorCliente(data.ventas, data.clientes).filter(c => c.ingresos > 0);
  const rentCultivos = rentabilidadPorCultivo(data.cultivos, data.parcelas, data.cosechas, data.gastos).filter(c => c.ingresos > 0);

  const exportCSV = () => {
    const rows: string[][] = [];
    rows.push(['REPORTE', `Resumen ${periodo}`, '']);
    rows.push(['Periodo', fmtDate(inicio), fmtDate(now)]);
    rows.push([]);
    rows.push(['MÉTRICA', 'VALOR']);
    rows.push(['Ventas totales', String(totalVentas.toFixed(2))]);
    rows.push(['Gastos totales', String(totalGastos.toFixed(2))]);
    rows.push(['Ganancia', String(ganancia.toFixed(2))]);
    rows.push(['Margen %', String(margen.toFixed(1))]);
    rows.push(['Producción (lb)', String(cosechasP.reduce((s, c) => s + c.cantidad_libras, 0).toFixed(2))]);
    rows.push([]);
    rows.push(['GASTOS POR CATEGORÍA']);
    rows.push(['Categoría', 'Monto']);
    gastosPorCategoria.forEach(g => rows.push([g.categoria, String(g.monto.toFixed(2))]));
    rows.push([]);
    rows.push(['RENTABILIDAD POR PARCELA']);
    rows.push(['Parcela', 'Ingresos', 'Costos', 'Ganancia', 'Margen %']);
    rentParcelas.forEach(r => rows.push([r.nombre, String(r.ingresos.toFixed(2)), String(r.costos.toFixed(2)), String(r.ganancia.toFixed(2)), String(r.margen_pct.toFixed(1))]));

    const csv = rows.map(r => r.map(c => `"${c.replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `reporte-${periodo}-${new Date().toISOString().split('T')[0]}.csv`;
    a.click(); URL.revokeObjectURL(url);
  };

  const exportPDF = () => {
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write(`<html><head><title>Reporte ${periodo}</title><style>
      body{font-family:Arial,sans-serif;margin:40px;color:#1e293b}
      h1{font-size:24px;border-bottom:2px solid #16a34a;padding-bottom:8px}
      h2{font-size:18px;margin-top:24px;color:#16a34a}
      table{width:100%;border-collapse:collapse;margin:12px 0}
      th,td{padding:8px 12px;text-align:left;border-bottom:1px solid #e2e8f0}
      th{background:#f8fafc;font-weight:bold}
      .kpi{display:inline-block;margin:8px 16px 8px 0;padding:12px 20px;background:#f8fafc;border-radius:8px}
      .kpi-label{font-size:12px;color:#64748b}
      .kpi-value{font-size:20px;font-weight:bold}
      .positive{color:#16a34a}.negative{color:#dc2626}
    </style></head><body>`);
    w.document.write(`<h1>Reporte Agrícola — ${periodo}</h1>`);
    w.document.write(`<p>${data.config?.nombre_finca} · ${fmtDate(inicio)} a ${fmtDate(now)}</p>`);
    w.document.write(`<div><div class="kpi"><div class="kpi-label">Ventas</div><div class="kpi-value">${fmtMoney(totalVentas, moneda)}</div></div>`);
    w.document.write(`<div class="kpi"><div class="kpi-label">Gastos</div><div class="kpi-value">${fmtMoney(totalGastos, moneda)}</div></div>`);
    w.document.write(`<div class="kpi"><div class="kpi-label">Ganancia</div><div class="kpi-value ${ganancia >= 0 ? 'positive' : 'negative'}">${fmtMoney(ganancia, moneda)}</div></div>`);
    w.document.write(`<div class="kpi"><div class="kpi-label">Margen</div><div class="kpi-value">${fmtPct(margen)}</div></div></div>`);
    w.document.write(`<h2>Gastos por Categoría</h2><table><tr><th>Categoría</th><th>Monto</th></tr>`);
    gastosPorCategoria.forEach(g => w.document.write(`<tr><td>${g.categoria}</td><td>${fmtMoney(g.monto, moneda)}</td></tr>`));
    w.document.write(`</table><h2>Rentabilidad por Parcela</h2><table><tr><th>Parcela</th><th>Ingresos</th><th>Costos</th><th>Ganancia</th><th>Margen</th></tr>`);
    rentParcelas.forEach(r => w.document.write(`<tr><td>${r.nombre}</td><td>${fmtMoney(r.ingresos, moneda)}</td><td>${fmtMoney(r.costos, moneda)}</td><td class="${r.ganancia >= 0 ? 'positive' : 'negative'}">${fmtMoney(r.ganancia, moneda)}</td><td>${fmtPct(r.margen_pct)}</td></tr>`));
    w.document.write(`</table><h2>Top Clientes</h2><table><tr><th>Cliente</th><th>Total Compras</th></tr>`);
    rentClientes.slice(0, 10).forEach(c => w.document.write(`<tr><td>${c.nombre}</td><td>${fmtMoney(c.ingresos, moneda)}</td></tr>`));
    w.document.write(`</table></body></html>`);
    w.print();
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Reportes" subtitle="Generación automática de reportes con exportación" action={
        <div className="flex gap-2">
          <Button variant="secondary" onClick={exportCSV}><FileSpreadsheet size={18} /> Excel (CSV)</Button>
          <Button onClick={exportPDF}><FileText size={18} /> PDF</Button>
        </div>
      } />

      {/* Selector de período */}
      <div className="flex gap-2">
        {(['dia', 'semana', 'mes', 'anio'] as Periodo[]).map(p => (
          <button key={p} onClick={() => setPeriodo(p)} className={`px-4 py-2 rounded-xl text-sm font-semibold capitalize transition-colors ${periodo === p ? 'bg-brand-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`}>
            {p === 'dia' ? 'Día' : p === 'semana' ? 'Semana' : p === 'mes' ? 'Mes' : 'Año'}
          </button>
        ))}
      </div>

      {/* Resumen */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-5"><div className="flex items-center gap-3"><TrendingUp className="text-brand-600" size={24} /><div><p className="text-xs text-slate-400">Ventas</p><p className="text-2xl font-bold text-slate-900">{fmtMoney(totalVentas, moneda)}</p></div></div></Card>
        <Card className="p-5"><div className="flex items-center gap-3"><TrendingDown className="text-red-600" size={24} /><div><p className="text-xs text-slate-400">Gastos</p><p className="text-2xl font-bold text-slate-900">{fmtMoney(totalGastos, moneda)}</p></div></div></Card>
        <Card className="p-5"><div className="flex items-center gap-3"><FileBarChart className={ganancia >= 0 ? 'text-brand-600' : 'text-red-600'} size={24} /><div><p className="text-xs text-slate-400">Ganancia</p><p className={`text-2xl font-bold ${ganancia >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtMoney(ganancia, moneda)}</p></div></div></Card>
        <Card className="p-5"><div className="flex items-center gap-3"><Calendar className="text-blue-600" size={24} /><div><p className="text-xs text-slate-400">Margen</p><p className="text-2xl font-bold text-slate-900">{fmtPct(margen)}</p></div></div></Card>
      </div>

      {/* Gastos por categoría */}
      <Card title="Gastos por Categoría" className="p-0">
        {gastosPorCategoria.length === 0 ? <div className="p-5"><EmptyState title="Sin gastos en este período" /></div> : (
          <Table>
            <thead><tr><Th>Categoría</Th><Th className="text-right">Monto</Th><Th className="text-right">% del total</Th></tr></thead>
            <tbody>
              {gastosPorCategoria.map(g => (
                <tr key={g.categoria} className="border-t border-slate-50">
                  <Td><Badge color="slate">{g.categoria}</Badge></Td>
                  <Td className="text-right tabular-nums font-semibold">{fmtMoney(g.monto, moneda)}</Td>
                  <Td className="text-right tabular-nums">{fmtPct((g.monto / totalGastos) * 100, 0)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>

      {/* Rentabilidad por parcela */}
      <Card title="Rentabilidad por Parcela" className="p-0">
        {rentParcelas.length === 0 ? <div className="p-5"><EmptyState title="Sin datos" /></div> : (
          <Table>
            <thead><tr><Th>Parcela</Th><Th className="text-right">Ingresos</Th><Th className="text-right">Costos</Th><Th className="text-right">Ganancia</Th><Th className="text-right">Margen</Th></tr></thead>
            <tbody>
              {rentParcelas.map(r => (
                <tr key={r.id} className="border-t border-slate-50">
                  <Td className="font-medium">{r.nombre}</Td>
                  <Td className="text-right tabular-nums">{fmtMoney(r.ingresos, moneda)}</Td>
                  <Td className="text-right tabular-nums text-red-600">{fmtMoney(r.costos, moneda)}</Td>
                  <Td className={`text-right tabular-nums font-bold ${r.ganancia >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtMoney(r.ganancia, moneda)}</Td>
                  <Td className="text-right tabular-nums">{fmtPct(r.margen_pct)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>

      {/* Rentabilidad por mercado y cultivo */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Por Mercado" className="p-0">
          {rentMercados.length === 0 ? <div className="p-5"><EmptyState title="Sin datos" /></div> : (
            <Table>
              <thead><tr><Th>Mercado</Th><Th className="text-right">Ingresos</Th><Th className="text-right">Ganancia</Th></tr></thead>
              <tbody>{rentMercados.map(m => <tr key={m.id} className="border-t border-slate-50"><Td className="font-medium">{m.nombre}</Td><Td className="text-right tabular-nums">{fmtMoney(m.ingresos, moneda)}</Td><Td className={`text-right tabular-nums font-bold ${m.ganancia >= 0 ? 'text-brand-600' : 'text-red-600'}`}>{fmtMoney(m.ganancia, moneda)}</Td></tr>)}</tbody>
            </Table>
          )}
        </Card>
        <Card title="Por Cultivo" className="p-0">
          {rentCultivos.length === 0 ? <div className="p-5"><EmptyState title="Sin datos" /></div> : (
            <Table>
              <thead><tr><Th>Cultivo</Th><Th className="text-right">Ingresos</Th><Th className="text-right">Margen</Th></tr></thead>
              <tbody>{rentCultivos.map(c => <tr key={c.id} className="border-t border-slate-50"><Td className="font-medium">{c.nombre}</Td><Td className="text-right tabular-nums">{fmtMoney(c.ingresos, moneda)}</Td><Td className="text-right tabular-nums font-bold">{fmtPct(c.margen_pct)}</Td></tr>)}</tbody>
            </Table>
          )}
        </Card>
      </div>

      {/* Top clientes */}
      <Card title="Top Clientes" className="p-0">
        {rentClientes.length === 0 ? <div className="p-5"><EmptyState title="Sin clientes" /></div> : (
          <Table>
            <thead><tr><Th>#</Th><Th>Cliente</Th><Th className="text-right">Total Compras</Th></tr></thead>
            <tbody>
              {rentClientes.slice(0, 10).map((c, i) => (
                <tr key={c.id} className="border-t border-slate-50">
                  <Td className="font-bold text-slate-400">{i + 1}</Td>
                  <Td className="font-medium">{c.nombre}</Td>
                  <Td className="text-right tabular-nums font-bold">{fmtMoney(c.ingresos, moneda)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </div>
  );
}
