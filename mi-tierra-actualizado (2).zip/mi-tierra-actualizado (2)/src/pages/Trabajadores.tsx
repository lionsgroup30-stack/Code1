import { useState } from 'react';
import { Plus, Pencil, Trash2, HardHat, Phone, Calendar, TrendingUp } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { rentabilidadPorTrabajador } from '../lib/calculations';
import { fmtMoney, fmtDate, todayISO } from '../lib/format';
import {
  Button, Modal, Field, inputClass, PageHeader, EmptyState, Card,
  Table, Th, Td, Badge, KpiCard, Semaforo,
} from '../components/ui';
import type { Trabajador } from '../lib/types';
import type { RentabilidadItem } from '../lib/calculations';

const ROLES = ['jornalero', 'supervisor', 'técnico', 'operador'] as const;
const roleLabel = (r: string): string => r.charAt(0).toUpperCase() + r.slice(1);

const empty = (): Partial<Trabajador> => ({
  nombre: '',
  rol: 'jornalero',
  telefono: '',
  jornal_diario: 0,
  activo: true,
  fecha_ingreso: todayISO(),
  observaciones: '',
});

// Semáforo de rentabilidad: verde ≥20%, amarillo 5–19%, rojo <0%, azul 0–4% sin pérdida
function rentSemaforo(r: RentabilidadItem): { estado: 'verde' | 'amarillo' | 'rojo' | 'azul'; label: string } {
  if (r.ingresos === 0 && r.costos === 0) return { estado: 'azul', label: 'Sin actividad' };
  if (r.margen_pct >= 20) return { estado: 'verde', label: `${r.margen_pct.toFixed(0)}%` };
  if (r.margen_pct >= 5) return { estado: 'amarillo', label: `${r.margen_pct.toFixed(0)}%` };
  if (r.margen_pct < 0) return { estado: 'rojo', label: `${r.margen_pct.toFixed(0)}%` };
  return { estado: 'azul', label: `${r.margen_pct.toFixed(0)}%` };
}

export function TrabajadoresPage() {
  const { trabajadores, cosechas, gastos, config } = useData();
  const crud = useCrud<Trabajador>('trabajadores');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Trabajador | null>(null);
  const [form, setForm] = useState<Partial<Trabajador>>(empty());

  const moneda = config?.moneda || 'RD$';

  // ---- KPIs ----
  const total = trabajadores.length;
  const activos = trabajadores.filter(t => t.activo).length;
  const jornalPromedio = activos > 0
    ? trabajadores.filter(t => t.activo).reduce((s, t) => s + t.jornal_diario, 0) / activos
    : 0;
  const costoMensual = trabajadores
    .filter(t => t.activo)
    .reduce((s, t) => s + t.jornal_diario * 30, 0);

  // ---- Rentabilidad por trabajador ----
  const rentMap = new Map<string, RentabilidadItem>(
    rentabilidadPorTrabajador(trabajadores, cosechas, gastos).map(r => [r.id, r]),
  );

  // ---- Handlers ----
  const openNew = () => { setEditing(null); setForm(empty()); setModal(true); };
  const openEdit = (t: Trabajador) => { setEditing(t); setForm(t); setModal(true); };
  const save = async () => {
    const payload = {
      ...form,
      telefono: form.telefono || null,
      observaciones: form.observaciones || null,
      fecha_ingreso: form.fecha_ingreso || todayISO(),
    };
    if (editing) await crud.update(editing.id, payload);
    else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => {
    if (confirm('¿Eliminar trabajador?')) await crud.remove(id);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Trabajadores"
        subtitle="Gestión de personal agrícola"
        action={<Button onClick={openNew}><Plus size={18} /> Nuevo Trabajador</Button>}
      />

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          label="Total Trabajadores"
          value={`${total}`}
          subtitle={`${activos} activos · ${total - activos} inactivos`}
          icon={<HardHat size={20} />}
          accent="brand"
        />
        <KpiCard
          label="Trabajadores Activos"
          value={`${activos}`}
          subtitle={total > 0 ? `${((activos / total) * 100).toFixed(0)}% de la plantilla` : '—'}
          icon={<TrendingUp size={20} />}
          accent="green"
        />
        <KpiCard
          label="Jornal Promedio"
          value={fmtMoney(jornalPromedio, moneda)}
          subtitle="Por día (activos)"
          icon={<Calendar size={20} />}
          accent="amber"
        />
        <KpiCard
          label="Costo Mensual Total"
          value={fmtMoney(costoMensual, moneda)}
          subtitle="Nómina estimada (30 días)"
          icon={<TrendingUp size={20} />}
          accent="blue"
        />
      </div>

      {/* Tabla o estado vacío */}
      {trabajadores.length === 0 ? (
        <EmptyState
          icon={<HardHat size={32} />}
          title="Sin trabajadores registrados"
          message="Registra tu personal agrícola para llevar control de jornales, costos y rentabilidad por trabajador."
          action={<Button onClick={openNew}><Plus size={18} /> Crear trabajador</Button>}
        />
      ) : (
        <Card className="overflow-hidden">
          <Table>
            <thead className="bg-slate-50/80">
              <tr>
                <Th>Nombre</Th>
                <Th>Rol</Th>
                <Th>Teléfono</Th>
                <Th>Jornal Diario</Th>
                <Th>Fecha Ingreso</Th>
                <Th>Estado</Th>
                <Th>Rentabilidad</Th>
                <Th className="text-right">Acciones</Th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {trabajadores.map(t => {
                const r = rentMap.get(t.id);
                const sem = r ? rentSemaforo(r) : null;
                return (
                  <tr key={t.id} className="hover:bg-slate-50/60 transition-colors">
                    <Td>
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-brand-50 flex items-center justify-center shrink-0">
                          <HardHat className="text-brand-600" size={18} />
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-slate-800 truncate">{t.nombre}</p>
                          {t.observaciones && (
                            <p className="text-xs text-slate-400 truncate max-w-[200px]">{t.observaciones}</p>
                          )}
                        </div>
                      </div>
                    </Td>
                    <Td>
                      <Badge color={t.rol === 'supervisor' ? 'blue' : t.rol === 'técnico' ? 'earth' : 'slate'}>
                        {roleLabel(t.rol)}
                      </Badge>
                    </Td>
                    <Td>
                      {t.telefono ? (
                        <span className="inline-flex items-center gap-1.5 text-slate-600">
                          <Phone size={13} className="text-slate-400" />
                          {t.telefono}
                        </span>
                      ) : (
                        <span className="text-slate-300">—</span>
                      )}
                    </Td>
                    <Td>
                      <span className="font-semibold tabular-nums text-slate-800">
                        {fmtMoney(t.jornal_diario, moneda)}
                      </span>
                    </Td>
                    <Td>
                      <span className="inline-flex items-center gap-1.5 text-slate-600">
                        <Calendar size={13} className="text-slate-400" />
                        {fmtDate(t.fecha_ingreso)}
                      </span>
                    </Td>
                    <Td>
                      {t.activo ? (
                        <Badge color="green">Activo</Badge>
                      ) : (
                        <Badge color="slate">Inactivo</Badge>
                      )}
                    </Td>
                    <Td>
                      {sem && r ? (
                        <div className="flex flex-col gap-1">
                          <Semaforo estado={sem.estado} label={sem.label} size="sm" />
                          <span className="text-xs text-slate-400 tabular-nums">
                            {fmtMoney(r.ganancia, moneda)}
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-300 text-xs">—</span>
                      )}
                    </Td>
                    <Td className="text-right">
                      <div className="inline-flex gap-1">
                        <Button variant="ghost" size="sm" onClick={() => openEdit(t)}><Pencil size={14} /></Button>
                        <Button variant="ghost" size="sm" onClick={() => del(t.id)} className="text-red-600"><Trash2 size={14} /></Button>
                      </div>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </Card>
      )}

      {/* Modal formulario */}
      <Modal
        open={modal}
        onClose={() => setModal(false)}
        title={editing ? 'Editar Trabajador' : 'Nuevo Trabajador'}
        size="lg"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Nombre" required>
            <input
              className={inputClass}
              value={form.nombre || ''}
              onChange={e => setForm({ ...form, nombre: e.target.value })}
              placeholder="Nombre completo"
            />
          </Field>
          <Field label="Rol" required>
            <select
              className={inputClass}
              value={form.rol || 'jornalero'}
              onChange={e => setForm({ ...form, rol: e.target.value })}
            >
              {ROLES.map(r => <option key={r} value={r}>{roleLabel(r)}</option>)}
            </select>
          </Field>
          <Field label="Teléfono">
            <input
              className={inputClass}
              value={form.telefono || ''}
              onChange={e => setForm({ ...form, telefono: e.target.value })}
              placeholder="809-000-0000"
            />
          </Field>
          <Field label="Jornal Diario" required hint="Pago por día de trabajo">
            <input
              type="number"
              step="0.01"
              min="0"
              className={inputClass}
              value={form.jornal_diario ?? 0}
              onChange={e => setForm({ ...form, jornal_diario: +e.target.value })}
            />
          </Field>
          <Field label="Fecha de Ingreso">
            <input
              type="date"
              className={inputClass}
              value={form.fecha_ingreso || ''}
              onChange={e => setForm({ ...form, fecha_ingreso: e.target.value })}
            />
          </Field>
          <Field label="Estado">
            <button
              type="button"
              onClick={() => setForm({ ...form, activo: !form.activo })}
              className={`flex items-center gap-2.5 ${inputClass} text-left`}
            >
              <span
                className={`relative inline-flex h-5 w-9 shrink-0 rounded-full transition-colors ${form.activo ? 'bg-brand-600' : 'bg-slate-300'}`}
              >
                <span
                  className={`absolute top-0.5 left-0.5 h-4 w-4 rounded-full bg-white shadow-sm transition-transform ${form.activo ? 'translate-x-4' : ''}`}
                />
              </span>
              <span className="text-sm font-medium text-slate-700">
                {form.activo ? 'Activo' : 'Inactivo'}
              </span>
            </button>
          </Field>
          <div className="sm:col-span-2">
            <Field label="Observaciones">
              <textarea
                className={inputClass}
                rows={2}
                value={form.observaciones || ''}
                onChange={e => setForm({ ...form, observaciones: e.target.value })}
                placeholder="Notas sobre el trabajador…"
              />
            </Field>
          </div>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving || !form.nombre}>
            {editing ? 'Guardar' : 'Crear'}
          </Button>
        </div>
      </Modal>
    </div>
  );
}
