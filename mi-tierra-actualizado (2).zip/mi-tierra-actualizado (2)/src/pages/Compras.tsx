import { useState } from 'react';
import { Plus, Pencil, Trash2, ShoppingBag, Coins, CreditCard } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtMoney, fmtDate, fmtInt, todayISO, startOfMonth } from '../lib/format';
import { Button, Modal, Field, inputClass, PageHeader, EmptyState, Card, Table, Th, Td, Badge, KpiCard } from '../components/ui';
import type { Compra } from '../lib/types';

const METODOS_PAGO = ['efectivo', 'transferencia', 'tarjeta', 'credito'] as const;
type MetodoPago = (typeof METODOS_PAGO)[number];

const metodoBadge: Record<MetodoPago, 'green' | 'blue' | 'amber' | 'slate'> = {
  efectivo: 'green',
  transferencia: 'blue',
  tarjeta: 'amber',
  credito: 'slate',
};

const metodoLabel: Record<MetodoPago, string> = {
  efectivo: 'Efectivo',
  transferencia: 'Transferencia',
  tarjeta: 'Tarjeta',
  credito: 'Crédito',
};

const empty = (): Partial<Compra> => ({
  proveedor: '', fecha: todayISO(), descripcion: '', monto_total: 0,
  metodo_pago: 'efectivo', inventario_item_id: '', cantidad: 1,
});

export function ComprasPage() {
  const { compras, inventario, config } = useData();
  const crud = useCrud<Compra>('compras');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Compra | null>(null);
  const [form, setForm] = useState<Partial<Compra>>(empty());
  const moneda = config?.moneda || 'RD$';

  const openNew = () => { setEditing(null); setForm(empty()); setModal(true); };
  const openEdit = (c: Compra) => { setEditing(c); setForm(c); setModal(true); };

  const save = async () => {
    const payload = {
      ...form,
      proveedor: form.proveedor || null,
      descripcion: form.descripcion || null,
      inventario_item_id: form.inventario_item_id || null,
    };
    if (editing) await crud.update(editing.id, payload);
    else await crud.insert(payload);
    setModal(false);
  };

  const del = async (id: string) => { if (confirm('¿Eliminar compra?')) await crud.remove(id); };

  const totalCompras = compras.length;
  const montoTotal = compras.reduce((s, c) => s + (c.monto_total || 0), 0);
  const sMes = startOfMonth();
  const comprasMes = compras.filter(c => new Date(c.fecha) >= sMes);
  const montoMes = comprasMes.reduce((s, c) => s + (c.monto_total || 0), 0);
  const promedio = totalCompras > 0 ? montoTotal / totalCompras : 0;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Compras"
        subtitle="Registro de compras de insumos y equipos"
        action={<Button onClick={openNew}><Plus size={18} /> Nueva Compra</Button>}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="Total Compras" value={fmtInt(totalCompras)} icon={<ShoppingBag size={20} />} accent="green" subtitle="Registros históricos" />
        <KpiCard label="Monto Total" value={fmtMoney(montoTotal, moneda)} icon={<Coins size={20} />} accent="blue" subtitle="Acumulado histórico" />
        <KpiCard label="Compras del Mes" value={fmtMoney(montoMes, moneda)} icon={<CreditCard size={20} />} accent="amber" subtitle={`${comprasMes.length} transacciones`} />
        <KpiCard label="Compra Promedio" value={fmtMoney(promedio, moneda)} icon={<Coins size={20} />} accent="slate" subtitle="Por transacción" />
      </div>

      {compras.length === 0 ? (
        <EmptyState
          icon={<ShoppingBag size={32} />}
          title="Sin compras registradas"
          message="Registra tus compras de insumos, equipos y materiales para llevar el control de gastos."
          action={<Button onClick={openNew}><Plus size={18} /> Registrar primera compra</Button>}
        />
      ) : (
        <Card className="p-0">
          <Table>
            <thead><tr>
              <Th>Fecha</Th><Th>Proveedor</Th><Th>Descripción</Th><Th>Inventario</Th>
              <Th className="text-right">Cantidad</Th><Th>Método Pago</Th><Th className="text-right">Monto Total</Th><Th></Th>
            </tr></thead>
            <tbody>
              {compras.map(c => {
                const metodo = (c.metodo_pago as MetodoPago) || 'efectivo';
                return (
                  <tr key={c.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                    <Td className="whitespace-nowrap">{fmtDate(c.fecha)}</Td>
                    <Td className="font-medium">{c.proveedor || '—'}</Td>
                    <Td className="text-slate-600">{c.descripcion || '—'}</Td>
                    <Td className="text-slate-600">{c.inventario?.nombre || '—'}</Td>
                    <Td className="text-right tabular-nums">{fmtInt(c.cantidad)}</Td>
                    <Td><Badge color={metodoBadge[metodo]}>{metodoLabel[metodo]}</Badge></Td>
                    <Td className="text-right tabular-nums font-bold text-slate-900">{fmtMoney(c.monto_total, moneda)}</Td>
                    <Td>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" onClick={() => openEdit(c)}><Pencil size={14} /></Button>
                        <Button variant="ghost" size="sm" onClick={() => del(c.id)} className="text-red-600"><Trash2 size={14} /></Button>
                      </div>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </Card>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Compra' : 'Nueva Compra'}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Proveedor"><input className={inputClass} value={form.proveedor || ''} onChange={e => setForm({ ...form, proveedor: e.target.value })} placeholder="Nombre del proveedor" /></Field>
          <Field label="Fecha" required><input type="date" className={inputClass} value={form.fecha || ''} onChange={e => setForm({ ...form, fecha: e.target.value })} /></Field>
          <div className="sm:col-span-2"><Field label="Descripción"><input className={inputClass} value={form.descripcion || ''} onChange={e => setForm({ ...form, descripcion: e.target.value })} placeholder="Detalle de la compra" /></Field></div>
          <Field label="Monto total" required><input type="number" step="0.01" className={inputClass} value={form.monto_total ?? 0} onChange={e => setForm({ ...form, monto_total: +e.target.value })} /></Field>
          <Field label="Método de pago" required>
            <select className={inputClass} value={form.metodo_pago || 'efectivo'} onChange={e => setForm({ ...form, metodo_pago: e.target.value })}>
              {METODOS_PAGO.map(m => <option key={m} value={m}>{metodoLabel[m]}</option>)}
            </select>
          </Field>
          <Field label="Inventario item" hint="Opcional — vincula la compra a un item de inventario">
            <select className={inputClass} value={form.inventario_item_id || ''} onChange={e => setForm({ ...form, inventario_item_id: e.target.value })}>
              <option value="">— Ninguno —</option>
              {inventario.map(i => <option key={i.id} value={i.id}>{i.nombre}</option>)}
            </select>
          </Field>
          <Field label="Cantidad" required><input type="number" className={inputClass} value={form.cantidad ?? 1} onChange={e => setForm({ ...form, cantidad: +e.target.value })} /></Field>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}
