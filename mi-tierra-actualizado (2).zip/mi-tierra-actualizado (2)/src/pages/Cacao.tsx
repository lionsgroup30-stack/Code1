import { useState } from 'react';
import { Plus, Pencil, Trash2, Coffee } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtMoney, fmtNum, fmtDate, todayISO } from '../lib/format';
import { Button, Modal, Field, inputClass, Table, Th, Td, PageHeader, EmptyState, Card, Badge, KpiCard } from '../components/ui';
import type { CacaoLote } from '../lib/types';

const empty = (): Partial<CacaoLote> => ({
  parcela_id: '', fecha_cosecha: todayISO(), libras_humedo: 0, libras_seco: 0,
  precio_libra_humedo: 0, precio_libra_seco: 0, fermentacion_dias: 0, secado_dias: 0,
  estado: 'fresco', observaciones: '',
});

export function CacaoPage() {
  const { cacao_lotes, parcelas, config } = useData();
  const crud = useCrud<CacaoLote>('cacao_lotes');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<CacaoLote | null>(null);
  const [form, setForm] = useState<Partial<CacaoLote>>(empty());
  const moneda = config?.moneda || 'RD$';

  const openNew = () => { setEditing(null); setForm(empty()); setModal(true); };
  const openEdit = (c: CacaoLote) => { setEditing(c); setForm(c); setModal(true); };
  const save = async () => {
    const payload = { ...form, parcela_id: form.parcela_id || null };
    if (editing) await crud.update(editing.id, payload); else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => { if (confirm('¿Eliminar lote de cacao?')) await crud.remove(id); };

  const totalHumedo = cacao_lotes.reduce((s, c) => s + c.libras_humedo, 0);
  const totalSeco = cacao_lotes.reduce((s, c) => s + c.libras_seco, 0);
  const valorHumedo = cacao_lotes.reduce((s, c) => s + c.libras_humedo * c.precio_libra_humedo, 0);
  const valorSeco = cacao_lotes.reduce((s, c) => s + c.libras_seco * c.precio_libra_seco, 0);
  const mermaPromedio = totalHumedo > 0 ? ((totalHumedo - totalSeco) / totalHumedo) * 100 : 0;

  return (
    <div className="space-y-6">
      <PageHeader title="Cacao" subtitle="Procesamiento de cacao: fermentación, secado y análisis de merma" action={<Button onClick={openNew}><Plus size={18} /> Nuevo Lote</Button>} />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="Cacao húmedo" value={`${fmtNum(totalHumedo)} lb`} icon={<Coffee size={20} />} accent="amber" />
        <KpiCard label="Cacao seco" value={`${fmtNum(totalSeco)} lb`} icon={<Coffee size={20} />} accent="default" subtitle={`Merma: ${fmtNum(mermaPromedio, 1)}%`} />
        <KpiCard label="Valor húmedo" value={fmtMoney(valorHumedo, moneda)} icon={<Coffee size={20} />} accent="green" />
        <KpiCard label="Valor seco" value={fmtMoney(valorSeco, moneda)} icon={<Coffee size={20} />} accent="green" />
      </div>

      {cacao_lotes.length === 0 ? (
        <EmptyState icon={<Coffee size={32} />} title="Sin lotes de cacao" message="Registra lotes de cacao para controlar fermentación, secado y merma." action={<Button onClick={openNew}><Plus size={18} /> Crear lote</Button>} />
      ) : (
        <Card className="p-0">
          <Table>
            <thead><tr>
              <Th>Fecha</Th><Th>Parcela</Th><Th>Estado</Th>
              <Th className="text-right">Húmedo (lb)</Th><Th className="text-right">Seco (lb)</Th>
              <Th className="text-right">Merma</Th><Th className="text-right">Ferment.</Th>
              <Th className="text-right">Secado</Th><Th className="text-right">Valor</Th><Th></Th>
            </tr></thead>
            <tbody>
              {cacao_lotes.map(c => {
                const merma = c.libras_humedo > 0 ? ((c.libras_humedo - c.libras_seco) / c.libras_humedo) * 100 : 0;
                const valor = (c.libras_seco || c.libras_humedo) * (c.precio_libra_seco || c.precio_libra_humedo);
                return (
                  <tr key={c.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                    <Td>{fmtDate(c.fecha_cosecha)}</Td>
                    <Td>{c.parcelas?.nombre || '—'}</Td>
                    <Td><Badge color={c.estado === 'seco' ? 'green' : c.estado === 'fermentando' ? 'amber' : 'earth'}>{c.estado}</Badge></Td>
                    <Td className="text-right tabular-nums">{fmtNum(c.libras_humedo)}</Td>
                    <Td className="text-right tabular-nums">{fmtNum(c.libras_seco)}</Td>
                    <Td className="text-right tabular-nums text-amber-600">{fmtNum(merma, 1)}%</Td>
                    <Td className="text-right tabular-nums">{c.fermentacion_dias}d</Td>
                    <Td className="text-right tabular-nums">{c.secado_dias}d</Td>
                    <Td className="text-right tabular-nums font-bold">{fmtMoney(valor, moneda)}</Td>
                    <Td><div className="flex gap-1"><Button variant="ghost" size="sm" onClick={() => openEdit(c)}><Pencil size={14} /></Button><Button variant="ghost" size="sm" onClick={() => del(c.id)} className="text-red-600"><Trash2 size={14} /></Button></div></Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </Card>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Lote de Cacao' : 'Nuevo Lote de Cacao'} size="lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Parcela"><select className={inputClass} value={form.parcela_id || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value })}><option value="">— Seleccionar —</option>{parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}</select></Field>
          <Field label="Fecha cosecha" required><input type="date" className={inputClass} value={form.fecha_cosecha || ''} onChange={e => setForm({ ...form, fecha_cosecha: e.target.value })} /></Field>
          <Field label="Libras húmedo"><input type="number" step="0.01" className={inputClass} value={form.libras_humedo ?? 0} onChange={e => setForm({ ...form, libras_humedo: +e.target.value })} /></Field>
          <Field label="Libras seco"><input type="number" step="0.01" className={inputClass} value={form.libras_seco ?? 0} onChange={e => setForm({ ...form, libras_seco: +e.target.value })} /></Field>
          <Field label="Precio/lb húmedo"><input type="number" step="0.01" className={inputClass} value={form.precio_libra_humedo ?? 0} onChange={e => setForm({ ...form, precio_libra_humedo: +e.target.value })} /></Field>
          <Field label="Precio/lb seco"><input type="number" step="0.01" className={inputClass} value={form.precio_libra_seco ?? 0} onChange={e => setForm({ ...form, precio_libra_seco: +e.target.value })} /></Field>
          <Field label="Días fermentación"><input type="number" className={inputClass} value={form.fermentacion_dias ?? 0} onChange={e => setForm({ ...form, fermentacion_dias: +e.target.value })} /></Field>
          <Field label="Días secado"><input type="number" className={inputClass} value={form.secado_dias ?? 0} onChange={e => setForm({ ...form, secado_dias: +e.target.value })} /></Field>
          <Field label="Estado"><select className={inputClass} value={form.estado || 'fresco'} onChange={e => setForm({ ...form, estado: e.target.value })}><option value="fresco">Fresco</option><option value="fermentando">Fermentando</option><option value="secando">Secando</option><option value="seco">Seco</option></select></Field>
          <div className="sm:col-span-2"><Field label="Observaciones"><textarea className={inputClass} rows={2} value={form.observaciones || ''} onChange={e => setForm({ ...form, observaciones: e.target.value })} /></Field></div>
        </div>
        <div className="flex justify-end gap-2 mt-5"><Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button><Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button></div>
      </Modal>
    </div>
  );
}
