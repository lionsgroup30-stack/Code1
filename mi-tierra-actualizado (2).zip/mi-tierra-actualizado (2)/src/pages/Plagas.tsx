import { useState } from 'react';
import { Plus, Pencil, Trash2, Bug } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtMoney, fmtNum, fmtDate, todayISO } from '../lib/format';
import { Button, Modal, Field, inputClass, Table, Th, Td, PageHeader, EmptyState, Card, Badge } from '../components/ui';
import type { Plaga } from '../lib/types';

const empty = (parcelaId = ''): Partial<Plaga> => ({
  parcela_id: parcelaId, fecha: todayISO(), tipo_plaga: '', producto: '', cantidad: 0, unidad: 'ml', costo: 0, severidad: 'baja', foto_url: '', tratamiento: '', resultado: '', observaciones: '',
});

const sevColor = (s: string): 'red' | 'amber' | 'slate' => s === 'alta' ? 'red' : s === 'media' ? 'amber' : 'slate';
const sevLabel = (s: string): string => s === 'alta' ? 'Alta' : s === 'media' ? 'Media' : 'Baja';

export function PlagasPage() {
  const { plagas, parcelas, config } = useData();
  const crud = useCrud<Plaga>('plagas');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Plaga | null>(null);
  const [form, setForm] = useState<Partial<Plaga>>(empty());

  const moneda = config?.moneda || 'RD$';

  const openNew = () => { setEditing(null); setForm(empty(parcelas[0]?.id || '')); setModal(true); };
  const openEdit = (p: Plaga) => { setEditing(p); setForm(p); setModal(true); };
  const save = async () => {
    const payload = { ...form, parcela_id: form.parcela_id || null, producto: form.producto || null, foto_url: form.foto_url || null, tratamiento: form.tratamiento || null, resultado: form.resultado || null };
    if (editing) await crud.update(editing.id, payload); else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => { if (confirm('¿Eliminar registro de plaga?')) await crud.remove(id); };

  return (
    <div>
      <PageHeader title="Plagas" subtitle="Control y seguimiento de plagas por parcela" action={<Button onClick={openNew} disabled={parcelas.length === 0}><Plus size={18} /> Nuevo Registro</Button>} />

      {plagas.length === 0 ? (
        <EmptyState icon={<Bug size={32} />} title="Sin registros de plagas" message={parcelas.length === 0 ? 'Primero crea una parcela.' : 'Registra las plagas detectadas y su tratamiento.'} action={parcelas.length > 0 ? <Button onClick={openNew}><Plus size={18} /> Registrar plaga</Button> : undefined} />
      ) : (
        <Card className="p-0">
          <Table>
            <thead><tr>
              <Th>Fecha</Th><Th>Parcela</Th><Th>Tipo plaga</Th><Th>Severidad</Th>
              <Th>Tratamiento</Th><Th>Resultado</Th>
              <Th className="text-right">Costo</Th><Th></Th>
            </tr></thead>
            <tbody>
              {plagas.map(p => (
                <tr key={p.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                  <Td>{fmtDate(p.fecha)}</Td>
                  <Td className="font-medium">{p.parcelas?.nombre || '—'}</Td>
                  <Td>{p.tipo_plaga || '—'}</Td>
                  <Td><Badge color={sevColor(p.severidad)}>{sevLabel(p.severidad)}</Badge></Td>
                  <Td className="text-slate-500">{p.tratamiento || '—'}</Td>
                  <Td className="text-slate-500">{p.resultado || '—'}</Td>
                  <Td className="text-right tabular-nums font-bold">{fmtMoney(p.costo, moneda)}</Td>
                  <Td>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" onClick={() => openEdit(p)}><Pencil size={14} /></Button>
                      <Button variant="ghost" size="sm" onClick={() => del(p.id)} className="text-red-600"><Trash2 size={14} /></Button>
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Registro de Plaga' : 'Nuevo Registro de Plaga'}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Parcela" required>
            <select className={inputClass} value={form.parcela_id || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value })}>
              {parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
            </select>
          </Field>
          <Field label="Fecha" required><input type="date" className={inputClass} value={form.fecha || ''} onChange={e => setForm({ ...form, fecha: e.target.value })} /></Field>
          <Field label="Tipo de plaga" required><input className={inputClass} value={form.tipo_plaga || ''} onChange={e => setForm({ ...form, tipo_plaga: e.target.value })} /></Field>
          <Field label="Producto"><input className={inputClass} value={form.producto || ''} onChange={e => setForm({ ...form, producto: e.target.value })} /></Field>
          <Field label="Cantidad" required><input type="number" step="0.01" className={inputClass} value={form.cantidad ?? 0} onChange={e => setForm({ ...form, cantidad: +e.target.value })} /></Field>
          <Field label="Unidad"><input className={inputClass} value={form.unidad || 'ml'} onChange={e => setForm({ ...form, unidad: e.target.value })} /></Field>
          <Field label="Costo"><input type="number" step="0.01" className={inputClass} value={form.costo ?? 0} onChange={e => setForm({ ...form, costo: +e.target.value })} /></Field>
          <Field label="Severidad">
            <select className={inputClass} value={form.severidad || 'baja'} onChange={e => setForm({ ...form, severidad: e.target.value })}>
              <option value="baja">Baja</option><option value="media">Media</option><option value="alta">Alta</option>
            </select>
          </Field>
          <Field label="Foto (URL)"><input className={inputClass} value={form.foto_url || ''} onChange={e => setForm({ ...form, foto_url: e.target.value })} placeholder="https://..." /></Field>
          <Field label="Tratamiento"><input className={inputClass} value={form.tratamiento || ''} onChange={e => setForm({ ...form, tratamiento: e.target.value })} placeholder="Ej: Aplicar insecticida X" /></Field>
          <Field label="Resultado"><input className={inputClass} value={form.resultado || ''} onChange={e => setForm({ ...form, resultado: e.target.value })} placeholder="Ej: Controlado" /></Field>
          <div className="sm:col-span-2"><Field label="Observaciones"><textarea className={inputClass} rows={2} value={form.observaciones || ''} onChange={e => setForm({ ...form, observaciones: e.target.value })} /></Field></div>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}
