import { useState } from 'react';
import { Plus, Pencil, Trash2, Sprout, Calendar } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { calcSemillero } from '../lib/calculations';
import { fmtDate, fmtPct, todayISO } from '../lib/format';
import { Button, Modal, Field, inputClass, PageHeader, EmptyState, Semaforo } from '../components/ui';
import type { Semillero } from '../lib/types';

const empty = (): Partial<Semillero> => ({
  cultivo_id: '', fecha_siembra: todayISO(), cantidad_semillas: 0, variedad: '',
  numero_bandejas: 0, sustrato: '', semillas_germinadas: 0, dias_para_trasplante: 35,
  observaciones: '', estado: 'siembra', proveedor: '', costo: 0, porcentaje_esperado_germinacion: 85,
});

export function SemillerosPage() {
  const { semilleros, cultivos, config } = useData();
  const crud = useCrud<Semillero>('semilleros');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Semillero | null>(null);
  const [form, setForm] = useState<Partial<Semillero>>(empty());

  const openNew = () => { setEditing(null); setForm({ ...empty(), dias_para_trasplante: config?.dias_trasplante_default ?? 35 }); setModal(true); };
  const openEdit = (s: Semillero) => { setEditing(s); setForm(s); setModal(true); };

  const save = async () => {
    const payload = { ...form, cultivo_id: form.cultivo_id || null };
    if (editing) await crud.update(editing.id, payload);
    else await crud.insert(payload);
    setModal(false);
  };

  const del = async (id: string) => { if (confirm('¿Eliminar este semillero?')) await crud.remove(id); };

  return (
    <div>
      <PageHeader title="Semilleros" subtitle="Seguimiento inteligente de germinación y trasplante" action={<Button onClick={openNew}><Plus size={18} /> Nuevo Semillero</Button>} />
      {semilleros.length === 0 ? (
        <EmptyState icon={<Sprout size={32} />} title="Sin semilleros registrados" message="Registra tus bandejas de semillero para calcular automáticamente la fecha de trasplante, germinación y estado." action={<Button onClick={openNew}><Plus size={18} /> Crear primer semillero</Button>} />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {semilleros.map(s => {
            const calc = calcSemillero(s);
            const cultivo = cultivos.find(c => c.id === s.cultivo_id);
            return (
              <div key={s.id} className="bg-white rounded-2xl border border-slate-200/70 shadow-sm p-5 hover:shadow-md transition-all">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <Sprout className="text-brand-600" size={20} />
                      <h3 className="font-bold text-slate-800">{s.variedad || cultivo?.nombre || 'Semillero'}</h3>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">Siembra: {fmtDate(s.fecha_siembra)}</p>
                  </div>
                  <Semaforo estado={calc.estado === 'listo' ? 'verde' : calc.estado === 'atrasado' ? 'rojo' : calc.estado === 'trasplantado' ? 'azul' : 'amarillo'} label={calc.estado} size="sm" />
                </div>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <Info label="Edad" value={`${calc.edad_dias} días`} />
                  <Info label="Germinación" value={fmtPct(calc.porcentaje_germinacion, 0)} />
                  <Info label="Bandejas" value={`${s.numero_bandejas}`} />
                  <Info label="Semillas" value={`${s.cantidad_semillas}`} />
                  <Info label="Proveedor" value={s.proveedor || '—'} />
                  <Info label="Costo" value={s.costo ? `${s.costo.toFixed(2)}` : '—'} />
                  <Info label="Germinación esp." value={fmtPct(s.porcentaje_esperado_germinacion ?? 85, 0)} />
                  <Info label="Trasplante" value={fmtDate(calc.fecha_trasplante_estimada)} />
                  <Info label="Restantes" value={calc.dias_restantes_trasplante < 0 ? `${Math.abs(calc.dias_restantes_trasplante)}d atraso` : `${calc.dias_restantes_trasplante} días`} accent={calc.dias_restantes_trasplante < 0 ? 'red' : 'default'} />
                </div>
                <div className="mt-3 p-2.5 rounded-xl bg-slate-50 text-sm text-slate-600 flex items-center gap-2">
                  <Calendar size={16} className="text-brand-600" />
                  <span>{calc.proxima_actividad}</span>
                </div>
                {s.observaciones && <p className="text-xs text-slate-400 mt-2 italic">{s.observaciones}</p>}
                <div className="flex gap-2 mt-3">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(s)}><Pencil size={14} /> Editar</Button>
                  <Button variant="ghost" size="sm" onClick={() => del(s.id)} className="text-red-600"><Trash2 size={14} /></Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Semillero' : 'Nuevo Semillero'} size="lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Cultivo">
            <select className={inputClass} value={form.cultivo_id || ''} onChange={e => setForm({ ...form, cultivo_id: e.target.value })}>
              <option value="">— Seleccionar —</option>
              {cultivos.map(c => <option key={c.id} value={c.id}>{c.nombre}</option>)}
            </select>
          </Field>
          <Field label="Variedad"><input className={inputClass} value={form.variedad || ''} onChange={e => setForm({ ...form, variedad: e.target.value })} /></Field>
          <Field label="Fecha de siembra" required><input type="date" className={inputClass} value={form.fecha_siembra || ''} onChange={e => setForm({ ...form, fecha_siembra: e.target.value })} /></Field>
          <Field label="Días para trasplante"><input type="number" className={inputClass} value={form.dias_para_trasplante ?? 35} onChange={e => setForm({ ...form, dias_para_trasplante: +e.target.value })} /></Field>
          <Field label="Cantidad de semillas"><input type="number" className={inputClass} value={form.cantidad_semillas ?? 0} onChange={e => setForm({ ...form, cantidad_semillas: +e.target.value })} /></Field>
          <Field label="Semillas germinadas"><input type="number" className={inputClass} value={form.semillas_germinadas ?? 0} onChange={e => setForm({ ...form, semillas_germinadas: +e.target.value })} /></Field>
          <Field label="Número de bandejas"><input type="number" className={inputClass} value={form.numero_bandejas ?? 0} onChange={e => setForm({ ...form, numero_bandejas: +e.target.value })} /></Field>
          <Field label="Sustrato"><input className={inputClass} value={form.sustrato || ''} onChange={e => setForm({ ...form, sustrato: e.target.value })} /></Field>
          <Field label="Proveedor"><input className={inputClass} value={form.proveedor || ''} onChange={e => setForm({ ...form, proveedor: e.target.value })} /></Field>
          <Field label="Costo"><input type="number" step="0.01" className={inputClass} value={form.costo ?? 0} onChange={e => setForm({ ...form, costo: +e.target.value })} /></Field>
          <Field label="% germinación esperada"><input type="number" className={inputClass} value={form.porcentaje_esperado_germinacion ?? 85} onChange={e => setForm({ ...form, porcentaje_esperado_germinacion: +e.target.value })} /></Field>
          <Field label="Estado">
            <select className={inputClass} value={form.estado || 'siembra'} onChange={e => setForm({ ...form, estado: e.target.value })}>
              <option value="siembra">Siembra</option><option value="germinacion">Germinación</option><option value="crecimiento">Crecimiento</option><option value="listo">Listo</option><option value="trasplantado">Trasplantado</option>
            </select>
          </Field>
          <div className="sm:col-span-2"><Field label="Observaciones"><textarea className={inputClass} rows={2} value={form.observaciones || ''} onChange={e => setForm({ ...form, observaciones: e.target.value })} /></Field></div>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}

function Info({ label, value, accent }: { label: string; value: string; accent?: 'red' | 'default' }) {
  return (
    <div>
      <p className="text-xs text-slate-400">{label}</p>
      <p className={`font-semibold ${accent === 'red' ? 'text-red-600' : 'text-slate-800'}`}>{value}</p>
    </div>
  );
}
