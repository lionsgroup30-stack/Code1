import { useState } from 'react';
import { Plus, Pencil, Trash2, FlaskConical } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { fmtMoney, fmtNum, fmtDate, todayISO } from '../lib/format';
import { Button, Modal, Field, inputClass, Table, Th, Td, PageHeader, EmptyState, Card } from '../components/ui';
import type { Fertilizacion } from '../lib/types';

const empty = (parcelaId = ''): Partial<Fertilizacion> => ({
  parcela_id: parcelaId, fecha: todayISO(), producto: '', cantidad: 0, unidad: 'lb', costo: 0, trabajador_id: '', fecha_proxima_aplicacion: '', observaciones: '',
});

export function FertilizacionPage() {
  const { fertilizacion, parcelas, trabajadores, config } = useData();
  const crud = useCrud<Fertilizacion>('fertilizacion');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Fertilizacion | null>(null);
  const [form, setForm] = useState<Partial<Fertilizacion>>(empty());

  const moneda = config?.moneda || 'RD$';

  const openNew = () => { setEditing(null); setForm(empty(parcelas[0]?.id || '')); setModal(true); };
  const openEdit = (f: Fertilizacion) => { setEditing(f); setForm(f); setModal(true); };
  const save = async () => {
    const payload = { ...form, parcela_id: form.parcela_id || null, trabajador_id: form.trabajador_id || null, fecha_proxima_aplicacion: form.fecha_proxima_aplicacion || null };
    if (editing) await crud.update(editing.id, payload); else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => { if (confirm('¿Eliminar registro de fertilización?')) await crud.remove(id); };

  const thisMonth = todayISO().slice(0, 7);
  const costoMes = fertilizacion.filter(f => (f.fecha || '').slice(0, 7) === thisMonth).reduce((s, f) => s + (f.costo ?? 0), 0);

  return (
    <div>
      <PageHeader title="Fertilización" subtitle="Registro de fertilización por parcela" action={<Button onClick={openNew} disabled={parcelas.length === 0}><Plus size={18} /> Nueva Fertilización</Button>} />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <Card className="p-5">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">Costo este mes</p>
          <p className="text-2xl font-bold text-slate-900 mt-1 tabular-nums">{fmtMoney(costoMes, moneda)}</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">Aplicaciones registradas</p>
          <p className="text-2xl font-bold text-slate-900 mt-1 tabular-nums">{fertilizacion.length}</p>
        </Card>
      </div>

      {fertilizacion.length === 0 ? (
        <EmptyState icon={<FlaskConical size={32} />} title="Sin registros de fertilización" message={parcelas.length === 0 ? 'Primero crea una parcela.' : 'Registra las aplicaciones de fertilizantes por parcela.'} action={parcelas.length > 0 ? <Button onClick={openNew}><Plus size={18} /> Registrar fertilización</Button> : undefined} />
      ) : (
        <Card className="p-0">
          <Table>
            <thead><tr>
              <Th>Fecha</Th><Th>Parcela</Th><Th>Producto</Th>
              <Th className="text-right">Cantidad</Th><Th className="text-right">Costo</Th>
              <Th>Responsable</Th><Th>Próxima</Th><Th></Th>
            </tr></thead>
            <tbody>
              {fertilizacion.map(f => (
                <tr key={f.id} className="border-t border-slate-50 hover:bg-slate-50/50">
                  <Td>{fmtDate(f.fecha)}</Td>
                  <Td className="font-medium">{f.parcelas?.nombre || '—'}</Td>
                  <Td>{f.producto || '—'}</Td>
                  <Td className="text-right tabular-nums">{fmtNum(f.cantidad, 2)} {f.unidad}</Td>
                  <Td className="text-right tabular-nums font-bold">{fmtMoney(f.costo, moneda)}</Td>
                  <Td className="text-slate-500">{f.trabajadores?.nombre || '—'}</Td>
                  <Td className="text-slate-500">{f.fecha_proxima_aplicacion ? fmtDate(f.fecha_proxima_aplicacion) : '—'}</Td>
                  <Td>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" onClick={() => openEdit(f)}><Pencil size={14} /></Button>
                      <Button variant="ghost" size="sm" onClick={() => del(f.id)} className="text-red-600"><Trash2 size={14} /></Button>
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Fertilización' : 'Nueva Fertilización'}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Parcela" required>
            <select className={inputClass} value={form.parcela_id || ''} onChange={e => setForm({ ...form, parcela_id: e.target.value })}>
              {parcelas.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
            </select>
          </Field>
          <Field label="Fecha" required><input type="date" className={inputClass} value={form.fecha || ''} onChange={e => setForm({ ...form, fecha: e.target.value })} /></Field>
          <Field label="Producto" required><input className={inputClass} value={form.producto || ''} onChange={e => setForm({ ...form, producto: e.target.value })} /></Field>
          <Field label="Cantidad" required><input type="number" step="0.01" className={inputClass} value={form.cantidad ?? 0} onChange={e => setForm({ ...form, cantidad: +e.target.value })} /></Field>
          <Field label="Unidad"><input className={inputClass} value={form.unidad || 'lb'} onChange={e => setForm({ ...form, unidad: e.target.value })} /></Field>
          <Field label="Costo"><input type="number" step="0.01" className={inputClass} value={form.costo ?? 0} onChange={e => setForm({ ...form, costo: +e.target.value })} /></Field>
          <Field label="Responsable">
            <select className={inputClass} value={form.trabajador_id || ''} onChange={e => setForm({ ...form, trabajador_id: e.target.value })}>
              <option value="">— Ninguno —</option>
              {trabajadores.map(t => <option key={t.id} value={t.id}>{t.nombre}</option>)}
            </select>
          </Field>
          <Field label="Próxima aplicación"><input type="date" className={inputClass} value={form.fecha_proxima_aplicacion || ''} onChange={e => setForm({ ...form, fecha_proxima_aplicacion: e.target.value })} /></Field>
          <div className="sm:col-span-2"><Field label="Observaciones"><textarea className={inputClass} rows={2} value={form.observaciones || ''} onChange={e => setForm({ ...form, observaciones: e.target.value })} /></Field></div>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}
