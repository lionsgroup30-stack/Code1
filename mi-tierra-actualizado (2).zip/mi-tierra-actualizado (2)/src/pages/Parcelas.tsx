import { useState } from 'react';
import { Plus, Pencil, Trash2, Trees, MapPin, Ruler } from 'lucide-react';
import { useData } from '../lib/DataContext';
import { useCrud } from '../lib/useCrud';
import { calcProduccion, parcelaProduccionEsperada, parcelaProduccionReal, calcCostosParcela, calcSemaforoCostos, parcelaTotalPlantas } from '../lib/calculations';
import { fmtMoney, fmtNum, fmtPct, fmtDate } from '../lib/format';
import { Button, Modal, Field, inputClass, PageHeader, EmptyState, Semaforo, Badge, Card } from '../components/ui';
import type { Parcela } from '../lib/types';

const empty = (): Partial<Parcela> => ({
  nombre: '', ubicacion: '', area_tareas: 0, area_m2: 0, cultivo_id: '',
  fecha_siembra: '', estado: 'preparacion', produccion_esperada_total: 0, precio_esperado_libra: 0,
});

export function ParcelasPage() {
  const { parcelas, cultivos, filas, cosechas, gastos, config } = useData();
  const crud = useCrud<Parcela>('parcelas');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Parcela | null>(null);
  const [form, setForm] = useState<Partial<Parcela>>(empty());

  const openNew = () => { setEditing(null); setForm(empty()); setModal(true); };
  const openEdit = (p: Parcela) => { setEditing(p); setForm(p); setModal(true); };
  const save = async () => {
    const payload = { ...form, cultivo_id: form.cultivo_id || null, fecha_siembra: form.fecha_siembra || null };
    if (editing) await crud.update(editing.id, payload); else await crud.insert(payload);
    setModal(false);
  };
  const del = async (id: string) => { if (confirm('¿Eliminar parcela? Se eliminarán también sus filas y cosechas.')) await crud.remove(id); };

  const moneda = config?.moneda || 'RD$';

  return (
    <div>
      <PageHeader title="Parcelas (Lotes)" subtitle="Lotes de cultivo con análisis automático de producción y costos" action={<Button onClick={openNew}><Plus size={18} /> Nueva Parcela</Button>} />
      {parcelas.length === 0 ? (
        <EmptyState icon={<Trees size={32} />} title="Sin parcelas" message="Registra tus lotes de cultivo para empezar el análisis automático." action={<Button onClick={openNew}><Plus size={18} /> Crear parcela</Button>} />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {parcelas.map(p => {
            const cultivo = cultivos.find(c => c.id === p.cultivo_id);
            const esperada = parcelaProduccionEsperada(p, filas);
            const real = parcelaProduccionReal(p, cosechas);
            const precio = p.precio_esperado_libra || cultivo?.costo_esperado_por_libra || 0;
            const prod = calcProduccion(esperada, real, precio);
            const costos = calcCostosParcela(p, gastos, filas, cosechas);
            const semCosto = calcSemaforoCostos(cultivo, costos, config?.porcentaje_alerta_costo ?? 15);
            const plantas = parcelaTotalPlantas(p, filas);
            const numFilas = filas.filter(f => f.parcela_id === p.id).length;
            return (
              <Card key={p.id} className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <Trees className="text-brand-600" size={20} />
                      <h3 className="font-bold text-slate-800">{p.nombre}</h3>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                      {cultivo && <Badge color="green">{cultivo.nombre}</Badge>}
                      {p.ubicacion && <span className="flex items-center gap-1"><MapPin size={12} />{p.ubicacion}</span>}
                      <span className="flex items-center gap-1"><Ruler size={12} />{fmtNum(p.area_tareas, 1)} tareas</span>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm" onClick={() => openEdit(p)}><Pencil size={14} /></Button>
                    <Button variant="ghost" size="sm" onClick={() => del(p.id)} className="text-red-600"><Trash2 size={14} /></Button>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 mb-4">
                  <Info label="Filas" value={`${numFilas}`} />
                  <Info label="Plantas" value={`${plantas}`} />
                  <Info label="Siembra" value={p.fecha_siembra ? fmtDate(p.fecha_siembra) : '—'} />
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50">
                    <div>
                      <p className="text-xs text-slate-400 font-medium">Producción (esperada vs real)</p>
                      <p className="text-sm font-semibold text-slate-700">{fmtNum(real)} / {fmtNum(esperada)} lb · {fmtPct(prod.cumplimiento, 0)}</p>
                    </div>
                    <Semaforo estado={prod.semaforo} label={prod.estado_texto} size="sm" />
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50">
                    <div>
                      <p className="text-xs text-slate-400 font-medium">Costos (real vs esperado/libra)</p>
                      <p className="text-sm font-semibold text-slate-700">{fmtMoney(costos.costo_por_libra, moneda)} / {fmtMoney(semCosto.costo_esperado_libra, moneda)}</p>
                    </div>
                    <Semaforo estado={semCosto.estado} label={semCosto.alerta ? 'Alerta' : 'OK'} size="sm" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-2.5 rounded-xl bg-slate-50">
                      <p className="text-xs text-slate-400">Costo total</p>
                      <p className="text-sm font-bold text-slate-800">{fmtMoney(costos.costo_total, moneda)}</p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-slate-50">
                      <p className="text-xs text-slate-400">Costo/planta</p>
                      <p className="text-sm font-bold text-slate-800">{fmtMoney(costos.costo_por_planta, moneda)}</p>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Editar Parcela' : 'Nueva Parcela'} size="lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Nombre" required><input className={inputClass} value={form.nombre || ''} onChange={e => setForm({ ...form, nombre: e.target.value })} /></Field>
          <Field label="Ubicación"><input className={inputClass} value={form.ubicacion || ''} onChange={e => setForm({ ...form, ubicacion: e.target.value })} /></Field>
          <Field label="Cultivo">
            <select className={inputClass} value={form.cultivo_id || ''} onChange={e => setForm({ ...form, cultivo_id: e.target.value })}>
              <option value="">— Seleccionar —</option>
              {cultivos.map(c => <option key={c.id} value={c.id}>{c.nombre}</option>)}
            </select>
          </Field>
          <Field label="Estado">
            <select className={inputClass} value={form.estado || 'preparacion'} onChange={e => setForm({ ...form, estado: e.target.value })}>
              <option value="preparacion">Preparación</option><option value="siembra">Siembra</option><option value="crecimiento">Crecimiento</option><option value="produccion">Producción</option><option value="cosecha">Cosecha</option><option value="inactivo">Inactivo</option>
            </select>
          </Field>
          <Field label="Área (tareas)"><input type="number" step="0.01" className={inputClass} value={form.area_tareas ?? 0} onChange={e => setForm({ ...form, area_tareas: +e.target.value })} /></Field>
          <Field label="Área (m²)"><input type="number" step="0.01" className={inputClass} value={form.area_m2 ?? 0} onChange={e => setForm({ ...form, area_m2: +e.target.value })} /></Field>
          <Field label="Fecha de siembra"><input type="date" className={inputClass} value={form.fecha_siembra || ''} onChange={e => setForm({ ...form, fecha_siembra: e.target.value })} /></Field>
          <Field label="Prod. esperada total (lb)"><input type="number" step="0.01" className={inputClass} value={form.produccion_esperada_total ?? 0} onChange={e => setForm({ ...form, produccion_esperada_total: +e.target.value })} /></Field>
          <Field label="Precio esperado/libra"><input type="number" step="0.01" className={inputClass} value={form.precio_esperado_libra ?? 0} onChange={e => setForm({ ...form, precio_esperado_libra: +e.target.value })} /></Field>
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <Button variant="secondary" onClick={() => setModal(false)}>Cancelar</Button>
          <Button onClick={save} disabled={crud.saving}>{editing ? 'Guardar' : 'Crear'}</Button>
        </div>
      </Modal>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return <div><p className="text-xs text-slate-400">{label}</p><p className="font-semibold text-slate-800 text-sm">{value}</p></div>;
}
