/*
# TerraIQ Enterprise V2.0 — Schema Expansion

1. New Tables (in dependency order)
- `trabajadores` — workers with daily wage, role, active status
- `lotes` — subdivisions of parcelas (parcela → lote → fila)
- `trasplantes` — transplant events linking semilleros to parcelas/lotes/filas
- `compras` — purchase records with supplier + optional inventory link
- `metas` — goal planning with target, current, deadline, progress tracking

2. Modified Tables (additive only, no data loss)
- `semilleros`: add proveedor, costo, porcentaje_esperado_germinacion
- `inventario`: add fecha_vencimiento (for insumos por vencer alerts)
- `filas`: add lote_id (nullable FK to lotes, backward compatible)
- `gastos`: add trabajador_id, subcategoria
- `cosechas`: add trabajador_id

3. Security
- RLS enabled on all new tables with anon+authenticated CRUD policies
*/

-- ============ TRABAJADORES ============
CREATE TABLE IF NOT EXISTS trabajadores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  rol text DEFAULT 'jornalero',
  telefono text,
  jornal_diario numeric(12,2) NOT NULL DEFAULT 0,
  activo boolean NOT NULL DEFAULT true,
  fecha_ingreso date DEFAULT CURRENT_DATE,
  observaciones text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE trabajadores ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_trabajadores" ON trabajadores;
CREATE POLICY "anon_all_trabajadores" ON trabajadores FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_trabajadores" ON trabajadores;
CREATE POLICY "anon_ins_trabajadores" ON trabajadores FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_trabajadores" ON trabajadores;
CREATE POLICY "anon_upd_trabajadores" ON trabajadores FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_trabajadores" ON trabajadores;
CREATE POLICY "anon_del_trabajadores" ON trabajadores FOR DELETE TO anon, authenticated USING (true);

-- ============ LOTES ============
CREATE TABLE IF NOT EXISTS lotes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parcela_id uuid NOT NULL REFERENCES parcelas(id) ON DELETE CASCADE,
  nombre text NOT NULL,
  area_tareas numeric(10,2) DEFAULT 0,
  estado text NOT NULL DEFAULT 'activo',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE lotes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_lotes" ON lotes;
CREATE POLICY "anon_all_lotes" ON lotes FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_lotes" ON lotes;
CREATE POLICY "anon_ins_lotes" ON lotes FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_lotes" ON lotes;
CREATE POLICY "anon_upd_lotes" ON lotes FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_lotes" ON lotes;
CREATE POLICY "anon_del_lotes" ON lotes FOR DELETE TO anon, authenticated USING (true);

-- ============ TRASPLANTES ============
CREATE TABLE IF NOT EXISTS trasplantes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  semillero_id uuid REFERENCES semilleros(id) ON DELETE SET NULL,
  parcela_id uuid NOT NULL REFERENCES parcelas(id) ON DELETE CASCADE,
  lote_id uuid REFERENCES lotes(id) ON DELETE SET NULL,
  fila_id uuid REFERENCES filas(id) ON DELETE SET NULL,
  fecha date NOT NULL DEFAULT CURRENT_DATE,
  cantidad_plantas int NOT NULL DEFAULT 0,
  trabajador_id uuid REFERENCES trabajadores(id) ON DELETE SET NULL,
  observaciones text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE trasplantes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_trasplantes" ON trasplantes;
CREATE POLICY "anon_all_trasplantes" ON trasplantes FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_trasplantes" ON trasplantes;
CREATE POLICY "anon_ins_trasplantes" ON trasplantes FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_trasplantes" ON trasplantes;
CREATE POLICY "anon_upd_trasplantes" ON trasplantes FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_trasplantes" ON trasplantes;
CREATE POLICY "anon_del_trasplantes" ON trasplantes FOR DELETE TO anon, authenticated USING (true);

-- ============ COMPRAS ============
CREATE TABLE IF NOT EXISTS compras (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  proveedor text,
  fecha date NOT NULL DEFAULT CURRENT_DATE,
  descripcion text,
  monto_total numeric(12,2) NOT NULL DEFAULT 0,
  metodo_pago text DEFAULT 'efectivo',
  inventario_item_id uuid REFERENCES inventario(id) ON DELETE SET NULL,
  cantidad numeric(12,2) DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE compras ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_compras" ON compras;
CREATE POLICY "anon_all_compras" ON compras FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_compras" ON compras;
CREATE POLICY "anon_ins_compras" ON compras FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_compras" ON compras;
CREATE POLICY "anon_upd_compras" ON compras FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_compras" ON compras;
CREATE POLICY "anon_del_compras" ON compras FOR DELETE TO anon, authenticated USING (true);

-- ============ METAS ============
CREATE TABLE IF NOT EXISTS metas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  titulo text NOT NULL,
  descripcion text,
  tipo text NOT NULL DEFAULT 'produccion',
  valor_objetivo numeric(14,2) NOT NULL DEFAULT 0,
  valor_actual numeric(14,2) NOT NULL DEFAULT 0,
  unidad text NOT NULL DEFAULT 'lb',
  fecha_limite date,
  estado text NOT NULL DEFAULT 'activa',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE metas ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_metas" ON metas;
CREATE POLICY "anon_all_metas" ON metas FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_metas" ON metas;
CREATE POLICY "anon_ins_metas" ON metas FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_metas" ON metas;
CREATE POLICY "anon_upd_metas" ON metas FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_metas" ON metas;
CREATE POLICY "anon_del_metas" ON metas FOR DELETE TO anon, authenticated USING (true);

-- ============ ALTER EXISTING TABLES (additive) ============
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'semilleros' AND column_name = 'proveedor') THEN
    ALTER TABLE semilleros ADD COLUMN proveedor text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'semilleros' AND column_name = 'costo') THEN
    ALTER TABLE semilleros ADD COLUMN costo numeric(12,2) DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'semilleros' AND column_name = 'porcentaje_esperado_germinacion') THEN
    ALTER TABLE semilleros ADD COLUMN porcentaje_esperado_germinacion numeric(5,2) DEFAULT 85;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'inventario' AND column_name = 'fecha_vencimiento') THEN
    ALTER TABLE inventario ADD COLUMN fecha_vencimiento date;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'filas' AND column_name = 'lote_id') THEN
    ALTER TABLE filas ADD COLUMN lote_id uuid REFERENCES lotes(id) ON DELETE SET NULL;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'gastos' AND column_name = 'trabajador_id') THEN
    ALTER TABLE gastos ADD COLUMN trabajador_id uuid REFERENCES trabajadores(id) ON DELETE SET NULL;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'gastos' AND column_name = 'subcategoria') THEN
    ALTER TABLE gastos ADD COLUMN subcategoria text;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'cosechas' AND column_name = 'trabajador_id') THEN
    ALTER TABLE cosechas ADD COLUMN trabajador_id uuid REFERENCES trabajadores(id) ON DELETE SET NULL;
  END IF;
END $$;

-- ============ ÍNDICES ============
CREATE INDEX IF NOT EXISTS idx_lotes_parcela ON lotes(parcela_id);
CREATE INDEX IF NOT EXISTS idx_trasplantes_parcela ON trasplantes(parcela_id);
CREATE INDEX IF NOT EXISTS idx_trasplantes_semillero ON trasplantes(semillero_id);
CREATE INDEX IF NOT EXISTS idx_compras_fecha ON compras(fecha);
CREATE INDEX IF NOT EXISTS idx_gastos_trabajador ON gastos(trabajador_id);
CREATE INDEX IF NOT EXISTS idx_cosechas_trabajador ON cosechas(trabajador_id);
CREATE INDEX IF NOT EXISTS idx_inventario_vencimiento ON inventario(fecha_vencimiento);
