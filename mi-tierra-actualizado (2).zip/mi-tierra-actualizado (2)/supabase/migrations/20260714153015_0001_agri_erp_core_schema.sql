/*
# ERP Agrícola Inteligente — Esquema Normalizado Core

Construye la base de datos normalizada para un ERP agrícola de un solo tenant
(sin pantalla de login solicitada). El diseño soporta multi-cultivo desde ahora
y queda preparado para multi-finca/multi-usuario futuro sin reescritura:
las parcelas cuelgan directamente del tenant y añadir una tabla "fincas"
+ columna finca_id más adelante es un cambio puramente aditivo.

## Tablas nuevas (en orden de dependencias)
1. cultivos — catálogo de cultivos/variedades con metas de producción y costo.
2. mercados — mercados con costo de transporte para comparar rentabilidad.
3. clientes — clientes con historial, crédito y ranking.
4. vehiculos — vehículos de transporte.
5. bancos — cuentas bancarias.
6. parcelas — lotes/parcelas, cada uno asociado a un cultivo.
7. filas — filas dentro de una parcela, con plantas y metas.
8. semilleros — bandejas de semillero con cálculos automáticos.
9. cosechas — eventos de cosecha (libras reales) por parcela/fila.
10. riego — registros de riego.
11. fertilizacion — registros de fertilización.
12. plagas — registros de control de plagas.
13. inventario — items de inventario con stock mínimo (alertas).
14. herramientas — herramientas/equipos registrados.
15. viajes — viajes de transporte con costos por saco/libra.
16. gastos — gastos clasificados por categoría, afectan costos del cultivo.
17. ventas — ventas con cliente, mercado, estado de pago.
18. transacciones_bancarias — movimientos de banco.
19. prestamos — préstamos con cuotas y saldo.
20. pagos_prestamos — pagos a préstamos (capital/interés).
21. cacao_lotes — procesamiento de cacao (fermentación, secado).
22. configuracion — configuración global singleton.

## Seguridad
- RLS habilitado en TODAS las tablas.
- Sin login solicitado: políticas TO anon, authenticated con USING (true) / WITH CHECK (true)
  porque los datos son intencionalmente compartidos en este tenant único.
*/

-- ============ CULTIVOS ============
CREATE TABLE IF NOT EXISTS cultivos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  variedad text,
  dias_germinacion int NOT NULL DEFAULT 7,
  dias_trasplante int NOT NULL DEFAULT 35,
  produccion_esperada_por_planta numeric(10,2) NOT NULL DEFAULT 0,
  costo_esperado_por_planta numeric(12,2) NOT NULL DEFAULT 0,
  costo_esperado_por_libra numeric(12,2) NOT NULL DEFAULT 0,
  margen_objetivo numeric(5,2) NOT NULL DEFAULT 30,
  color text DEFAULT '#10b981',
  activo boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE cultivos ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_cultivos" ON cultivos;
CREATE POLICY "anon_all_cultivos" ON cultivos FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_cultivos" ON cultivos;
CREATE POLICY "anon_ins_cultivos" ON cultivos FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_cultivos" ON cultivos;
CREATE POLICY "anon_upd_cultivos" ON cultivos FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_cultivos" ON cultivos;
CREATE POLICY "anon_del_cultivos" ON cultivos FOR DELETE TO anon, authenticated USING (true);

-- ============ MERCADOS ============
CREATE TABLE IF NOT EXISTS mercados (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  ubicacion text,
  costo_transporte numeric(12,2) DEFAULT 0,
  precio_referencia_libra numeric(10,2) DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE mercados ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_mercados" ON mercados;
CREATE POLICY "anon_all_mercados" ON mercados FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_mercados" ON mercados;
CREATE POLICY "anon_ins_mercados" ON mercados FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_mercados" ON mercados;
CREATE POLICY "anon_upd_mercados" ON mercados FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_mercados" ON mercados;
CREATE POLICY "anon_del_mercados" ON mercados FOR DELETE TO anon, authenticated USING (true);

-- ============ CLIENTES ============
CREATE TABLE IF NOT EXISTS clientes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  telefono text,
  email text,
  direccion text,
  credito_limite numeric(12,2) DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_clientes" ON clientes;
CREATE POLICY "anon_all_clientes" ON clientes FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_clientes" ON clientes;
CREATE POLICY "anon_ins_clientes" ON clientes FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_clientes" ON clientes;
CREATE POLICY "anon_upd_clientes" ON clientes FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_clientes" ON clientes;
CREATE POLICY "anon_del_clientes" ON clientes FOR DELETE TO anon, authenticated USING (true);

-- ============ VEHICULOS ============
CREATE TABLE IF NOT EXISTS vehiculos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  modelo text,
  placa text,
  kilometraje numeric(12,2) DEFAULT 0,
  fecha_mantenimiento date,
  costo_mantenimiento numeric(12,2) DEFAULT 0,
  observaciones text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE vehiculos ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_vehiculos" ON vehiculos;
CREATE POLICY "anon_all_vehiculos" ON vehiculos FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_vehiculos" ON vehiculos;
CREATE POLICY "anon_ins_vehiculos" ON vehiculos FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_vehiculos" ON vehiculos;
CREATE POLICY "anon_upd_vehiculos" ON vehiculos FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_vehiculos" ON vehiculos;
CREATE POLICY "anon_del_vehiculos" ON vehiculos FOR DELETE TO anon, authenticated USING (true);

-- ============ BANCOS ============
CREATE TABLE IF NOT EXISTS bancos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  tipo text DEFAULT 'cuenta',
  saldo_inicial numeric(14,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE bancos ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_bancos" ON bancos;
CREATE POLICY "anon_all_bancos" ON bancos FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_bancos" ON bancos;
CREATE POLICY "anon_ins_bancos" ON bancos FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_bancos" ON bancos;
CREATE POLICY "anon_upd_bancos" ON bancos FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_bancos" ON bancos;
CREATE POLICY "anon_del_bancos" ON bancos FOR DELETE TO anon, authenticated USING (true);

-- ============ PARCELAS (LOTES) ============
CREATE TABLE IF NOT EXISTS parcelas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  ubicacion text,
  area_tareas numeric(10,2) DEFAULT 0,
  area_m2 numeric(12,2) DEFAULT 0,
  cultivo_id uuid REFERENCES cultivos(id) ON DELETE SET NULL,
  fecha_siembra date,
  estado text NOT NULL DEFAULT 'preparacion',
  produccion_esperada_total numeric(12,2) DEFAULT 0,
  precio_esperado_libra numeric(10,2) DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE parcelas ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_parcelas" ON parcelas;
CREATE POLICY "anon_all_parcelas" ON parcelas FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_parcelas" ON parcelas;
CREATE POLICY "anon_ins_parcelas" ON parcelas FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_parcelas" ON parcelas;
CREATE POLICY "anon_upd_parcelas" ON parcelas FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_parcelas" ON parcelas;
CREATE POLICY "anon_del_parcelas" ON parcelas FOR DELETE TO anon, authenticated USING (true);

-- ============ FILAS ============
CREATE TABLE IF NOT EXISTS filas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parcela_id uuid NOT NULL REFERENCES parcelas(id) ON DELETE CASCADE,
  numero int NOT NULL DEFAULT 1,
  etiqueta text,
  cantidad_plantas int NOT NULL DEFAULT 0,
  fecha_trasplante date,
  estado text NOT NULL DEFAULT 'activa',
  produccion_esperada_por_planta numeric(10,2) DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE filas ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_filas" ON filas;
CREATE POLICY "anon_all_filas" ON filas FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_filas" ON filas;
CREATE POLICY "anon_ins_filas" ON filas FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_filas" ON filas;
CREATE POLICY "anon_upd_filas" ON filas FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_filas" ON filas;
CREATE POLICY "anon_del_filas" ON filas FOR DELETE TO anon, authenticated USING (true);

-- ============ SEMILLEROS ============
CREATE TABLE IF NOT EXISTS semilleros (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cultivo_id uuid REFERENCES cultivos(id) ON DELETE SET NULL,
  fecha_siembra date NOT NULL DEFAULT CURRENT_DATE,
  cantidad_semillas int NOT NULL DEFAULT 0,
  variedad text,
  numero_bandejas int NOT NULL DEFAULT 0,
  sustrato text,
  semillas_germinadas int NOT NULL DEFAULT 0,
  dias_para_trasplante int NOT NULL DEFAULT 35,
  observaciones text,
  estado text NOT NULL DEFAULT 'siembra',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE semilleros ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_semilleros" ON semilleros;
CREATE POLICY "anon_all_semilleros" ON semilleros FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_semilleros" ON semilleros;
CREATE POLICY "anon_ins_semilleros" ON semilleros FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_semilleros" ON semilleros;
CREATE POLICY "anon_upd_semilleros" ON semilleros FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_semilleros" ON semilleros;
CREATE POLICY "anon_del_semilleros" ON semilleros FOR DELETE TO anon, authenticated USING (true);

-- ============ COSECHAS (PRODUCCIÓN REAL) ============
CREATE TABLE IF NOT EXISTS cosechas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parcela_id uuid NOT NULL REFERENCES parcelas(id) ON DELETE CASCADE,
  fila_id uuid REFERENCES filas(id) ON DELETE SET NULL,
  fecha date NOT NULL DEFAULT CURRENT_DATE,
  cantidad_libras numeric(12,2) NOT NULL DEFAULT 0,
  precio_por_libra numeric(10,2) NOT NULL DEFAULT 0,
  mercado_id uuid REFERENCES mercados(id) ON DELETE SET NULL,
  observaciones text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE cosechas ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_cosechas" ON cosechas;
CREATE POLICY "anon_all_cosechas" ON cosechas FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_cosechas" ON cosechas;
CREATE POLICY "anon_ins_cosechas" ON cosechas FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_cosechas" ON cosechas;
CREATE POLICY "anon_upd_cosechas" ON cosechas FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_cosechas" ON cosechas;
CREATE POLICY "anon_del_cosechas" ON cosechas FOR DELETE TO anon, authenticated USING (true);

-- ============ RIEGO ============
CREATE TABLE IF NOT EXISTS riego (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parcela_id uuid REFERENCES parcelas(id) ON DELETE CASCADE,
  fila_id uuid REFERENCES filas(id) ON DELETE SET NULL,
  fecha date NOT NULL DEFAULT CURRENT_DATE,
  cantidad_litros numeric(12,2) DEFAULT 0,
  duracion_min int DEFAULT 0,
  observaciones text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE riego ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_riego" ON riego;
CREATE POLICY "anon_all_riego" ON riego FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_riego" ON riego;
CREATE POLICY "anon_ins_riego" ON riego FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_riego" ON riego;
CREATE POLICY "anon_upd_riego" ON riego FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_riego" ON riego;
CREATE POLICY "anon_del_riego" ON riego FOR DELETE TO anon, authenticated USING (true);

-- ============ FERTILIZACION ============
CREATE TABLE IF NOT EXISTS fertilizacion (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parcela_id uuid REFERENCES parcelas(id) ON DELETE CASCADE,
  fila_id uuid REFERENCES filas(id) ON DELETE SET NULL,
  fecha date NOT NULL DEFAULT CURRENT_DATE,
  producto text NOT NULL,
  cantidad numeric(10,2) DEFAULT 0,
  unidad text DEFAULT 'lb',
  costo numeric(12,2) DEFAULT 0,
  observaciones text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE fertilizacion ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_fertilizacion" ON fertilizacion;
CREATE POLICY "anon_all_fertilizacion" ON fertilizacion FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_fertilizacion" ON fertilizacion;
CREATE POLICY "anon_ins_fertilizacion" ON fertilizacion FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_fertilizacion" ON fertilizacion;
CREATE POLICY "anon_upd_fertilizacion" ON fertilizacion FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_fertilizacion" ON fertilizacion;
CREATE POLICY "anon_del_fertilizacion" ON fertilizacion FOR DELETE TO anon, authenticated USING (true);

-- ============ PLAGAS ============
CREATE TABLE IF NOT EXISTS plagas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parcela_id uuid REFERENCES parcelas(id) ON DELETE CASCADE,
  fila_id uuid REFERENCES filas(id) ON DELETE SET NULL,
  fecha date NOT NULL DEFAULT CURRENT_DATE,
  tipo_plaga text NOT NULL,
  producto text,
  cantidad numeric(10,2) DEFAULT 0,
  unidad text DEFAULT 'ml',
  costo numeric(12,2) DEFAULT 0,
  severidad text DEFAULT 'baja',
  observaciones text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE plagas ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_plagas" ON plagas;
CREATE POLICY "anon_all_plagas" ON plagas FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_plagas" ON plagas;
CREATE POLICY "anon_ins_plagas" ON plagas FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_plagas" ON plagas;
CREATE POLICY "anon_upd_plagas" ON plagas FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_plagas" ON plagas;
CREATE POLICY "anon_del_plagas" ON plagas FOR DELETE TO anon, authenticated USING (true);

-- ============ INVENTARIO ============
CREATE TABLE IF NOT EXISTS inventario (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  categoria text NOT NULL,
  unidad text NOT NULL DEFAULT 'unidad',
  stock_actual numeric(12,2) NOT NULL DEFAULT 0,
  stock_minimo numeric(12,2) NOT NULL DEFAULT 0,
  costo_unitario numeric(12,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE inventario ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_inventario" ON inventario;
CREATE POLICY "anon_all_inventario" ON inventario FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_inventario" ON inventario;
CREATE POLICY "anon_ins_inventario" ON inventario FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_inventario" ON inventario;
CREATE POLICY "anon_upd_inventario" ON inventario FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_inventario" ON inventario;
CREATE POLICY "anon_del_inventario" ON inventario FOR DELETE TO anon, authenticated USING (true);

-- ============ HERRAMIENTAS ============
CREATE TABLE IF NOT EXISTS herramientas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  tipo text,
  estado text NOT NULL DEFAULT 'bueno',
  fecha_compra date,
  costo numeric(12,2) DEFAULT 0,
  observaciones text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE herramientas ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_herramientas" ON herramientas;
CREATE POLICY "anon_all_herramientas" ON herramientas FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_herramientas" ON herramientas;
CREATE POLICY "anon_ins_herramientas" ON herramientas FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_herramientas" ON herramientas;
CREATE POLICY "anon_upd_herramientas" ON herramientas FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_herramientas" ON herramientas;
CREATE POLICY "anon_del_herramientas" ON herramientas FOR DELETE TO anon, authenticated USING (true);

-- ============ VIAJES (TRANSPORTE) ============
CREATE TABLE IF NOT EXISTS viajes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vehiculo_id uuid NOT NULL REFERENCES vehiculos(id) ON DELETE CASCADE,
  fecha date NOT NULL DEFAULT CURRENT_DATE,
  origen text,
  destino text,
  kilometros numeric(10,2) DEFAULT 0,
  combustible_litros numeric(10,2) DEFAULT 0,
  combustible_costo numeric(12,2) DEFAULT 0,
  sacos_transportados int DEFAULT 0,
  libras_transportadas numeric(12,2) DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE viajes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_viajes" ON viajes;
CREATE POLICY "anon_all_viajes" ON viajes FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_viajes" ON viajes;
CREATE POLICY "anon_ins_viajes" ON viajes FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_viajes" ON viajes;
CREATE POLICY "anon_upd_viajes" ON viajes FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_viajes" ON viajes;
CREATE POLICY "anon_del_viajes" ON viajes FOR DELETE TO anon, authenticated USING (true);

-- ============ GASTOS ============
CREATE TABLE IF NOT EXISTS gastos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  categoria text NOT NULL,
  descripcion text,
  monto numeric(12,2) NOT NULL DEFAULT 0,
  fecha date NOT NULL DEFAULT CURRENT_DATE,
  parcela_id uuid REFERENCES parcelas(id) ON DELETE SET NULL,
  fila_id uuid REFERENCES filas(id) ON DELETE SET NULL,
  cultivo_id uuid REFERENCES cultivos(id) ON DELETE SET NULL,
  vehiculo_id uuid REFERENCES vehiculos(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE gastos ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_gastos" ON gastos;
CREATE POLICY "anon_all_gastos" ON gastos FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_gastos" ON gastos;
CREATE POLICY "anon_ins_gastos" ON gastos FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_gastos" ON gastos;
CREATE POLICY "anon_upd_gastos" ON gastos FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_gastos" ON gastos;
CREATE POLICY "anon_del_gastos" ON gastos FOR DELETE TO anon, authenticated USING (true);

-- ============ VENTAS ============
CREATE TABLE IF NOT EXISTS ventas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cliente_id uuid REFERENCES clientes(id) ON DELETE SET NULL,
  mercado_id uuid REFERENCES mercados(id) ON DELETE SET NULL,
  parcela_id uuid REFERENCES parcelas(id) ON DELETE SET NULL,
  fecha date NOT NULL DEFAULT CURRENT_DATE,
  producto text,
  cantidad_libras numeric(12,2) NOT NULL DEFAULT 0,
  precio_por_libra numeric(10,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  metodo_pago text DEFAULT 'efectivo',
  estado_pago text NOT NULL DEFAULT 'pagado',
  fecha_pago date,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE ventas ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_ventas" ON ventas;
CREATE POLICY "anon_all_ventas" ON ventas FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_ventas" ON ventas;
CREATE POLICY "anon_ins_ventas" ON ventas FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_ventas" ON ventas;
CREATE POLICY "anon_upd_ventas" ON ventas FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_ventas" ON ventas;
CREATE POLICY "anon_del_ventas" ON ventas FOR DELETE TO anon, authenticated USING (true);

-- ============ TRANSACCIONES BANCARIAS ============
CREATE TABLE IF NOT EXISTS transacciones_bancarias (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  banco_id uuid NOT NULL REFERENCES bancos(id) ON DELETE CASCADE,
  tipo text NOT NULL DEFAULT 'ingreso',
  monto numeric(14,2) NOT NULL DEFAULT 0,
  fecha date NOT NULL DEFAULT CURRENT_DATE,
  descripcion text,
  venta_id uuid REFERENCES ventas(id) ON DELETE SET NULL,
  gasto_id uuid REFERENCES gastos(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE transacciones_bancarias ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_tbanc" ON transacciones_bancarias;
CREATE POLICY "anon_all_tbanc" ON transacciones_bancarias FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_tbanc" ON transacciones_bancarias;
CREATE POLICY "anon_ins_tbanc" ON transacciones_bancarias FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_tbanc" ON transacciones_bancarias;
CREATE POLICY "anon_upd_tbanc" ON transacciones_bancarias FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_tbanc" ON transacciones_bancarias;
CREATE POLICY "anon_del_tbanc" ON transacciones_bancarias FOR DELETE TO anon, authenticated USING (true);

-- ============ PRESTAMOS ============
CREATE TABLE IF NOT EXISTS prestamos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  monto_principal numeric(14,2) NOT NULL DEFAULT 0,
  tasa_interes numeric(6,2) NOT NULL DEFAULT 0,
  plazo_meses int NOT NULL DEFAULT 12,
  fecha_inicio date NOT NULL DEFAULT CURRENT_DATE,
  cuota_mensual numeric(12,2) NOT NULL DEFAULT 0,
  saldo_actual numeric(14,2) NOT NULL DEFAULT 0,
  descripcion text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE prestamos ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_prestamos" ON prestamos;
CREATE POLICY "anon_all_prestamos" ON prestamos FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_prestamos" ON prestamos;
CREATE POLICY "anon_ins_prestamos" ON prestamos FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_prestamos" ON prestamos;
CREATE POLICY "anon_upd_prestamos" ON prestamos FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_prestamos" ON prestamos;
CREATE POLICY "anon_del_prestamos" ON prestamos FOR DELETE TO anon, authenticated USING (true);

-- ============ PAGOS PRESTAMOS ============
CREATE TABLE IF NOT EXISTS pagos_prestamos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prestamo_id uuid NOT NULL REFERENCES prestamos(id) ON DELETE CASCADE,
  fecha date NOT NULL DEFAULT CURRENT_DATE,
  monto numeric(12,2) NOT NULL DEFAULT 0,
  tipo text NOT NULL DEFAULT 'capital',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE pagos_prestamos ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_pagos_prest" ON pagos_prestamos;
CREATE POLICY "anon_all_pagos_prest" ON pagos_prestamos FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_pagos_prest" ON pagos_prestamos;
CREATE POLICY "anon_ins_pagos_prest" ON pagos_prestamos FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_pagos_prest" ON pagos_prestamos;
CREATE POLICY "anon_upd_pagos_prest" ON pagos_prestamos FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_pagos_prest" ON pagos_prestamos;
CREATE POLICY "anon_del_pagos_prest" ON pagos_prestamos FOR DELETE TO anon, authenticated USING (true);

-- ============ CACAO (PROCESAMIENTO) ============
CREATE TABLE IF NOT EXISTS cacao_lotes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parcela_id uuid REFERENCES parcelas(id) ON DELETE SET NULL,
  fecha_cosecha date NOT NULL DEFAULT CURRENT_DATE,
  libras_humedo numeric(12,2) NOT NULL DEFAULT 0,
  libras_seco numeric(12,2) DEFAULT 0,
  precio_libra_humedo numeric(10,2) DEFAULT 0,
  precio_libra_seco numeric(10,2) DEFAULT 0,
  fermentacion_dias int DEFAULT 0,
  secado_dias int DEFAULT 0,
  estado text DEFAULT 'fresco',
  observaciones text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE cacao_lotes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_cacao" ON cacao_lotes;
CREATE POLICY "anon_all_cacao" ON cacao_lotes FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_cacao" ON cacao_lotes;
CREATE POLICY "anon_ins_cacao" ON cacao_lotes FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_cacao" ON cacao_lotes;
CREATE POLICY "anon_upd_cacao" ON cacao_lotes FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_del_cacao" ON cacao_lotes;
CREATE POLICY "anon_del_cacao" ON cacao_lotes FOR DELETE TO anon, authenticated USING (true);

-- ============ CONFIGURACION (SINGLETON) ============
CREATE TABLE IF NOT EXISTS configuracion (
  id int PRIMARY KEY DEFAULT 1,
  nombre_finca text DEFAULT 'Mi Finca',
  capital_inicial numeric(14,2) NOT NULL DEFAULT 0,
  margen_objetivo numeric(5,2) NOT NULL DEFAULT 30,
  porcentaje_alerta_costo numeric(5,2) NOT NULL DEFAULT 15,
  dias_trasplante_default int NOT NULL DEFAULT 35,
  moneda text NOT NULL DEFAULT 'RD$',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT singleton_config CHECK (id = 1)
);
ALTER TABLE configuracion ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_all_config" ON configuracion;
CREATE POLICY "anon_all_config" ON configuracion FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_ins_config" ON configuracion;
CREATE POLICY "anon_ins_config" ON configuracion FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_upd_config" ON configuracion;
CREATE POLICY "anon_upd_config" ON configuracion FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

INSERT INTO configuracion (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

-- ============ ÍNDICES ============
CREATE INDEX IF NOT EXISTS idx_parcelas_cultivo ON parcelas(cultivo_id);
CREATE INDEX IF NOT EXISTS idx_filas_parcela ON filas(parcela_id);
CREATE INDEX IF NOT EXISTS idx_cosechas_parcela ON cosechas(parcela_id);
CREATE INDEX IF NOT EXISTS idx_cosechas_fecha ON cosechas(fecha);
CREATE INDEX IF NOT EXISTS idx_gastos_parcela ON gastos(parcela_id);
CREATE INDEX IF NOT EXISTS idx_gastos_categoria ON gastos(categoria);
CREATE INDEX IF NOT EXISTS idx_gastos_fecha ON gastos(fecha);
CREATE INDEX IF NOT EXISTS idx_ventas_cliente ON ventas(cliente_id);
CREATE INDEX IF NOT EXISTS idx_ventas_fecha ON ventas(fecha);
CREATE INDEX IF NOT EXISTS idx_ventas_mercado ON ventas(mercado_id);
CREATE INDEX IF NOT EXISTS idx_ventas_estado_pago ON ventas(estado_pago);

-- Datos semilla: mercados predeterminados
INSERT INTO mercados (nombre, ubicacion, costo_transporte, precio_referencia_libra)
SELECT 'Mercado Nuevo', 'Santo Domingo', 0, 0
WHERE NOT EXISTS (SELECT 1 FROM mercados WHERE nombre = 'Mercado Nuevo');
INSERT INTO mercados (nombre, ubicacion, costo_transporte, precio_referencia_libra)
SELECT 'San Pedro', 'San Pedro de Macorís', 0, 0
WHERE NOT EXISTS (SELECT 1 FROM mercados WHERE nombre = 'San Pedro');
INSERT INTO mercados (nombre, ubicacion, costo_transporte, precio_referencia_libra)
SELECT 'Hato Mayor', 'Hato Mayor', 0, 0
WHERE NOT EXISTS (SELECT 1 FROM mercados WHERE nombre = 'Hato Mayor');

-- Vehículo predeterminado Ford F-150
INSERT INTO vehiculos (nombre, modelo)
SELECT 'Ford F-150', 'Ford F-150'
WHERE NOT EXISTS (SELECT 1 FROM vehiculos WHERE nombre = 'Ford F-150');

-- Cultivo de cacao por defecto
INSERT INTO cultivos (nombre, variedad, dias_germinacion, dias_trasplante, color)
SELECT 'Cacao', null, 7, 60, '#92400e'
WHERE NOT EXISTS (SELECT 1 FROM cultivos WHERE nombre = 'Cacao');
