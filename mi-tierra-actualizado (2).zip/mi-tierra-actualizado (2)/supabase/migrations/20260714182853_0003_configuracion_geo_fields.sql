/*
# Add geographic fields to configuracion

1. Modified Tables
- `configuracion`: add `latitud` (numeric, default 18.4861 for Dominican Republic center) and `longitud` (numeric, default -69.9312)
2. Notes
- These fields support the Clima (weather) module by providing farm coordinates for the Open-Meteo API.
- Defaults are set to Santo Domingo, Dominican Republic coordinates.
*/

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'configuracion' AND column_name = 'latitud') THEN
    ALTER TABLE configuracion ADD COLUMN latitud numeric(10,4) DEFAULT 18.4861;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'configuracion' AND column_name = 'longitud') THEN
    ALTER TABLE configuracion ADD COLUMN longitud numeric(10,4) DEFAULT -69.9312;
  END IF;
END $$;
