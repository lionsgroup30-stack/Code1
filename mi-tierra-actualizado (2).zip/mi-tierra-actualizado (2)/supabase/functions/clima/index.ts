import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface WeatherData {
  temperatura: number;
  humedad: number;
  precipitacion: number;
  viento: number;
  codigo: number;
  descripcion: string;
}

function weatherDescription(code: number): string {
  if (code === 0) return "Despejado";
  if (code <= 3) return "Parcialmente nublado";
  if (code <= 48) return "Niebla";
  if (code <= 67) return "Lluvia";
  if (code <= 77) return "Nieve";
  if (code <= 82) return "Lluvia intensa";
  if (code <= 99) return "Tormenta";
  return "Desconocido";
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const lat = url.searchParams.get("lat") || "18.4861";
    const lon = url.searchParams.get("lon") || "-69.9312";

    const apiUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max,weather_code&timezone=America%2FSanto_Domingo&forecast_days=7`;

    const response = await fetch(apiUrl);
    if (!response.ok) {
      throw new Error(`Open-Meteo API error: ${response.status}`);
    }
    const data = await response.json();

    const current: WeatherData = {
      temperatura: data.current?.temperature_2m ?? 0,
      humedad: data.current?.relative_humidity_2m ?? 0,
      precipitacion: data.current?.precipitation ?? 0,
      viento: data.current?.wind_speed_10m ?? 0,
      codigo: data.current?.weather_code ?? 0,
      descripcion: weatherDescription(data.current?.weather_code ?? 0),
    };

    const forecast = (data.daily?.time ?? []).map((date: string, i: number) => ({
      fecha: date,
      temp_max: data.daily?.temperature_2m_max?.[i] ?? 0,
      temp_min: data.daily?.temperature_2m_min?.[i] ?? 0,
      precipitacion: data.daily?.precipitation_sum?.[i] ?? 0,
      viento: data.daily?.wind_speed_10m_max?.[i] ?? 0,
      codigo: data.daily?.weather_code?.[i] ?? 0,
      descripcion: weatherDescription(data.daily?.weather_code?.[i] ?? 0),
    }));

    return new Response(
      JSON.stringify({ current, forecast, location: { lat: +lat, lon: +lon } }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
